# Gemini Next Tasks — PB-002 scoped slices (broad claim open) (2026-08-29)

PB-002 scoped interaction slice is landed at the rig-evidence layer (`e9ace7f22`,
focused class 10/10). The broad autonomous progression claim remains open. What
remains, in priority order. Sources: `PROJECT-CONTROL.md` blocker table,
`ROADMAP.md`/`STATUS.md` PB-002 sections,
`scorecard-explorations/playerbot-blockers.md`, and
`LevelingLoopScenario.KnownPrimitiveGaps`.

## 1. PB-002 broad closure — live progression slice (highest value)

Rig evidence does not close the broad claim. Run the quest-270 chain (or the
full leveling loop) on the **live stack** with a real client/bot: accept →
supplies → skill 11229 cast at doodad 687 → phase 161→304 → turn-in. Record
wire/state evidence; classify as live-bot, not rig. `H` stays UNKNOWN until
Josh plays it. Entry: `LevelingLoopScenario` + live Game server; needs
`AAEMU_LIVE_RIG`-style environment per existing E2E conventions.

## 2. Next objective types (one slice each, InteractionLeg pattern)

From `KnownPrimitiveGaps`, in value order:

- **QuestActObjSphere** — sphere-entry movement primitive. `SphereQuestManager`
  is now null-guarded (`e9ace7f22`); still needs `SphereGameData` seeding in
  rigs and a leg that moves the bot into the act's sphere. Canonical control
  candidate already identified: quest 1372 (accept NPC 2279, Lv10).
- **QuestActObjCraft** — Craft action exists; workbench resolution + recipe
  mapping uncomposed. Canonical candidate: quest 6024 (Lv10, accept NPC 1884).
- **QuestActObjCinema** — cinema-trigger primitive. Candidates: 6041/6044/6054
  (accept NPC 14317, Lv1).

Each: one leg + positive test + fail-closed control, same recipe as the
quest-270 slice (see `scorecard-explorations/mechanics/quest-implementation-guide.md`).

## 3. Quest discovery channel gaps

~900 channel offers remain unreachable; `ConAcceptComponent` is deliberately
deferred (stub, no player-observable precondition). Item/Sphere/Level channels
are landed. Task: census which of the ~900 are ConAcceptComponent-gated vs
objective-gated, and wire the next channel.

## 4. PB-001 live navigation

`IGameplayActor.NavigateTo` landed; interior + cross-region routes unproven on
the live stack. Run them, then Josh assesses movement feel (H).

## 5. PB-005 grounding classification (H-blocked)

Cave/interior, submerged, and duplicate-ownership rows await Josh's W4-5
grounding tour coordinates. Engineering can pre-stage the classification
tooling; do not fabricate classifications without the tour data.

## 6. PB-007 WAR-HONOR

Narrow flagged-aggression handshake is closed. Deferred: WAR-HONOR (>251
hostile kills + conflict timer) and broader PvP/honor/client-feel scope.

## 7. A5 six-hour dormant-timer soak

Cancellation safety landed (`950cfd279`). Run the approved six-hour soak with
exact SHA, env, and cleanup evidence; no soak result exists yet.

## 8. Mail lifecycle gaps

From `fef64f07e` scorecard note: mail return opcode 0x0a2 evidence boundary +
COD/expiry lifecycle gaps remain open.

## 9. Housekeeping (5 minutes)

- Commit or discard the two modified generated evidence files
  (`leveling-loop-2026-08-25.jsonl`, `m7-adventurer-spike.jsonl`) left dirty by
  the test run.
- Optional: amend `e9ace7f22`'s message — it claims a "SpawnEffect coordinate
  transform" fix, but the actual change is the null-chain hardening.
