# PB-002 Quest-270 Interaction — Handoff (2026-08-29)

## Status: SCOPED INTERACTION SLICE GREEN — PB-002 SCOPED SLICES LANDED / BROAD AUTONOMOUS PROGRESSION CLAIM OPEN

The DeepSeek worker's 5h exploration is superseded. The implementation was redone
in an isolated takeover worktree and the quest-270 chain **passes at the rig
evidence layer**. One pre-existing fail-closed control test was rewired to a new
quest and needs a small fixture seed to go green. Exact state below.

This is deterministic rig evidence, not live-bot or human evidence. Full objective
reachability, live/client progression, and H (human) evidence remain open.

---

## 1. Worktree map (important — two dirty trees, only one is valid)

| Path | State |
|---|---|
| `/root/aaemu-dev` (develop, HEAD `5712254d7`) | **Contains STALE MALFORMED worker copies** of `AAEmu.Game/Models/Game/Bots/HeadlessSession.cs` + `AAEmu.Game/Models/Game/Skills/Effects/SpawnEffect.cs` (duplicated methods, unterminated braces — does not compile). **Delete first:** `git checkout -- AAEmu.Game/Models/Game/Bots/HeadlessSession.cs AAEmu.Game/Models/Game/Skills/Effects/SpawnEffect.cs` |
| `/root/aaemu-dev/.worktrees/pb002-interaction-unblock` | DeepSeek's coherent-but-superseded diff (+83/−11). May be discarded after taking mine. |
| `/tmp/aaemu-pb002-takeover` | **MY WORK — the good tree.** Detached at `5712254d7`, uncommitted. `AAEmu.Game/Data/compact.sqlite3` is a symlink → canonical DB. |

**Take over by copying these six files from `/tmp/aaemu-pb002-takeover/...` into `/root/aaemu-dev`:**
1. `AAEmu.Game/Core/Managers/UnitManagers/DoodadManager.cs`
2. `AAEmu.Game/Models/Game/Bots/HeadlessSession.cs`
3. `AAEmu.Game/Models/Game/Skills/Effects/SpawnEffect.cs`
4. `AAEmu.Game/Core/Managers/Bots/GameplayActor.cs`
5. `AAEmu.Game/Core/Managers/Bots/LevelingLoopScenario.cs`
6. `AAEmu.UnitTests/Game/Core/Managers/Bots/LevelingLoopScenarioRigTests.cs`

(`cp -a` preserves the BOM-less edit; `git diff --check` was clean.)

## 2. What the change is

### Engine / actor
- **`DoodadManager`**: `Create(...)` now delegates to `CreateCore(..., attachToWorld: true)`; new `internal Doodad CreateDetached(..., attachToWorld: false)` skips the property `ParentWorld` assignment. **Why:** the property setter walks `Transform.InstanceId → WorldManager.GetWorld(id)`, which returns null for unregistered fixture worlds → `value.Id` NRE. Public `Create` behavior is byte-identical to before.
- **`HeadlessSession.SpawnDoodadFromTemplate(uint)`** (new, additive): fail-closed canonical doodad spawn — requires loaded `DoodadManager` (`PeekInstance.Exist`), `CreateDetached` with `skipPhaseInitialization: true` (deterministic; tests drive phases), pins `_parentWorld`/`_instanceId` backing fields, region-joins when `World.Regions != null`, `World.AddObject`. Legacy bare `SpawnNpc/SpawnDoodad` **untouched** (the worker's global canonical-rerouting was rejected: `NpcManager.Create` pulls equipment/buffs/AI and would destabilize the full suite).
- **`SpawnEffect.Apply`** line 37: `caster?.ParentWorld?.SpawnManager?.GetNpcSpawner(...)`. Headless worlds have no SpawnManager; without this the five trailing SpawnEffects of skill 11229 NRE'd. In production worlds SpawnManager exists, so behavior there is unchanged except never crashing on a torn-down world.
- **`GameplayActor.InteractWith`**: when `ResolveInteractionSkill` returns a skill id, the action now goes through the **real client pipeline** — `new Skill(template).Use(Character, SkillCaster(Unit), SkillCastTarget(Doodad, objId), null, bypassGcd:false)` — so `InteractionEffect → World.Interactions.Use.Execute → Doodad.Use → DoDoodadInteractionEvents → QuestActObjInteraction.OnInteraction` all fire through the same path as `CSStartSkillPacket`. Scheduled cast-time skills (11229 has 3000 ms cast) get the same synchronous-completion seam UseItem already uses (`Character.SkillTask` identity check → `skill.Cast(...)` → `skill.Cancelled = true`). Skill-less loot-func interactions keep the old direct `doodad.Use(Character)` path; request rejection semantics and post-observation change detection are unchanged.

### Scenario support
- **`LevelingLoopScenario`**: `QuestActObjInteraction` removed from `KnownPrimitiveGaps`; new switch case routes to new `InteractionLeg` — resolves source template (`HighlightDoodadId ?? DoodadId`) among perceived doodads, bounded attempts (one per source), `InteractWith` per source, and **requires the live objective count to increase** after every completed interaction (fail-closed, never fakes credit).

### Tests added (`LevelingLoopScenarioRigTests`)
- Nested **`CanonicalInteractionDataScope`** (IDisposable): captures/restores `SkillManager` + `DoodadManager` singletons, installs fresh instances with Moq deps (pattern copied from `GameplayActorTestRig.SeedDoodadManager`), calls `.Load()` to pull full canonical data, restores in `Dispose`. Call order in tests: `PlayerbotPilotRig.SeedPilotSingletons()` → `using var scope = ...` → `GameplayActorTestRig.Seed()` → `SeedQuest269To270Items()`.
- `LevelingLoop_Quest269To270_CompletesCanonicalInteraction` — **PASSES**: two-link autonomous chain (269 group-hunt ×5 via RigKillSeam over real templates 3462/3465/3466/3467/3468, then 270: accept at NPC 3526 → supplies 3899+3900 → skill 11229 cast at doodad 687 phase 161 → phase 304 + both items consumed + OnInteraction credit → advance → turn-in). Asserts link order, pursuit type, phase, inventory drain, and audit-trace subsequence.
- `InteractWith_Quest270WithoutSuppliedItems_FailsWithoutCredit` — **PASSES**: accepts 270 directly (`actor.AcceptQuest(270, Npc, 3526)`), strips both supply items via `Inventory.ConsumeItem`, `InteractWith` → Rejected, objective stays 0, phase stays 161.
- `InteractWith_Quest270WrongPhase_FailsWithoutCredit` — **PASSES**: phase forced to 304 first → group 304 has no funcs → resolve skill 0 → no state change → Rejected, no credit, items intact.
- `LevelingLoop_UnsupportedObjectiveType_FailsClosedNamingMissingPrimitive` — **FAILING (last blocker)**, see §4.

## 3. Verified canonical facts (do NOT re-trace)

- Quest 269 (Lv8): start comp 913 (gate Level≥5 only), accept/report NPC 5436, progress act detail 55 = MonsterGroupHunt group 57 ×5 (npcs 3466/3467/3468/3465/3462), completion reward item 18791 (act 4079).
- Quest 270 (Lv8): start comp 917 gates: `Level≥5` + `PreCompleteQuestContext(269)`; accept act 162 → NPC 3526; supplies: 3899 (토치/torch) ×1 + 3900 (짚더미/hay) ×1 — both have `use_skill_id = 0`; progress act detail 12 = `QuestActObjInteraction`: wi_id 19 (Use), count 1, doodad_id 687, highlight 687, phase 0; report act 896/189 → NPC 3526.
- Doodad 687 (토끼굴): func groups **161** (kind 1 Start) and **304** (kind 2). Group 161: func row 176 `DoodadFuncRemoveItem` `func_skill_id=11229`, `next_phase=304`; `doodad_func_remove_items` 176: item **3899** ×1. Group 304 has no funcs. `DoodadManager.Create` → `GetFuncGroupId()` picks kind-1 group → **161**.
- Skill 11229: `casting_time=3000`, `target_type_id=8` (Doodad), mana 0, no effect delay/channeling. Reagents: `skill_reagents` id 787 = item **3900** ×1. Effects in order: **InteractionEffect 5124 first**, then SpawnEffects 20778–20782 (5). Credit fires before the spawn tail; missing 3900 → no credit (proven by passing no-items control). The SpawnEffects reference spawners absent in headless worlds — that's why the `SpawnEffect` null-chain (§2) is required.
- Quest 64's interaction act (detail 372, doodad 2880) is now *partially* reachable — it can't be the unsupported control anymore.

## 4. LAST BLOCKER FOR THIS SCOPED INTERACTION TEST SET

`LevelingLoop_UnsupportedObjectiveType_FailsClosedNamingMissingPrimitive` was
re-pointed from quest 64 (interaction — now supported) to **quest 1372**

```
FailStage=RUN (FidelityError): ArgumentNullException: Value cannot be null. (Parameter 'dictionary')
```

The loop NREs before reaching OBJECTIVES — sphere evaluation touches `SphereGameData.Instance.IsInsideAreaSphere` (see `UnitReqs.cs` AreaSphere kind), whose dictionary is never seeded by `PlayerbotPilotRig.SeedPilotSingletons()` (it only loads QuestManager + UnitRequirementsGameData).

**Two acceptable fixes:**
1. Seed `SphereGameData` with an empty dictionary (missing-only, GameplayActorTestRig discipline) in the test before `Run`, keeping quest 1372; or
2. Re-point the control to a cinema quest: **6041** (`QuestActObjCinema`, accept NPC 14317, Lv1 — verify that acceptor's other offers don't win the band and that its start-gate dictionary is seeded; query `unit_reqs` for its start component first).

Run everything:
```bash
cd /root/aaemu-dev   # AFTER §1 cleanup + file copy
dotnet test --project AAEmu.UnitTests/AAEmu.UnitTests.csproj --configuration Release \
  --treenode-filter "/*/*/LevelingLoopScenarioRigTests/*"
# Then the standard gate from a NORMAL clone (gate.sh fails from linked worktrees — .git file):
./scripts/gate.sh
```

Expected after the fix: class at 11/11 (it is 10 tests now; the takeover run was total 10 / failed 1).
## 5. Quest implementation guide (DONE FOR THIS SCOPED SLICE — NOT BROAD PB-002 CLOSURE)

The user-requested sophisticated-quest doc is written:
[`scorecard-explorations/mechanics/quest-implementation-guide.md`](../mechanics/quest-implementation-guide.md).
It covers the canonical-data archaeology queries, the interaction-credit
pipeline, scenario-leg conventions, and every headless-rig seam this slice
needed (detached factory, synchronous cast completion, kill seam, null-chain
hardening, fail-closed control selection). No further authoring required.

## 6. Evidence classification

Rig evidence only — deterministic headless contract tests against canonical
compact.sqlite3 data. **Not** live-server or human proof; PB-002 broad claim stays
OPEN per `SCORECARD.md`. `H` remains UNKNOWN. No gate run yet on the final tree
(gate must run post-integration from a normal clone).
