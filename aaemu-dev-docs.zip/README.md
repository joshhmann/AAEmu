# ![AAEmu](https://i.imgur.com/NFDY376.png)

[![Coverage Status](https://coveralls.io/repos/github/AAEmu/AAEmu/badge.svg?branch=develop)](https://coveralls.io/github/AAEmu/AAEmu?branch=develop)
![Discord](https://img.shields.io/discord/479677351618281472?color=%235865F2&label=Discord&logo=Discord&logoColor=%23FFFFFF")
[![Ask DeepWiki](https://deepwiki.com/badge.svg)](https://deepwiki.com/AAEmu/AAEmu)

__Open source server software for ArcheAge written in .NET C#__

### Setup, help & support, FAQs
Head over to the [wiki](https://github.com/AAEmu/AAEmu/wiki).
For the fork's project status and evidence rollup, see
[PROJECT-CONTROL.md](PROJECT-CONTROL.md).
If you don't find what you're looking for there, [talk to a human](#discussion). Please do not use our issue tracker for support requests.

### Discussion
- [Community Discord](https://discord.gg/vn8E8E6)
- [FAQ](https://github.com/AAEmu/AAEmu/wiki/FAQ)
- [Mini troubleshooting guide](https://github.com/AAEmu/AAEmu/wiki/Mini-troubleshoot-guide)

### Can I contribute?
Yes you can! Contributions are welcomed provided that they comply with our [Contributing Guidelines](CONTRIBUTING.md). Please ensure you read the relevant sections of the guidelines carefully before making a Pull Request or opening an Issue.

## Contributing

See [Contributing](CONTRIBUTING.md) for details. Thanks to all the people who already contributed!

<a href="https://github.com/AAEmu/AAEmu/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=AAEmu/AAEmu&max=750" />
</a>

## Star History

[![Star History Chart](https://star-history.dera.page/svg?repos=AAEmu/AAEmu&type=timeline)](https://star-history.dera.page/#AAEmu/AAEmu&type=timeline)

## Licensing information

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU Lesser General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

AAEmu/AAEmu are not affiliated with XLGames. All brands and trademarks belong to their respective owners. AAEmu is not a XLGames-approved software, nor is it associated with XLGames.
