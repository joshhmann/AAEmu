# ArcheAge Slums — Data-Wiring and Evidence Scorecard (enriched)

Layers: (1) canonical 1.2 data surface (679 sqlite tables), (2) code wiring,
(3) upstream issue tracker (AAEmu/AAEmu open issues, 2026-08-03).

The table-wiring percentage is a discovery signal, not a feature-completeness
percentage. A referenced table can back broken behavior, while a complete
mechanic may not require every related table. Milestone readiness is decided
by the human, automated, restart-persistence, and soak evidence in ROADMAP.md;
never raise priority merely to improve a wiring percentage.

# ArcheAge 1.2 Data-Wiring Scorecard

Generated from: compact.sqlite3 r208022 (679 tables) vs AAEmu develop (95 managers).

## Legend
- **Tables**: canonical sqlite tables in the domain
- **Data-wired**: tables referenced by any .cs (server reads this data)
- **Managers**: game systems present in code

## Mechanic completion model

Track player-facing mechanics separately from table wiring and separately from
zone content. Each mechanic gets six evidence dimensions:

| Dimension | What it proves |
|---|---|
| **C — Canonical** | The intended ArcheAge 1.2 behavior and required compact/MySQL/client data are identified. |
| **W — Wired** | Normal runtime code paths exist end-to-end; a manager or referenced table alone is not enough. |
| **H — Human** | A player completes the curated scenario from a reproducible reset state without GM repair. |
| **A — Automated** | Behavior assertions exercise the mechanic, including negative/error paths. |
| **R — Restart** | Logout/restart/crash recovery preserves state without loss or duplication. |
| **S — Soak** | The mechanic survives its milestone load/duration and meets explicit performance/recovery budgets. |

Grades are `U` unassessed, `0` absent/broken, `1` partial or proxy evidence,
`2` verified for the named curated scope, and `N/A` only with a written reason.
Never average the grades. A mechanic is ready for a milestone only when every
dimension required by that milestone is `2`; the weakest required dimension
wins. Every non-`U` grade must link to a query/report, code path, test, human
run, restart run, or soak artifact.

**H dimension rule (reconciled 2026-08-12, bot-backtrack program):** `H`
means an ACTUAL PLAYER completing the curated scenario — never a bot or
scripted actor. Scripted-actor/bot evidence is recorded under `A`
(functional) with an explicit "proxy/bot-functional" label in the evidence
cell; it is NEVER recorded as `H=2`. `H` stays `U` (UNKNOWN) until Josh runs
the curated scenario. (ROADMAP M5-stand-in rule: bots prove function, never
feel.)

## MCP expansion (2026-08-27)
- MCP sidecars and the management gateway remain client-neutral; availability
  is not external-client actor lifecycle evidence.
- Historical coverage merge `8a22dcb4` and its 33-test / 19-tool smoke record
  are retained. Earlier route-count checkpoints remain historical, not the
  current catalog verdict.
- Flash reports fifteen additional authenticated actor routes/tools:
  `deposit_money`, `withdraw_money`, `deposit_item`, `withdraw_item`, `plant`,
  `harvest`, `craft`, `buy`, `sell`, `pack_pickup`, `put_down`,
  `load_pack_onto_vehicle`, `board_vehicle`, `unboard_vehicle`, and
  `drive_vehicle`. The current MCP catalog is **39 tools**.

## Position 2026-09-07 (current; history below preserved)

- HEAD: local `develop` at `0f2ff824f`. Since the `322390b32` baseline above:
  combat kill-races closed, M5 decision primitive + M6 cancellation/isolation
  integrated, Q1 singleton-lane serialization, Q2 runner fix, Q3 seam salvage
  (blend dropped), Q4 grant rig + live hunt-leg, Q5 wildlife audit, Q6 live
  9/9, M8 C3 farmer, Phase 1 audit telemetry + registry hardening, gap tests
  (deck-wins, seat round-trip, assist cast).
- Gate @ `8a4721775`: 2883 total / 2882 passed / 0 failed / 1 skipped
  (environmental live-rig skip); MCP smokes 39 + 24; archaeology-cycle
  156/156 + 24-tool smoke, compact md5 unchanged.
- A5: b1 + b2 closed (tested revision `02903804b`); SHAPE re-show pending.
- H stays U (UNKNOWN) everywhere until Josh runs the curated scenario —
  including his 2026-09-06 Wardton tour (keeps + deck exception recorded,
  two dock snaps parked UNCONFIRMED, cave keep ruling).
- Current source/test HEAD is local `develop` at `322390b32` (combat bonus-snapshot + aggro-table
  kill races; prior `7c0772f12` loot-race regression, `9ad5735b2` bot-wildlife crash cluster);
  CompleteQuest composition, non-objective act classification, and Level objective pursuit are
  landed, plus SusManager teleport reset (`da06470ab`), `ExecutionBoundary.RunUnscoped` for skill
  plots (`16112c24c`), and trapezoidal Move profile (`a38484f9e`). M5 proposal
  `263ecc66c474ca1c5f4b085e86ef3e47f49fd1`, M6
  cancellation `950cfd279`, population isolation `c97909f4f`, and opt-in
  six-hour leg `155c82c66` remain integrated.
  `A5_TIER3_SIX_HOUR=1`, minutes >=360, and sample seconds 1..300; it
  propagates a cooperative deadline and uses ID-bound `finally` cleanup.
- The bounded Tier3 rehearsal at source/test
  `4721cbd306cbf346bfe38b7373d5adf479b6231f` remains historical readiness
  evidence: 1000 seeded, 50 embodied, 950 dormant, p95 259.2ms, RSS +2.56%.
  The six-hour canary DID execute and produced
  `/root/aaemu-e2e-a5-tier3-sixhour/logs/g2-a5-tier3-sixhour-report.json`:
  360.00003 minutes / 361 samples, DormantSpecs 1000 throughout, embodied 0,
  materializations/dematerializations 0, queues/failures/save-skips 0, DB
  writes delta 0, tick max 19.1ms, save p95/max 85.7/100.8ms.
- The canary RSS assertion failed because baseline capture preceded deferred
  world-startup quiescence: baseline 1207.9MB, peak 5749.4MB, final 3744.1MB,
  budget +512MB. This is a testing/canary diagnostic failure, not yet
  classified as a leak and not an A5 pass; no live/human gameplay evidence is
  implied. Correction `ccd4ea857` adds `A5_WARMUP_READY`, a post-quiescence
  baseline, separate startup-peak accounting, fail-fast post-baseline RSS
  breach handling, and FULL/PARTIAL report semantics. A corrected rerun,
  preferably a 12-hour testing soak, is pending.
- **Corrected 12-hour testing/canary soak (2026-08-30, SHA
  `1ce4664f96705850136dc9d46999070fac9763fb`):** FULL — 720.000044 minutes /
  721 samples; DormantSpecs 1000/1000, embodied 0, materializations/
  dematerializations 0, scheduler queues/failures/save-skips 0, DB writes 0,
  RSS baseline 2383.4MB, startup peak 2471.3MB, steady peak 2539.3MB, growth
  155.9MB < 512MB. `passed=false` on timing only: seven distinct breach
  samples (six failure strings after dedupe) — region 299/288/308/291/297/291ms
  (budget 200) and tick max 282.9ms (budget 250). Triage: 571 ActiveRegionTick
  overruns in the 12h game log (570 in window), recurring ~76s cadence,
  566/571 same-second with physics-slow warnings, deferred 0 characters;
  physics 278–554ms tracks the stalls. Classification **UNKNOWN / host-level
  physics-thread stall versus scheduler/host steal** — not a confirmed code
  regression, not a pass. Next: isolate/inspect testing-host CPU steal and
  physics-thread diagnostics, bounded timing reproduction; budgets not
  relaxed. Warmup correction validated; timing triage remains open. Evidence
  is testing/canary operational, not live human gameplay.
- **2026-09-05 docs/correlation (read-only):** live triage ~05:36 UTC (`--since 2h`) = 7 `threw on
  target` (Effect 15109/skill 16210 IndexOutOfRange on wildlife) + 0 boundary violations + 0
  `moving a bit fast`; game container restarted ~46 min prior. Calibration correlation
  (`/tmp/opencode/a5_corr.py`): 10 physics-slow warnings vs 214,900 telemetry samples, zero host
  contention (steal/throttle 0.00) ⇒ in-process pause/GC suspect. Tier-3 6h soak
  (`Probe_A5Tier3DormantTimers_SixHour`, log header start 2026-09-05T05:21:27Z, HEAD `9ad5735b2`,
  ETA ~11:21 UTC 2026-09-05) is IN FLIGHT — report path still holds the stale 2026-08-30 `46129ae`
  until the fresh report lands with `passed=true`.
- **2026-09-05 closeout (code landed, docs-only):** loot-race regression `7c0772f12` (deterministic
  AlwaysDrop pack, 40x16-thread hammer, fail-pre/pass-post; pushed); .165 presence-demo rebuilt on
  `7c0772f12` (rollback tag kept, healthy, 5-min 0/0/0, 250 bots). Live triage: Effect 15109/skill
  16210 IndexOutOfRange (GetBonuses race) + ClearAggroOfUnit InvalidOperationException via Npc.DoDie
  (aggro race), Effects 15109/1134. Fix `322390b32` (+360/-84, BonusesLock whole-body, static
  AggroLock, BuffToleranceTests hammer + NpcAggroRaceTests; API stable; no-nesting audited); gate
  2836/1/1 (sole fail known PvP honor flake, 11/11 isolated green), MCP 39 + 24; pushed. Soak #1
  died +72min by EXTERNAL kill (zero-failure ticks, no OOM/disk/exit markers; ~06:33 UTC) — partial
  evidence, not a pass. Soak #2 rerun ON `322390b32` detached (PPID=1), log
  `soak-run-20260905-022834.log`, ETA ~15:28 UTC 2026-09-05; A5 stays OPEN, soak #2 is the
  candidate — no pass claim until the fresh report lands with `passed=true`.
- **2026-09-05 evidence-lane corrections (docs-only; dated bullets above preserved):** deployed pointer
  is `135c4f14e` (source `322390b32`), 250-bot 10-min 0/0/0 per director session report (not freshly
  queried) — supersedes the `7c0772f12`/5-min pointer; gate 2836/1/1 is NOT green (1 PvP-honor flake;
  11/11 isolated is determinism evidence only); soak #1 cause UNKNOWN (external-kill unproved);
  soak #2 window runs from post-warmup baseline (`A5_WARMUP_READY` 09:33:11Z → ETA ≈ warmup-ready +
  6h, formula never a promised clock) — supersedes fixed 15:28; A5 FINAL = (shape) +
  (quiescence-budget; soak #2 is this leg's candidate, runtime-metrics counters) + (actual timer
  progression, PLANNED) — H separate, never an A5 criterion; "preferably 12-hour" is
  recommendation-only; spline `5fdb7a385` branch-only/unit-only, geometry unproven. No grade
  changes; H grades unchanged (DEFERRED stays deferred, U stays U).
- **2026-09-05 A5 soak #2 PASS (docs-only record; quiescence-budget leg closed, A5 stays OPEN):**
  fresh `/root/aaemu-e2e-a5-tier3-sixhour/logs/g2-a5-tier3-sixhour-report.json` — G2-A5 Tier-3
  natural dormant-timer soak, runAtUtc 2026-09-05T15:33:11Z, 1000 dormant / 360 min / 60 s, FULL
  360.00008-min window (`windowCompleted` true), warmup `A5_WARMUP_READY` 09:33:11Z (134.8 s,
  baseline 5635.5 MB), RSS growth 6.7 MB (budget 512), DB writes 0, SaveP95 2.25 ms / SaveMax
  61 ms / 0 skips, 361 samples, `failures: []`, `passed: true`, leg RUN; binary 6h04m34s, 1/1.
  Code identity: stamp `ca7762d7d` is a docs-merge HEAD read at report time
  (`322390b32→ca7762d7d` = 7 markdown-only files, zero code) — tested binary is exactly
  `322390b32`. Closes (b1) 6h quiescence-budget leg; still open (a) SHAPE at the fixed tip
  (last measured 2026-08-26 pre-change), (b2) timer-progression assertion (A5-W2 unbuilt).
  "Preferably 12-hour" recommendation-only. H separate, unchanged. Soak #1 stays partial evidence.
- The prior full gate at source/test `0ce518ac03a18de00fff1516aa9e794e8566bee6`
  remains historical at 2504 total / 2503 passed / 0 failed / 1 skipped,
  compiler 0/0, MCP 39. H remains U (UNKNOWN) and no M6 full-exit claim is
  made.

**2026-09-01 A5 stall investigation dossier (read-only) + 2026-09-02 memory
diagnosis (user/live operational evidence):**
[`scorecard-explorations/mechanics/a5-physics-stall-investigation-2026-09-01.md`](scorecard-explorations/mechanics/a5-physics-stall-investigation-2026-09-01.md) —
two distinct failure modes (region overrun vs tick invoke max), 12h soak ran
pre-remediation (`1ce4664f…` predates `1801baf98…`), budgets NOT relaxed.
**2026-09-02:** section 7 records the memory-pressure diagnosis from
**user/live operational evidence** (prod CT133 presence-demo ~6 days healthy,
no soak, 1,647 physics-slow warnings over 9 days, both-world spikes
~500–575 ms matching, e.g. 573/574 ms; prod Game ~130,228 kB VmSwap on 8 GB
CT with 512 MB zram, swappiness 60, VmData ~4.7 GB, MySQL/Login/Adminer/API
sharing the ceiling; comparison/contrast soak 0 KB swap on CT124 with 48 GB
RAM, zero warnings in 12 h; live 573 ms spike coincided with a .NET BGC
thread, ~25 MB RSS drop, swap-in clustering — single reported coincidence,
not causal proof) — a **strongly supported provisional infrastructure
root cause** (Mai's CT133 diagnosis, user/live operational evidence) for
the **user-reported current PROD CT133 only**, **no longer merely UNKNOWN
host scheduling for that environment**; the soak-time classification
remains UNKNOWN (soak host had 0 swap, no in-soak host/GC telemetry —
memory/swap does NOT explain the 12 h soak breaches). **A5 remains
formally OPEN/UNCLOSED** until CT133 memory remediation is applied and a
comparable post-change run confirms the warnings disappear. Next action:
memory remediation first (preferred CT133 → 16 GB; alternatives
`DOTNET_GCHeapHardLimit` calibration or disabling swap with OOM risk),
before/after memory/swap/GC telemetry, then rerun the post-remediation
soak. A 1-hour calibration-lane telemetry run (2026-09-02) is **no new soak
result**: host sidecar ~3,388 samples, 0 steal/CPU PSI/throttling, physics
loop max 62 ms at boot and ≤ 40 ms steady, 0 in-window physics-slow
warnings. Durable planning item `A5-MEMORY-01` recorded in the dossier (no
live kanban board file in-repo; not a fake issue); acceptance = before/after
CT133 VmSwap/zram/GC/RSS telemetry plus a post-remediation full soak with
zero breaches. Old 12 h report was pre-remediation; **no new soak pass is
claimed**; budgets unchanged. **Post-remediation follow-up (2026-09-02,
user/Mai operational evidence, additive):** section 8 of the A5 dossier
records the post-change observation — Game PID 3057037, deployment since
20:06 UTC, ~10.5 h; CT 16 GiB RAM / 8 GiB swap; cgroups
`memory.max=max` / `memory.swap.max=max` with zero OOM/max hits; CT
4.2 GB / container 2.8 GB; Game VmRSS 2.67 GB, VmData 4.27 GB, **VmSwap
0 kB** (pre-restart ~129 MB); stack game 2.6 GiB / db 467.5 MiB / login
43.2 MiB / adminer 8.8 MiB / register-api 15 MB; GC trace capture alive
5.3 MB and growing; GC events in nettrace, not ordinary logs — 17 physics
warnings across the ~10.5 h observation (worst 340 ms) and 22 spikes in
the first 2 h post-restart (worst 807 ms) as distinct reported
windows/classes; **500 ms+ signature absent in the later observed period**
(the ~10.5 h window's worst is 340 ms) — the 807 ms first-2 h spike
predates that absence, which is not claimed for the first-2 h window.
This **strongly supports** the prod CT133 memory-pressure/swap
hypothesis but does **not fully prove** it (residual ~300 ms events keep
another cause open); historical 12 h soak classification remains
**UNKNOWN**; **no A5 pass is claimed**; budgets unchanged. Next closure
criteria: continue GC/nettrace capture, correlate residual warnings with
GC/thread/process/host telemetry, then run a comparable post-change A5
soak with zero budget breaches before closing A5. Labeled user/Mai
operational evidence, not H/human gameplay and not independently
reproduced here.
- PB-001 is **IMPLEMENTATION + TRACKED FIVE-TEST CONTRACT EVIDENCE**:
  source/test commits `0c57ef0c9` and `57b6e2960`; focused command/result:
  `dotnet test --project AAEmu.UnitTests/AAEmu.UnitTests.csproj --configuration Release --no-build --treenode-filter '/*/*/GameplayActorNavigateTests/*'`
  → `Test run summary: Passed! total: 5 failed: 0 succeeded: 5 skipped: 0 duration: 1s 362ms`.
  `BaiNavigationRigTests` supplies GeoData/navmesh coverage. The preserved
  prototype waypoint test was invalid because it injected private state via
  reflection; do not claim waypoint coverage from it.
- Flash-reported focused route/MCP/queue validation is **53/53**
  (`BotActionControllerRouteTests` 2/2, `BotControlActionMcpTests` 33/33,
  `BotActionCommandQueueTests` 18/18). Flash also reports a live
  `discover_self_quests` MCP benchmark with `action_status`, `trace`, and an
  independent MySQL character-row cross-check; no SHA-pinned benchmark
  artifact is checked in.
- Only later Party, Trade, Expedition, Auction, and related actor expansion
  remains explicitly deferred and is not claimed as MCP-exposed. Grades in the
## Archaeology MCP (2026-08-31) — greenfield read-only data server

- **Greenfield, separate-process, read-only MCP.** `AAEmu.ArchaeologyMcp/` is a
  new MCP stdio server (no MCP SDK; newline-delimited JSON-RPC 2.0, matching
  the `AAEmu.BotControlMcp` convention) that runs as its own process and opens
  SQLite with `Mode=ReadOnly`. It exposes the canonical ArcheAge 1.2 reference
  data (`compact.sqlite3`) and allowlisted repo source roots as read-only MCP
  tools. It is **client-neutral** (any MCP client can spawn the same process)
  and does not change any PB/M7/A5 claim.
- **Current tool surface: 24 tools.** Raw catalog/files/SQLite
  (`list_sources`, `list_databases`, `list_tables`, `describe_table`,
  `query_sql`, `read_file`, `search_files`); AAPak list/read
  (`list_pak_entries`, `read_pak_entry`); cross-cutting search
  (`search_everything`, `trace_references`, `find_quest_objectives`); typed
  domain helpers (`trace_skill`, `trace_item`, `trace_quest`, `trace_npc`,
  `trace_doodad`, `trace_mate`, `trace_vehicle`, `trace_crafting`,
  `trace_world_spawn`, `search_physics`); plus `lookup_row` and
  `compare_source_data`.
- **Canonical DB:** `AAEmu.Game/Data/compact.sqlite3`, **679 tables**, md5
  `78b3bdbf038db3b927056106efdf91af` (unchanged), target ArcheAge **1.2
  r208022**. Read-only invariant: the md5 is unchanged after any tool run.
- **Allowlisted roots + optional AAPak.** Primary root `AAEmu.Game/Data/`;
  secondary roots `AAEmu.Game/` source, `SQL/`, `tools/`, `Scripts/*census.sh`,
  `scorecard-explorations/`. E2E/soak roots, MySQL (mutable state), and secrets
  are excluded by default; extra roots only via explicit
  `ARCHEAGE_EXTRA_ROOTS` opt-in. The `game_pak` AAPak archive is reachable
  read-only through `list_pak_entries`/`read_pak_entry` only when
  `ARCHEAGE_PAK_PATH` is configured (bounded listing, 1 MiB reads, never
  streamed wholesale); otherwise both tools return a deterministic
  `not configured` error.
- **Strict controls:** SQL allow-list (`SELECT`/`WITH`/`EXPLAIN`/schema-read
  `PRAGMA` only; no mutation keywords, no multi-statement batches, no comments);
  read-only connections; row/column/byte bounds; a native
  `sqlite3_progress_handler` deadline (10 s) because `Microsoft.Data.Sqlite`
  ignores `CommandTimeout`; path/symlink guards on `read_file`/`search_files`/
  `list_databases`/`file:<name>` ids; no shell execution; no mutation tools.
- **Focused evidence is code/tests/smoke, not live client/H.** Evidence is
  `SqlGuardTests`, `ArchaeologyMcpServerTests` (24-tool surface),
  `ArchaeologyDomainTests`, `PakArchiveServiceTests`, and the deterministic
  `Scripts/mcp-archaeology-smoke.sh` protocol+read-only smoke. This is
  **A/R/L** (function/restart/load per artifact) evidence only; **H stays
  UNKNOWN** — no live client, no human run.
- **Current known limits:** no MySQL surface (mutable state, excluded); no full
  extracted client tree (only `game_pak` archive + decompiled UI Lua subset);
  no graph output (graphify builders exist but `graphify-out/` is empty);
  `search_everything`/`trace_references` are bounded text/schema-driven
  (evidence labels `exact`/`heuristic`/`textual` are never overstated);
  `search_physics` covers only the `physical_*` effect tables (no
  collision/geometry data exists in the canonical DB).
- **Development-cycle checkpoints:** deterministic local checks on every
  archaeology change (before coding: source/catalog/version inventory; during
  coding: source/data cross-reference and relationship/acceptance query;
  before merge: MCP build + focused security tests + archaeology stdio smoke;
  after merge/periodic refresh: acceptance dossier and md5/provenance review).
  The canonical one-command pre-merge check is `./scripts/archaeology-cycle.sh`
  (builds + archaeology unit tests + full smoke), run alongside `./scripts/gate.sh`.
  `./scripts/gate.sh` runs the existing BotControl smoke (4/5) plus the
  **lightweight archaeology gate smoke** (`Scripts/mcp-archaeology-gate-smoke.sh`,
  24 tools, 5/5 — no game_pak/MySQL/archaeology unit tests); the **full**
  archaeology smoke (`Scripts/mcp-archaeology-smoke.sh`) and the
  archaeology-focused unit tests are **not** duplicated in `gate.sh` — they run
  only in `archaeology-cycle.sh`. See [AGENTS.md](AGENTS.md) "Archaeology MCP —
  development-cycle checkpoints".
- **Contributor contract:** contributors MUST invoke archaeology when
  investigating/changing source, schema, protocol, client-data,
  quest/objective, item/skill/NPC/mate/vehicle/world/physics behavior, or any
  change depending on a reference-data fact; ordinary unrelated changes MAY
  skip it. Tool/source routing, the evidence contract (HEAD, source_id/path/
  version, query inputs, confidence label, truncation/bounds, canonical DB
  md5, data/code vs live/client/H), and the required pre-merge
  `./scripts/archaeology-cycle.sh` alongside `./scripts/gate.sh` are defined
  in [AGENTS.md](AGENTS.md) "Archaeology MCP — development-cycle checkpoints".
- **Links:** [`AAEmu.ArchaeologyMcp/README.md`](AAEmu.ArchaeologyMcp/README.md)
  and the authoritative data-source inventory
  [`scorecard-explorations/mechanics/archaeology-data-source-inventory.md`](scorecard-explorations/mechanics/archaeology-data-source-inventory.md).

## Post-M7 readiness / scaling gate — A5 timing triage, ActiveRegionTick remediation, next calibration (2026-08-30)

- **The 12-hour testing/canary report at SHA
  `1ce4664f96705850136dc9d46999070fac9763fb` remains valid evidence:** FULL
  720.000044 minutes / 721 samples; dormancy 1000/1000, embodied 0,
  materializations/dematerializations 0/0, scheduler queues/failures/save-skips
  0, DB writes 0, RSS growth 155.9MB < 512MB budget. Overall `passed=false` on
  timing only.
- **Timing evidence (classification unchanged):** seven distinct sampled
  breaches — region 299/288/308/291/297/291ms (budget 200ms) and tick max
  282.9ms (budget 250ms); 571 ActiveRegionTick overrun log events in-window
  recurring ~76s; 566/571 same-second physics-slow warnings; no
  workload/DB/RSS correlation. Classification remains **UNKNOWN host-level
  physics-thread stall vs host steal** — not a relaxed threshold and not an
  A5 pass.
- **Remediation `1801baf987d70eb8f2ac64ac3a9fa84e470e74e8` landed:**
  ActiveRegionTick now reuses ONE character snapshot and a direct
  active-spawner scan (`SpawnManager.GetActiveNpcSpawners` /
  `NpcSpawner.IsPlayerInSpawnRadius(IReadOnlyList<Character>)`), avoiding the
  old `GetAllSpawners()` deep-copy and nested per-spawner `GetAllCharacters()`
  enumeration; added `CharacterSnapshotMs`/`SpawnerScanMs` telemetry (bridge
  `metrics`); no-player and active-player regression tests pass 2/2
  (`ActiveRegionTickSpawnerScanTests`); builds clean. It reduces
  allocation/work but still scans O(spawners) per pass — no zero-cost claim.
- **Next action:** run bounded testing/canary calibration with the same warmup
  and phase metrics, inspect `SpawnerScanMs`/`CharacterSnapshotMs`/physics
  stalls; only then decide code fix vs budget calibration and another 12h run.
- Evidence is testing/canary operational, not human/client evidence. All
  historical reports are preserved.
## Post-M7 readiness — PB-MOUNT Autonomous Mount Riding on Arterial Highways & Travel Mobility (2026-09-03)

- **Autonomous Mount Management & Travel Mobility (`BotMountManager`):** Implemented automated mount summoning, mounting, high-speed travel (~10.5 m/s vs 5.4 m/s foot travel), and dismounting for combat/interaction.
  - **Mount Lifecycle (`EnsureMounted`, `EnsureDismounted`, `IsMounted`):** Spawns and links character steed/snowlion companion, sets world transform/instance backing without invoking headless-incompatible resolvers, and boards rider via `actor.Mount` / `MateManager.MountMate`.
  - **Engine Movement Synchronization (`GameplayActor.ApplyCharacterMove`):** Detects active mounted companion and redirects character movement commands to the mount (`VehicleMovementModel.ApplyUnitMove(Character, mate, ...)`), bypassing engine rider client-ignore rules while keeping the transform hierarchy synchronized.
  - **Highway Transit Integration:** Wired into `LevelingLoopScenario.TryTransitionToNextZone` so bots automatically mount up during long-distance inter-zone transit (Solzreed -> Dewstone -> Marianople) and dismount upon reaching the destination quest hub.
- **Evidence:** `BotMountManagerTests` **4/4** green; `LevelingLoopScenarioRigTests` **37/37** green. Full `./scripts/gate.sh` passed cleanly with 0 compiler errors/warnings, **2,773 total tests (2,772 passed, 1 skipped)**, 39 MCP BotControl tools, and 24 MCP Archaeology tools.

## Post-M7 readiness — PB-BAG Autonomous Bag Management, Vendoring & Durability Repair (2026-09-03)

- **Autonomous Bag Management & Gear Maintenance (`BotBagManager`):** Implemented automated inventory capacity auditing, vendor junk classification, and equipment durability maintenance.
  - **Inventory Auditing (`AuditBag`):** Tracks total capacity, free slots, used slots, fullness percent, damaged equipment count, and estimated junk salvage revenue. Detects near-full bags ($\le 2$ slots).
  - **Strict Asset Protection (`IsTrash`):** Guarantees quest items (`Quest_Item`, quest equipment, `LootQuestId`), active weapons/armor, and essential sustain items (potions, food, water) are never sold. Filters for `Trash_*` categories (35, 98, 101, 102, 103, 104, 105) and common refundables.
  - **Autonomous Vendoring (`SellAllTrash`):** Pumps real `actor.Sell` transactions against merchant NPCs, reclaiming inventory slots and converting mob loot into copper.
  - **First-Class Equipment Repair (`GameplayActor.Repair` & `BotBagManager.RepairAllEquipment`):** Exposed `ActorActionType.Repair` on `IGameplayActor` and implemented canonical `Character.DoRepair` interaction with blacksmith/merchant NPCs, restoring weapons and armor to `MaxDurability`. Added null safety to `Character.DoRepair` packet dispatch and `ItemManager._config` lookups.
  - **Leveling Loop Integration:** Automatically triggers maintenance on quest turn-ins at settlement hubs in `LevelingLoopScenario`.
- **Evidence:** `BotBagManagerTests` **4/4** green; `LevelingLoopScenarioRigTests` **37/37** green. Full `./scripts/gate.sh` passed with 0 compiler errors/warnings, **2,769 total tests (2,768 passed, 1 skipped)**, 39 MCP BotControl tools, and 24 MCP Archaeology tools.

## Post-M7 readiness — PB-COMBAT Tactical Combat Decision Tree & Class Spacing (2026-09-03)

- **Tactical Combat Decision Tree (`CombatDecisionTree`):** Implemented deterministic decision tree for playerbot combat. Evaluates health status, class roles (`CombatRole.Melee`, `RangedPhysical`, `RangedMagic`, `HealerSupport`), tactical spacing, and priority skill selection.
  - **Role Inference (`InferRole`):** Derives primary tactical style from starting specialization `character.Ability1` (`Wild` -> Ranged physical, `Magic`/`Death`/`Illusion` -> Caster, `Love`/`Romance` -> Support, others -> Melee).
  - **Emergency Survival Flee (`EmergencyFlee`):** When HP drops below critical safety threshold ($\le 20\%$), disengages combat and sprints away from hostiles to prevent death.
  - **Tactical Kiting & Spacing (`KiteSpacing`):** Ranged archers and magic casters dynamically backpedal 10m when hostiles penetrate melee range ($< 12\text{m}$), maintaining the optimal $12\text{–}22\text{m}$ damage band.
  - **Melee Gap Closing (`CloseGap`):** Melee bots navigate to target reach before casting close-quarters skill rotations.
- **Scenario Integration:** Wired into `LevelingLoopScenario.HuntLeg`, `LevelLeg`, and `AbilityLevelLeg`.
- **Evidence:** `CombatDecisionTreeTests` **5/5** green; `LevelingLoopScenarioRigTests` **37/37** green. Full `./scripts/gate.sh` passed with 0 compiler errors/warnings, **2,765 total tests (2,764 passed, 1 skipped)**, 39 MCP BotControl tools, and 24 MCP Archaeology tools.

## Post-M7 readiness — PB-002 Autonomous Inter-Zone Progression & Nui Shrine Death Recovery Loop (2026-09-03)

- **Autonomous Inter-Zone Leveling Progression (`TryTransitionToNextZone`):** When bots exhaust all available quest offerings in their current starting zone, they evaluate their level against zone transition gates. Level $\ge 10$ in Solzreed transitions along the arterial highway to Dewstone Plains (Lilyut Crossing hub) to trigger fresh quest discovery. Level $\ge 20$ in Dewstone transitions to Marianople Capital Gate.
- **Autonomous Death Recovery (`HandleDeathRecovery`):** When a bot dies in combat or during leveling loops, it enters death recovery, resurrects via the real `CharacterResurrection` engine path at the nearest Nui goddess shrine, relocates to the shrine anchor, and recovers HP/MP to safe operating threshold ($\ge 70\%$) before resuming quest pursuit.
- **Evidence:** `LevelingLoopScenarioRigTests` **37/37** passed (+2 tests: `LevelingLoop_DeathRecovery_ResurrectsAtNuiAndRecoversHealth` and `LevelingLoop_InterZoneTravel_TransitionsToNextZoneHighway`). Full `./scripts/gate.sh` passed with 0 compiler errors/warnings, **2,760 total tests (2,759 passed, 1 skipped)**, 39 MCP BotControl tools, and 24 MCP Archaeology tools.

## Post-M7 readiness — In-Game Dev Mapper, Navigation Toolchain, Obstacle Avoidance & Beyond Solzreed Expansion (2026-09-03)

- **In-Game Dev Mapper (Manual Walk Mode):** Implemented `DevMapperService` and `/mapper` commands (`walk`, `mark`, `stop`, `list`, `play`). Traces character movement with distance/bearing compaction (1.5m, 20°), hooks doodad interactions, NPC talks, and combat casts. Dual exports to standard CryEngine `Data/Path/<name>.path` and rich action graphs in `Data/Routes/<name>.json`. Added volatile lock-free check for zero-overhead in normal bot loops and wired disconnect cleanup in `CharacterLifecycleService.Deactivate`. Unit tests: `DevMapperServiceTests` 5/5 passed.
- **Bulk Navigation Toolchain (`Tools/Mapper/`):**
  - `redline_to_path.py`: Converts annotated 2D coordinates/map lines into continuous 3D `.path` and `.json` waypoints with ground Z-height estimation from NPC spawns.
  - `generate_zone_heatmap.py`: Plots 25,118 world NPC spawns and carriage checkpoints into 2D vector maps (`.svg`) revealing roads and settlement hubs.
  - `extract_doodad_obstacles.py`: Correlates `doodad_spawns.json` against `Doodads.xml` across 15 structure categories, extracting coordinates and keep-out collision radii.
- **Beyond Solzreed Inter-Zone Expansion (Levels 15–30):**
  - Mapped Dewstone Plains (`w_garangdol_plains_1`, 2,745 NPCs, 7 carriage checkpoints, 327 obstacles), White Arden (`w_white_forest_1`, 948 NPCs, 13 checkpoints, 107 obstacles), and Marianople (`w_marianople_1`, 1,692 NPCs, 17 checkpoints, 252 obstacles).
  - Built arterial inter-zone highway network connecting Wardton $\rightarrow$ Lilyut Crossing $\rightarrow$ Dewstone Plains (`highway_solzreed_to_dewstone.path`, 10.2 km, 402 waypoints) and Dewstone $\rightarrow$ Royster's Camp $\rightarrow$ Marianople City Gate (`highway_dewstone_to_marianople.path`, 4.0 km, 163 waypoints).
- **Physical Obstacle Avoidance (`ObstacleManager`):**
  - Created `ObstacleManager` indexing 1,395 placed obstacles across Solzreed, Dewstone, White Arden, and Marianople into a 100m 2D spatial hash grid (`Data/Navigation/*_obstacles.json`).
  - Wired into `AiGeodataManager.CheckImpossibleWalk(Vector3 point)` so A* pathfinding expands around fences, stone walls, closed gates, and buildings.
  - Sub-microsecond collision queries: `IsBlocked(point)`, `IntersectsObstacle(from, to)`, `GetNearbyObstacles(point, radius)`. Unit tests: `ObstacleManagerTests` 3/3 passed.
- **Evidence:** Full `./scripts/gate.sh` passed cleanly with 0 compiler errors/warnings, **2,758 total tests (2,757 passed, 1 skipped)**, 39 MCP BotControl tools, and 24 MCP Archaeology tools. Commits: `805f23c59`, `b34e34263`, `a1d0ae664`, `fc5c9fc1b` on `origin/develop`.

## Post-M7 readiness — PB-001 NavigateToUnit contract and LevelingLoopScenario integration (2026-09-03)

- **PB-001 routed navigation expansion:** Landed `IGameplayActor.NavigateToUnit(uint targetObjId, ...)` across `IGameplayActor`, `GameplayActor`, and `PlayerBotControllerAdapter` (`BotActionKind.NavigateToUnit`), sharing the A* GeoData pathfinder and waypoint stepper with `NavigateTo`.
- **LevelingLoopScenario integration:** Replaced straight-line `actor.MoveToUnit` calls with `actor.NavigateToUnit` in `HuntLeg` (hunt prey, talk NPCs), `LevelLeg` (grind targets), `AbilityLevelLeg` (ability grind targets), and `TurnIn` (report NPCs); wired `actor.NavigateTo` into `GatherLeg`, `GroupGatherLeg`, and `TurnIn` (report doodads) for sources/targets beyond 3 meters.
- **Evidence:** `GameplayActorNavigateTests` **8/8** passed (+3 tests: `TargetNotFound` rejected-action, `AlreadyAtUnit` immediate completion, `WithoutGeoData` direct leg arrival). `BaiNavigationRigTests` **6/6** passed. `LevelingLoopScenarioRigTests` **35/35** passed. Full `./scripts/gate.sh` passed cleanly with 0 compiler errors/warnings, **2,750 tests (2,749 passed, 1 skipped)**, 39 MCP BotControl tools, and 24 MCP Archaeology tools. Broad live stack navigation remains open.

## Post-M7 readiness and closure — PB-002 AbilityLevel support and 70 component-only deferral (2026-09-03)

- **PB-002 objective family closure:** `QuestActObjAbilityLevel` is now fully supported in `LevelingLoopScenario` via `AbilityLevelLeg`.
  - Dispatches grinding of perceived hostiles through `GameplayActor.CastSkill` and real engine `AddExp` / `AddActiveExp`.
  - Fails closed (`WrongDecision`) when the required ability is not one of the character's active abilities (`Ability1`, `Ability2`, `Ability3`).
  - No synthetic objective credit or fake XP writes; uses live `ExperienceManager.GetLevelFromExp(ability.Exp)`.
- **Ruling on the 70 component-only quests:**
  - Archeology MCP database census confirmed: of 191 component quests, 76 are paired with talk/doodad/gather discovery channels, and 45 are auto-started via `npc.Template.EngageCombatGiveQuestId`.
  - Breakdown of the remaining 70: **68 Ayanad Library floor/room bounties** (category 에아나드 도서관, level 51–55), **10 Prologue cinematic sequence chains** (category 프롤로그), **6 Honor / 2 Mistmerrow Rift world-events** (categories 명예, 전장의 안개), and **4 minigame/title/regional triggers** (categories 놀이, 칭호, 기념행사).
  - Rather than dead relics, these are specialized zone/event/script-driven quests without ordinary NPC/doodad/combat offer channels.
  - **Ruling**: Formally **deferred** to their respective future systems (Ayanad Library mechanics, tutorial director, rift/world-schedule engine). For PB-002 autonomous leveling, they fail closed and are excluded from the ordinary acceptance frontier.
- **Evidence:** `LevelingLoopScenarioRigTests` **35/35** passed (+2 ability level tests: normal completion and inactive fail-closed control). `./scripts/gate.sh` passed cleanly with 0 compiler errors/warnings, 2,747 tests (2,746 passed, 1 skipped), 39 MCP BotControl tools, and 24 MCP Archaeology tools. Broad autonomous loop and human/client testing remain open.

## Post-M7 readiness and closure — PB-002 MateLevel rig proof and canonical-data boundary (2026-08-30)

- **PB-002 remains PARTIAL / configurable support, not universal closure.**
  `QuestActObjMateLevel` has a configurable `MateLeg`; this is not closure
  across all canonical carriers or progression routes.
- `MateLeg` uses explicit `LoopOptions.MateGrowthItemId`; default `0` fails
  closed. It uses the ordinary item-use path and does not write mate XP,
  level, or the quest objective directly.
- **Deterministic rig proof:** `GameplayActor.UseItem(item, mateObjId)` →
  real `AddExp` effect → `Mate.AddExp` → headless-safe `OnMateLevelUp` →
  objective credit. **41 uses of 50k XP** reach **2,021,250 mate XP / level
  50**.
- Focused evidence is `GameplayActorMateLevelRigTests` **5/5** and
  `LevelingLoopScenarioRigTests` **33/33**; Game/UnitTests Release builds
  report **0 errors**. Evidence is deterministic rig/proxy only: no live
  authenticated or human/client evidence.
- Canonical item **29040** / skill **23085** is blocked by
  `MotherFactionOnly=5`; no canonical faction satisfies it. Do not claim
  canonical live-carrier closure. A data ruling/fix or an evidenced alternative
  canonical growth-item source is needed.
- `QuestActObjAbilityLevel` remains blocked: no ordinary player action raises a
  specific ability level, nine quests have zero accept surfaces, and quest
  **5967** is self-gated by ten Ability ≥ 50 requirements.
- **Next action:** decide/fix the canonical 23085 data issue or document an
  evidenced canonical growth-item source; then run live testing. Broad PB-002
  progression and human/client acceptance remain open.

## Post-M7 readiness and closure — PB-002 current objective frontier (historical/pre-rig snapshot; stale wording retained, 2026-08-30)


- **PB-002 remains PARTIAL; broad autonomous progression is OPEN.** This is
  current deterministic rig/proxy evidence (A/R), not live authenticated
  progression and not human/client evidence.
- **Landed objective families:** interaction, item-use, item-group use/gather,
  Sphere, Craft, Cinema, MonsterHunt/MonsterGroupHunt, Aggro (partial),
  ZoneKill, EtcItemObtain, CompleteQuest, and Level. CheckTimer and
  SupplyRemoveItem are non-objective gate/cleanup acts, not gaps.
- **Remaining objective gaps (2026-08-30 research decision):**
  `QuestActObjAbilityLevel` is **blocked / not implementable now** — 15 raw
  rows, 11 carrier quests (10 live after the 6069 drop), 9 single-ability
  quests (6070/6075–6082) have zero accept surfaces, and quest 5967 is
  self-gated by ten Ability ≥ 50 requirements; an exhaustive source trace found
  no ordinary player action/packet that raises a specific ability's level
  (only `Character.AddExp(exp, true)` distributes active-tree XP). Needs a data
  ruling/drop and/or a 1.2 trainer client capture. `QuestActObjMateLevel` is
  **implementable after a narrow rig proof** — 10 raw rows, 6 live carrier
  quests (5430/5464/5465/5466/5812/5813), 4 dangling act rows; canonical
  mate-targeted growth consumables exist and ordinary
  `GameplayActor.UseItem(item, mateObjId)` can target a Mate, with the real
  `AddExp` effect → `Mate.AddExp` → headless-safe `OnMateLevelUp` as the credit
  path (2,021,250 XP to level 50; 29040 at 50k XP = bounded 41 uses). The gap
  stays until the rig proof (fixture summon-item registration in `ItemManager`
  + headless targeting) passes. Aggro remains partial for forms without a
  resolvable NPC acceptor, ranking, or kill event. Separately, 70
  component-only quests with no engage tie remain genuinely unreachable as an
  acceptance channel; acceptance reachability is distinct from objective
  support.
- **Focused evidence:** `LevelingLoopScenarioRigTests` **32/32**,
  `QuestActObjAggroTests` **2/2**, `QuestEtcItemObtainRigTests` **3/3**,
  `QuestZoneKillVictimRigTests` **2/2**, and `PvpFlaggingRigTests` **11/11**;
  Game/UnitTests Release builds report 0 errors. These results do not close
  broad PB-002 autonomy.
- **Evidence layer for Ability/Mate:** canonical SQL + code archaeology only
  (dossiers `scorecard-explorations/mechanics/ability-level-objective-research.md`
  and `mate-level-objective-research.md`); no implementation, no live
  authenticated run, and no human/client evidence for either family.
- **Remaining next actions:** (1) Mate rig proof (fixture summon-item
  registration in `ItemManager` + headless mate-targeted potion use); (2) data
  hygiene for the dangling act rows (Ability 34805–34808; Mate 33008/33212/
  33213/35465) per data-defects §7; (3) ability data ruling/drop for
  6070/6075–6082 and 5967 trainer-flow client capture; rulings for the 70
  unreachable acceptance forms/data; live authenticated progression; and
  human/client evidence.

## Post-M7 readiness and closure — PB-002 aggro result (historical/pre-fix record, 2026-08-29)

- **PB-002: PARTIAL, broad claim OPEN.** `QuestActObjAggro` is supported only
  for NPC-acceptor forms with a nonzero acceptor template and real victim aggro
  attribution. The scenario selects normal perceived NPCs, reuses the shared
  SetTarget → Cast → kill → Loot path, and accepts completion only from live
  quest state after OnKill credit; it never writes an objective counter.
- Evidence is **deterministic rig / A (proxy, bot-functional) only**:
  `QuestActObjAggroTests` **2/2**, `LevelingLoopScenarioRigTests` **21/21**,
  and Release build **0 errors**. Canonical quest **2432** (aggro act **4**,
  NPC template **9**, Level 6) is the positive evidence. There is no live or
  human evidence, and no restart/soak claim.
- Canonical census is unchanged: **37** `quest_act_obj_aggros` rows,
  **30 canonical aggro progress acts / 30 distinct quests**, all
  component-accepted via `QuestActConAcceptComponent`, with **no NPC/NPC-kill
  acceptance**. Acceptance-channel counts are not changed by this slice.
- Boundary and next action: component forms without a nonzero acceptor template
  or a real victim event carrying `OnKillArgs.Target = dead NPC` remain
  fail-closed. Keep PB-002 open for the broader objective families and extend
  only with another canonical objective whose ranking and kill event are
  observable.

**2026-08-30 re-census at `9b8ba6317` — PB-002 perimeter update (supersedes the aggro "broken" verdict,
preserves the census facts above):** after `3827b5170` (kill-accept perception), `7d0b80041`
(`AutoStartedQuestIds` pursuit), `a1653d67d` (`DoDie` now emits `OnKillArgs.Target = victim`), and
`f5331ced7` (`AggroLeg`), the component-only bucket splits 30 auto-start+aggro (no longer engine-broken,
pursuable through the real kill-credit path) / 15 auto-start+MonsterHunt / 70 truly unreachable
(no `engage_combat_give_quest_id` on any NPC template, stub `RunAct`); the 380 kill-only quests are
perceived through the `DiscoverQuests` kill-accept channel. Perceivable-to-bot total at HEAD is
4,181 + 45 = 4,226. Full counts, commit citations, and reproducible SQL in
`scorecard-explorations/generated/discovery-channel-census-2026-08-29.md` §"2026-08-30 re-census".
The kill-event boundary "component forms without a real victim event remain fail-closed" holds only for
aggressive forms whose acceptor template fails to resolve to a perceivable kill — no longer for the 30
canonical aggro quests, which resolve through `AddQuestFromNpc` at first aggro.

**2026-08-30 — PB-002 landed current state:** `CompleteQuestLeg` now composes
`QuestActObjCompleteQuest` through real prerequisite accept → pursue → turn-in
machinery; the engine sets the completed flag. CheckTimer and SupplyRemoveItem
are non-objective gate/cleanup acts and are passed through. `LevelLeg` now
pursues `QuestActObjLevel`; it is no longer a gap. Current remaining objective
gaps are `QuestActObjAbilityLevel` (11 quests) and `QuestActObjMateLevel`
(7 live quests; 1 orphaned data row). Aggro remains partial where NPC
acceptor/ranking/kill evidence cannot be resolved.

Evidence remains deterministic rig/proxy only: `LevelingLoopScenarioRigTests`
32/32, `QuestActObjAggroTests` 2/2, `QuestEtcItemObtainRigTests` 3/3,
`QuestZoneKillVictimRigTests` 2/2, `PvpFlaggingRigTests` 11/11, and Game/
UnitTests Release builds 0 errors. Broad PB-002 autonomy remains OPEN.
The 70 component-only quests without an engage tie remain genuinely
unreachable as an acceptance channel; acceptance reachability is distinct
from objective support.

**Historical/pre-fix context:** earlier dated wording that called
CompleteQuest/Level uncommitted or listed item-group, ZoneKill, or
EtcItemObtain as gaps is retained only as historical status and is superseded
by the landed current state above.


**PB-002 interaction candidate — historical/pre-fix context:** The earlier
canonical quest-270 attempt (doodad 687, interaction skill 11229) reached
`Doodad.Use`, but its spawned fixture exposed no phase functions. That failure
and its “no implementation landed” conclusion are preserved as historical
evidence only. **Current result:** quest **269→270** interaction is landed and
verified at the deterministic rig layer through `QuestActObjInteraction` and
the real `GameplayActor.InteractWith` path. The current
`LevelingLoopScenarioRigTests` total is **21/21** after the aggro work. Broad
PB-002 remains open, with no live or human breadth claim.

**Current A5 soak boundary:** The bounded Tier3 rehearsal at source/test
`4721cbd306cbf346bfe38b7373d5adf479b6231f` is historical readiness evidence.
The six-hour dormant canary DID execute and produced
`/root/aaemu-e2e-a5-tier3-sixhour/logs/g2-a5-tier3-sixhour-report.json`:
360.00003 minutes / 361 samples, DormantSpecs 1000 throughout, embodied 0,
materializations/dematerializations 0, queues/failures/save-skips 0, DB writes
delta 0, tick max 19.1ms, save p95/max 85.7/100.8ms. RSS assertion failed
because baseline capture preceded deferred world-startup quiescence (1207.9MB
baseline, 5749.4MB peak, 3744.1MB final, +512MB budget); it is not yet
classified as a leak. This is a testing/canary diagnostic failure, not an A5
pass or live/human gameplay evidence. Correction `ccd4ea857` adds
`A5_WARMUP_READY`, post-quiescence baseline, separate startup peak, fail-fast
post-baseline RSS breach, and FULL/PARTIAL report semantics. A corrected
rerun, preferably a 12-hour testing soak, remains pending. Cancellation focused
tests 3/3 and ownership tests 2/2 pass. H remains human-only and UNKNOWN.

**Corrected 12-hour testing/canary soak (2026-08-30, SHA
`1ce4664f96705850136dc9d46999070fac9763fb`):** completed FULL — 720.000044
minutes / 721 samples. DormantSpecs 1000/1000, embodied 0, materializations/
dematerializations 0, scheduler queues/failures/save-skips 0, DB writes 0,
RSS baseline 2383.4MB, startup peak 2471.3MB, steady peak 2539.3MB, RSS growth
155.9MB < 512MB budget. Overall `passed=false` on timing only: seven distinct
timing-breach samples (six failure strings after dedupe) — region
299/288/308/291/297/291ms (budget 200ms) and one tick max 282.9ms (budget
250ms). No RSS failure. Triage: 571 ActiveRegionTick overruns in the 12h game
log (570 in window) at a recurring ~76s cadence (gaps 75–80s ×375, 30s ×126);
566/571 coincide same-second with physics-slow warnings; region passes report
deferred 0 characters; physics values 278–554ms track the region stalls. All
other workload metrics stayed healthy. No GC evidence; classification is
**UNKNOWN / host-level physics-thread stall versus scheduler/host steal** —
not a confirmed code regression and not a pass. Prior dormant soaks showed no
recurring 100–300ms region stalls; the active 1000-bot storm is not
comparable. Next action (historical — superseded by the 2026-08-30 scaling-gate
entry above): isolate/inspect testing-host CPU steal and physics-thread
diagnostics, then a bounded timing reproduction; budgets are NOT relaxed yet.
The A5 warmup correction (`ccd4ea857`) is validated; the corrected 12h rerun is
complete but timing triage remains open. Evidence is testing/canary operational
evidence, not live human gameplay.

## M2 loop reconciliation (2026-08-28)

The M2 player loop is **clean reset → ordinary golden-path baseline
quest/progression → required first-mount/baseline state → restart/clean-state
persistence verification**. At source/test HEAD
`ba530bcebec12af2bc7dc0db7451a535665bbed3`, the focused deterministic
normal-clone A/R aggregate is **32/32 passed, 0 failed, 0 skipped**:
`HeadlessSessionProvisioningTests` 8/8, `M1M2ReplayScenarioRigTests` 3/3,
`M1M2ReplayCastWindowRigTests` 1/1, `PlayerbotPilotTests` 6/6,
`QuestScenarioTests` 12/12, `QuestScenarioTierTests` 1/1, and
`QuestDataCensusTests` 1/1. The exact per-class command form was
`dotnet test --project AAEmu.UnitTests/AAEmu.UnitTests.csproj --configuration Release --no-build --treenode-filter '/*/*/<Class>/*'`.

`PlayerbotPilotTests` 30/30 cycles and restart 2/2, and
`M1M2ReplayScenario`'s fixed 16-quest ordering, are ordered-manifest/contract
proxy evidence only. Its mount criterion reports **no real mount** in the
headless fixture. `QuestScenarioTierTests` passed as a test method, but its
observed census was **4463 PASS / 110 FAIL / 14 SKIP over 4587** (T1 failure
quest 6280); these are historical evidence findings, not an M2 full-closure
claim. The matrix remains **Player closes loop = Unknown/H open** and **Bot
closes loop autonomously = Unknown/Open** for M2. No live/client/H evidence
is claimed; the original two-player/no-GM baseline remains Josh-owned and
deferred.


**Proxy vs authentic replay (2026-08-13, canonical sync t_c9f0d7f6):** the
M3a/M4 `A`-dimension grades above rest on scripted-actor PROXY evidence
(M3a: in-memory rig, reflection, GM inventory, direct service calls; M4
integrated rig: direct zone/transform assignment, manual cargo attach). Those
rigs are **superseded for authentic acceptance — NOT erased** (historical
evidence preserved in ROADMAP's M4 EXIT RECORD + deferred-gate table) — by
the bot-backtrack Phase-2 replay (root t_b4f455b0, scope t_2625be99) through
M5.1 contract actions on a real server: no direct Transform/ZoneId/GM/
reflection/DB shortcuts; labor (−60/pack) + mail payout (124540/pack,
SpecialtyManager) conservation required; process-level restart suites re-run
as-is. **Grades are not inflated:** proxy evidence stays labeled, and `H`
stays `U` (UNKNOWN) until Josh tests feel (human packet t_2b654349). Scope
lock 2026-08-14 (marker t_2625be99): replay route = **Housing.Build (M5.2,
merged 3396d9ef1) → farm/storage → craft → pack → load/drive vehicle →
unload → sell → reward**, all prerequisites merged (LoadPackOntoVehicle
6c2429ae0, DriveVehicle 6edbf0cbb, full M5.1 surface on develop).

**M3 loop reconciliation (2026-08-28):** M3a's player loop is the clean
ordinary `Character` path **place/build → plant/harvest →
storage/coffer/furniture state → observable ownership/contents result**;
M3b restart persistence is a separate loop. The prior exact source/test
baseline `b9a72825f` recorded the M3 focused aggregate **178/178** (M3a exit
1/1, M3b furniture 4/4, phase restart 10/10, property policy 11/11, repair
scanner 13/13). Current source/test HEAD is
`a77ef878d8fcba297c32c0228e712e0695cc4887`, including source commit
`1a3f13dc1`; `HousingStorageFurnitureTests` passes 13/13 with authorized
owner open and unauthorized refusal before `OpenedBy` mutation. The bot
property replay remains ordered scripted/fixture proxy; direct fixture
`SetPosition`/service preparation is not acceptance. Player/H UAT and any
live-client claim remain open.

**M4 loop reconciliation (2026-08-28; current source/test HEAD
`6ff68e1bb4a6afe08441308acb9a485b5133c42e`):** M4's clean ordinary
`Character` loop is **gather/harvest → craft pack → carry/place → load owned
vehicle → drive normal route → unload → sell specialty pack for reward →
repeat**, with per-object restart/persistence as applicable.
`SellSpecialty` composes the canonical
`CSSellBackpackGoodsPacket → SpecialtyManager.SellSpecialty` path with
ordinary merchant/pack checks, pack-consumption postcondition,
same-zone/no-pack refusal, repeat-cycle, and idempotency coverage. Focused
results: `M4ExitIntegratedSessionTests` 2/2,
`EconomyDayCycleScenarioRigTests` 4/4, and
`M3aM4ReplayScenarioRigTests` 2/2. The full normal-clone gate is
2498 total / 2497 passed / 0 failed / 1 skipped; compiler 0/0; MCP 39 tools.
The skipped `Provision_Activate_Persist_Deactivate_RoundTrip` requires
`AAEMU_LIVE_RIG` and `AAEMU_E2E_DB_PASSWORD`; the forced rebuild report was
1067 warnings / 0 errors. Player/Bot loop closure remains Unknown/Open:
replay is ordered scripted/fixture proxy and direct setup shortcuts are not
authentic acceptance. No live M4 restart/vehicle proof was run because the
shared E2E reset is unsafe; human/client QAT remains open. Historical
evidence remains preserved.

**M5 actor decision/action loop reconciliation (2026-08-28; local source/test
HEAD `0ce518ac03a18de00fff1516aa9e794e8566bee6`):** The bounded
`BotDecisionProposal`/`BotDecisionSelector`/`BotDecisionCycle` primitive
(`263ecc66c474ca1c5f4b085e86ef3e47f49fd1`) is integrated into `LevelingLoop`'s
quest-accept choice. It keeps observed context immutable, checks hard legality
before preference, bounds candidates, selects by deterministic fixed priority/
personality/tie-break, requires a terminal postcondition, and dispatches via
existing `GameplayActor`. `BotDecisionProposalTests` pass **5/5**. This is a
decision primitive plus scoped quest consumer, not universal bot autonomy;
broad M5 policy remains open. Existing actor-contract evidence, M5.3 movement
caveat, and H/client boundary remain unchanged.

**A5 canary diagnostic (current result):** The bounded rehearsal and the
executed six-hour dormant canary are separate evidence. See the current soak
boundary above for the valid report path, 360.00003-minute / 361-sample result,
RSS diagnostic failure, and pending corrected rerun. The corrected 12-hour
testing/canary soak (SHA `1ce4664f96705850136dc9d46999070fac9763fb`) is now
complete: FULL 720.000044 minutes / 721 samples, RSS within budget (growth
155.9MB < 512MB), `passed=false` on timing only (region 299/288/308/291/297/291ms
and tick max 282.9ms) — classification UNKNOWN / host-level physics-thread
stall versus scheduler/host steal; timing triage remains open (see current soak
boundary above).

## M6/M7 loop reconciliation (2026-08-28)

**M6 player loop — source/test HEAD
`da0fdc61a72a15111fddc8ac627a164a5f050558`:** clean ordinary
`Character`/bot dormant → proximity wake/materialize → scheduled action resumes
→ identity/inventory/position/metadata survive restart → safe dematerialization.
Focused M6 evidence remains **105/105**. `950cfd279` provides cancellation,
`c97909f4f` isolates baseline population, and `155c82c66` adds the
six-hour natural dormant-timer stage with explicit controls, cooperative
deadline, and ID-bound cleanup. Corrected rehearsal readiness at
`4721cbd306cbf346bfe38b7373d5adf479b6231f` remains historical evidence.
The executed canary report is
`/root/aaemu-e2e-a5-tier3-sixhour/logs/g2-a5-tier3-sixhour-report.json`
(360.00003 minutes / 361 samples): DormantSpecs 1000, embodied 0,
materializations/dematerializations 0, queues/failures/save-skips 0, DB writes
delta 0, tick max 19.1ms, save p95/max 85.7/100.8ms. RSS assertion failed on
the pre-quiescence baseline (1207.9MB baseline, 5749.4MB peak, 3744.1MB final,
budget +512MB), not yet classified as a leak. This is a testing/canary
diagnostic failure, not an A5 pass or H/UAT evidence. `ccd4ea857` corrects
warmup baseline/peak handling; a preferably 12-hour rerun remains pending.
**Corrected 12-hour testing/canary soak (2026-08-30, SHA
`1ce4664f96705850136dc9d46999070fac9763fb`):** FULL — 720.000044 minutes /
721 samples; DormantSpecs 1000/1000, embodied 0, materializations/
dematerializations 0, scheduler queues/failures/save-skips 0, DB writes 0,
RSS baseline 2383.4MB, startup peak 2471.3MB, steady peak 2539.3MB, growth
155.9MB < 512MB. `passed=false` on timing only: seven distinct breach samples
(six failure strings after dedupe) — region 299/288/308/291/297/291ms (budget
200) and tick max 282.9ms (budget 250). Triage: 571 ActiveRegionTick overruns
in the 12h game log (570 in window), recurring ~76s cadence, 566/571
same-second with physics-slow warnings, deferred 0 characters; physics
278–554ms tracks the stalls. Classification **UNKNOWN / host-level
physics-thread stall versus scheduler/host steal** — not a confirmed code
regression, not a pass. Next: isolate/inspect testing-host CPU steal and
physics-thread diagnostics, bounded timing reproduction; budgets not relaxed.
Warmup correction validated; timing triage remains open. Evidence is
testing/canary operational, not live human gameplay.
Focused M7 evidence is **147/147** no-fail/no-skip: primary **36/36**
(Adventurer 12, PartySpike 4, PartyLifecycleFaultMatrix 4,
PartyFollowAssist 4, DeathWatch 5, LevelingLoop 7) plus actor support
**111/111**. Evidence is A/R rig/proxy: hunt kill uses real
`DoOnMonsterHuntEvents` with fixture HP=0; Party spike is synthetic/fixture.
No current live authenticated-client run or H/UAT exists. `LevelingLoop`
remains bounded autonomous 254→255 only; broad autonomous decision closure,
real damage/`Npc.DoDie`, scheduler-driven route, party
roles/regroup/restart/disconnect, mount/travel, and H remain open. Historical
live reports are not relabeled current.

### Global mechanic ledger

This is the prioritized inventory, not a claim that manager presence means the
feature works. The initial `W1` entries only record code surfaces found by
Graphify and must be promoted by an end-to-end exploration.

| ID | Mechanic / scoped scenario | First gate | C | W | H | A | R | S | Evidence / next audit |
|---|---|---:|:---:|:---:|:---:|:---:|:---:|:---:|---|
| PROG-01 | Character creation, login, logout, re-entry | M2 | U | U | U | U | U | N/A | M2 baseline legs remain historical A/R/L proxy evidence: automated t_c6eb12ec (Rei gate t_1998cfd8 PASS) + restart t_cca63225 (Rei gate t_c069bacd PASS) + live probe t_92a41fe6 2/2; current deterministic A/R reconciliation at source/test HEAD `ba530bcebec12af2bc7dc0db7451a535665bbed3` is 32/32 pass across the focused provisioning/replay/census classes, with `PlayerbotPilotTests` 30/30 cycles and restart 2/2 ordered-manifest proxy evidence only; grades stay U because the original two-player/no-GM human baseline remains Josh-owned/open (t_46bf9b84). Save path: SaveManager dirty-tracking merged 5ed5d6493 (fork fix, SaveManagerTests 10/10) |
| QUEST-01 | Solzreed curated starter quest chain + rewards | M1 | 2 | 1 | U | 1 | 2 | N/A | `Golden-Route-Solzreed.md`; quest scenario harness; `next-missing-776-777.md` (330/776/777 COMPONENT_NEXT_MISSING → 0 via QuestDataOverlay, Rei gate PASS t_d8a8c798); `act-ref-2145-rig.md` (2145→2146 + sibling 1960→1961 ACT_REF_MISSING_QUEST → 0 via `2026-08-05-prune-act-ref-missing-2145.sql`, Rei gate PASS t_53baa876); `no-start-cluster-1533-1548-evidence.md` (QUEST_NO_START cluster 1533–1548 → 0 via `2026-08-05-drop-no-start-cluster.sql` — 23 contexts/25 components/42 acts dropped, Rei gate PASS t_f884383f); `no-components-1391-rig.md` (QUEST_NO_COMPONENTS 1391 empty template → dropped via `2026-08-05-drop-1391.sql` — 1 context dropped, drift −1, Rei gate PASS t_a56e8e2d); real restart verified 2026-08-10 (t_cca63225/t_92a41fe6): M2 restart baseline control run A `E2e_RestartPersistence_TwoCheckpoints_FullStateMatch` PASS 4m01s — real process-level SIGKILL + cold boot, quests 254/266 active after restart, Step/Status/Objectives byte-equal, resume-through-turn-in completes; live probe 2/2 PASS (`restart-baseline-probe-20260810-195332.md`, q266 retained across real restart, still Ready after re-entry, completed_quests 3==3==3==3); M3b exit E2E restart cycles (f5b00c686); 2026-08-23 (6dbd41b64): QuestActEtcItemObtain credit path implemented — the long-standing census watch-item family closes, ~51 live quests fixed (QUEST-01 grades unchanged — the Solzreed curated scope was already graded) |
| CTRL-01 | Movement, targeting, interaction, control-state recovery | M2/M5 | U | U | U | U | U | U | Actor-contract spike |
| COMBAT-01 | PvE combat, death, resurrection, loot | M2/M5 | U | 1 | U | U | U | U | `SkillManager`; combat audit |
| NPC-INTERACTION-01 | Data-driven per-NPC interaction skill menus (`npc_interaction_sets`/`npc_interactions`) | Later | U | 0 | U | 0 | U | U | NEW 2026-08-31 (`mechanics/undefined-world-mechanics-2026-08-31.md`): partial / undefined dispatch — `npc_interaction_sets` 111 rows, `npc_interactions` 114 rows (113 distinct skills ~21335-25256: common-tongue learning 21366/21521/21520, 무혐의 입증 21335, war-victory celebration 23146), 142 NPCs with `npc_interaction_set_id>0` (107 distinct sets). `NpcTemplate.NpcInteractionSetId` loaded (NpcManager.cs:574) with **zero consumers**; `CSStartInteractionPacket.cs:20-58` sends a hardcoded option chain (Banker/Auctioneer/Priest/…) and `SCNpcInteractionSkillListPacket` documents "the client will use the first one regardless". Per-NPC skill menus are not data-driven. W=0/A=0; H=UNKNOWN |
| ABILITY-01 | Ability selection, skill use, progression | M2 | U | 1 | U | U | U | N/A | `SkillManager`; ability audit |
| ITEM-01 | Inventory, equipment, stacking, split/move, full-inventory errors | M2 | U | 1 | U | U | U | U | `ItemManager`; inventory conservation audit. **2026-08-24 (0482ba3f0):** item_proc_bindings loaded + GetItemProcBindings; UnitProcs factory seam — items can carry procs. Evidence note only — grades stay conservative pending the inventory conservation audit |
| LABOR-01 | Labor consume/regenerate/cap/persist | M3/M4 | U | U | U | U | U | U | Labor/ActAbility audit |
| MATE-01 | Obtain, summon, mount, dismount, persist a mount | M2 | U | 2 | U | 1 | U | N/A | `MateManager`; golden-route mount scenario. **2026-08-24 (0482ba3f0):** mate_equip_packs/pack_groups/pack_items/slot_packs loaded in MateGameData (the zero-data-wired mates domain is now wired); fail-closed IsMateEquipAllowed legality at MateEquipmentContainer.CanAccept; latent EquipmentContainer null-Owner level-gate bypass fixed for mates. W=2 (real load + enforcement paths end-to-end); A=1 rig-level legality only — no live equip E2E yet (kept honest); H=UNKNOWN |
| HOUSING-01 | Claim land, construct, own, permit, demolish | M3 | 2 | 2 | U | 2 | U | N/A | M3a: `HousingPlacementValidator` (zone/category/overlap/ownership, 1.2 housing_groups/areas/group_categories) + `HousingManager.Build` wiring + `CraftEffect` construction + `DecorationLimitEvaluator` (canonical deco limits: housing_deco_limits 12 groups / 23 elems, deco_limit 40, absolute 60/208 — M3a resolved the partial-domains "dead weight" finding); harnesses `HomesteadPlacementScenarioTests` 29/29 + `HousingM3aConstructionTests` 18/18 + M3a exit scenario `M3aExitScenarioTests` (2 scripted actors = M5-stand-in, adjacent homesteads, one session) — Rei gate t_72c787c8; M3 canonical circle-back audit `mechanics/m3-canonical-audit.md` (2026-08-11): dossier verified fully covered; placement is zone-level not polygon-level, terrain 115/116 + unit 114 + max_construct_count unenforced → FIX-2 (Tai). **H=U (reconciled 2026-08-12): exit driven by scripted actors — proxy/bot-functional, H UNKNOWN until Josh runs it; M3a contract replay = deferred gate**. **2026-08-24 (0482ba3f0):** FIX-2 closed — terrain/overlap/cap/race checks verified as already landed; two-thread build-race regression added via real HousingManager.Build. Grades unchanged |
| FARM-01 | Place, grow, harvest, and recover curated crops/livestock | M3 | 2 | 2 | U | 2 | U | U | M3a: canonical potato loop (seed 15659 → doodad 2259 → loot pack 6452) on real Doodad paths (`DoodadFuncCropHarvest`/`DoodadFuncFruitPick` → loot phase); `CropHarvestLoopTests` 6/6 + M3a exit scenario (plant→grow→harvest in the same one-session flow) — Rei gate t_72c787c8; M3 canonical circle-back audit `mechanics/m3-canonical-audit.md` (2026-08-11): growth timers data-verified (60 s + 9 min, codex-confirmed "matures in ~10m"; climate 0.73 = upstream PR #744 research-derived), rot timer 48.33 h + watering path pinned (FIX-4 t_254eafc7); **livestock: growth chain data-verified (calf 2672: 3.43 h + 30.87 h) and restart-recovery pinned (M3b-2 8/8), interactions implemented (FIX-1 t_afbf7cb7, REI GATE t_3afe9f5b): `DoodadFuncFeed` consumes the feed item (error `not_enough_item`), `DoodadFuncDairyCollect`/`DoodadFuncShear`/`DoodadFuncButcher` advance their canonical chains (shear publishes the 60 s regrow term; loot from the milk/butcher phases: pack 6392 → milk 8055, pack 6390 → beef 8048); `LivestockInteractionTests` 9/9 on the real calf 2672 / sheep 518 chains**. **H=U (reconciled 2026-08-12): M3a exit driven by scripted actors — proxy/bot-functional, H UNKNOWN until Josh runs it; M3a contract replay = deferred gate** |
| PROPERTY-01 | Furniture/storage/phase/attachment persistence | M3b | 2 | 2 | U | U | 2 | U | M3 canonical circle-back audit `mechanics/m3-canonical-audit.md` (2026-08-11): canonical 1.2 persistence contract identified — MySQL `housings` (owner/co-owner, template, transform, build step, permission, dates, sell state) + `doodads` (phase/plant/growth/phase times, house-relative local transform, attach_point, owner_type, item/container links); 1.2 drops nothing on death, persists everything on restart, returns furniture+design by mail on demolish (wiki S4/S9/S10 + code `ReturnHouseItemsToOwner`); fork deliberately disables unpaid-tax demolish (documented deviation, NOTE to Josh); M3b exit gate (t_accb1c63): merged M3b-1..4; full lifecycle E2E `M3bExitPersistenceE2eTests` — place→decorate→plant→harvest, N=3 crash cycles (restart, kill -9 mid-save via INNODB_TRX-observed autosave, MySQL container kill during harvest save) + final re-entry, two homesteads (900002/900003), 16 rows asserted intact per boot with transforms/phases/owners/attachment, no loss/dup — PASS 7m08s; W=2: exit E2E exercises the real save/load runtime paths end-to-end (16 rows per boot × 3 crash cycles; kill -9 mid-save + container kill); M3b-1 E2E `M3bFurniturePersistenceE2eTests` 7/7 rows ×2 SIGKILL restarts; recovery/load seams: `ShouldLoadHouseRow`/`ShouldLoadPersistentDoodad` (M3b-3 11/11), `ApplyLoadedState` read-only phase restore (M3b-2 8/8), SpawnPersistentDoodads save-after-restore (M3b-1 4/4) — full unit gate 1691/0/1 on merged tree; autosave p95 1301ms < 2000ms at 25 bots + 2 homesteads |
| CRAFT-01 | Recipe prerequisites, labor/material consume, output | M4 | 2 | 2 | U | 2 | 2 | N/A | M4-A (fix/m4a-crafting-integrity, t_d957e80d): workstation req_doodad_id/range/ownership enforcement, bag-scope materials, stack-aware fit, rate rolls, labor-cost parity, queue guards — merged into M4 EXIT (t_97e59ffc, release/m4-exit); `M4ExitIntegratedSessionTests` drives craft 5404 (3× golden potato 19887 → pack 26489) through the REAL CharacterCraft.Craft → CraftEffect.Apply → EndCraft chain in one 4-scripted-actor session (M5-stand-in): level-9 negative (LevelLowToUse), materials consumed before grant, pack lands in Backpack slot (full gate 1778/0/1 on the merged tree). **H=U (reconciled 2026-08-12): exit driven by scripted actors — proxy/bot-functional, H UNKNOWN until Josh runs it; M4 economic replay = deferred gate** |
| PACK-01 | Craft, carry, place, load, unload, sell trade pack | M4 | 2 | 2 | U | 2 | 2 | U | M4-2 (fix/m4-2-trade-packs, t_449d0c41): level-10 craft/sell gates, origin-zone StoreCantSellSameZone, 6-day placed-pack expiry, 22 h mail delay; `SpecialtyManagerTests` 21/21 (sale math, 80/20, coin routes, gates); `M4_2TradePackRestartE2eTests` — plant_time + made_unit_id survive kill -9 (PASS on merged tree 2m12s); `M4ExitIntegratedSessionTests` — full craft→load→travel→unload→sell→reward loop, reward math 91238 base / 124540 payout verified, 2× repeat (4 scripted actors = M5-stand-in). **H=U (reconciled 2026-08-12): exit driven by scripted actors — proxy/bot-functional, H UNKNOWN until Josh runs it; M4 economic/navigation replay = deferred gate** |
| SLAVE-01 | Cart/ship summon, seats/cargo, cleanup, recovery | M4 | 2 | 2 | U | 2 | 2 | U | M4-3 (fix/m4-3-vehicle-lifecycle, t_4a91a4f5, Rei gate t_5019f7b1 PASS): despawn gates owner/312/288/801, BindSlave 324, RidersEscape 640; `SlaveLifecycleTests` 29/29; `M4VehiclesE2eTests` — two kill -9 restarts, row intact, exactly 1 row (PASS on merged tree 3m09s); `M4ExitIntegratedSessionTests` — pack loaded on slave, 801 despawn refusal, unload → despawn allowed (4 scripted actors = M5-stand-in). **H=U (reconciled 2026-08-12): exit driven by scripted actors — proxy/bot-functional, H UNKNOWN until Josh runs it; M4 navigation replay = deferred gate** |
| TRADE-01 | Direct player-to-player item/currency trade | Later | U | 2 | U | 1 | U | N/A | `TradeManager`; separate from trade packs. **2026-08-23 (d4b5e524c): trade FUNCTIONAL** — OkTrade cancel-then-finish KeyNotFoundException fixed; both-locked AND both-ok gate (was !a && !b single-side exploit); TradeOffer/TradePutup/TradeLockOk contract actions; `TradeHandshakeScenarioRigTests` 5/5. W=2 (real engine path end-to-end); **A=1 rig-level only — no live/restart evidence yet (kept honest)**; H=UNKNOWN |
| MERCHANT-01 | NPC vendor buy/sell, price, stock, refund/error paths | M2/M4 | U | 2 | U | 2 | U | N/A | **2026-08-26 recovery:** MerchantRigTests drive the REAL CSBuyItemsPacket/CSSellItemsPacket paths over capture-backed connections with real NpcManager goods packs; bot Buy/Sell actions replicate the packet seam. Merchant trio is now merged on develop (`cb514c42e` funds gate, `beaf9b82e` buyback refund, `3ba33b3af` grant-failure rollback; merge `e5db6d390`). `EconomyDayCycleE2eTests` live conservation E2E passed, with money/bank/items held across kill -9 restart (`/root/aaemu-e2e/logs/m8-economy-cycle-reconcile.md`). W=2/A=2; **H=U** — no human-client shop run. |
| AUCTION-01 | List, search, bid/buy, settle, cancel, expire | M8 | U | 2 | U | 2 | 2 | U | `AuctionManager`; market audit. **2026-08-23 (f3bb787ce) — strongest promotion of the sweep: W/A/R = 2** — expiry sweep hardened (per-lot isolation, null-safe missing-item expiry, mail-fail no longer wedges lots, `_auctionTaskScheduled` guard); `AuctionHouseRestartE2eTests` live E2E PASS 3m26s — post → buy → settle → expiry-mail across kill -9 (E2eStack.RestartGameServer(afterStop) seam). C stays U pending the canonical market audit; H=UNKNOWN |
| ECON-01 | Currency/item/labor conservation across economy | M4/M8 | U | U | U | U | U | U | Cross-mechanic invariant audit |
| MAIL-01 | Send, receive, attach, return, expire, persist | Later | U | 2 | U | 2 | 2 | U | `MailManager`; mail audit. **2026-08-26 Mail S3 acceptance (commit `31045d033`):** `MailS3RestartE2eTests.Mail_EquipmentAndCopper_SurviveRestart_AndTakeByRealPackets` PASS 1/1 in 2m39s on isolated MySQL/Docker with authenticated actors. Real `CSSendMailPacket` send near a mailbox, process kill-9/restart, persisted `SlotType.Mail=5`, receiver ownership retargeting, post-registration unread recount (1), `CSListMail`/`CSReadMail`, sequential attachment take, exact equipment instance detail/grade/durability/rune/temper fidelity, copper transfer, read transition (1→0), and `CSDeleteMail` persistence deletion all passed. Ownership guards landed for receive paths. **Scope:** W=2/A=2/R=2 for this restart-and-attachment flow; C=U (full canonical mail contract not audited), H=U (no human client run), S=U (not a soak/security-grade score). Return opcode `0x0a2` remains **STRONGLY_INFERRED** pending real-client capture; COD enforcement and expiry/bounce E2E remain follow-ups. Prior 2026-08-23 return/expiry rig evidence and 2026-08-25 ownership/instance-faithfulness findings remain in the dated history below.
| TRANSFER-01 | Fixed-route transport board/ride/disembark/recover | M4 | U | 2 | U | 1 | U | U | `TransferManager`; route audit. **2026-08-24 (3a534b539): transfer FUNCTIONAL + LIVE PROVEN** — CSBoardingTransferPacket TlId shadowing FIXED (multi-part transfers share the master's TlId but seats exist only on child parts; FirstOrDefault always resolved the seatless master, so boarding could never bond); read-only `transfers` bridge dump command; TransferRideE2eTests LIVE PASS (board Marianople Gondola tlId=1 ap=2 BondChairDouble → ride route samples → disembark at current position). W=2 (real engine path end-to-end); A=1 live board/ride/disembark E2E — recover/restart legs still open; H=UNKNOWN |
| INDUN-01 | Instance dungeons: entry/party/isolation/clear/exit, completion hooks, cooldown persistence | Later | U | 1 | U | 1 | U | U | **FORMALIZED 2026-08-31** per the read-only roadmap mechanics-gaps audit + `mechanics/undefined-world-mechanics-2026-08-31.md` (the mechanic-inventory 2026-08-25 row 22 "tracked" claim had no ledger row — real coverage 63/65, corrected by this row). Dossier `mechanics/indun-domain.md` (2026-08-24): `IndunManager` structured — entry reqs (level/party/ticket/visit count), per-party `Dungeon`s on isolated `WorldInstance`s, queue-during-load, solo→party, kick-on-leave, 24h solo expiry, access-flag reset, in-memory 4h cooldowns; `indun_zones`(20)/`indun_events`(70)/`indun_actions`(104) loaded; portal doodad funcs from client data. W=1: low-level dungeons 45/46/47/50/51/52 have ZERO scripted completion events; cooldowns memory-only; `RestoreItemTime` dead; `DungeonLoaderTask` blocking sleeps; channel-select TODO. A=1 (L exit-leg, PB-003 CLOSED with layer correction DATA→E2E-coverage): `IndunExitE2eTests` 11/11 — entry skill 17731 → bosses 10166/10167 dead → completion events 4601/4602 → exit via portal 4289/skill 17733 → SCLoadInstancePacket(world 0/zone 179) both members at pre-entry anchor; report `/root/aaemu-e2e-pb003/logs/indun-exit-e2e-report.json`. Lane D slices S1 bot-party clear-then-exit (Hadir Farm 46), S2 completion hook (45/46/47/50/51/52), S3 cooldown persistence + channel-select + non-blocking loader; S4 phase scripting deferred. Conservative grades; H=UNKNOWN |
| PVP-01 | Flagging, factions, damage, honor, death/recovery | Later | 2 | 2 | U | 2 | U | U | **Narrow handshake FIXED/CLOSED 2026-08-27** at behavioral gate evidence baseline `3871459d142fdd1767b9365a1de8d4cd3652ab0e`; current source/test HEAD is `792774d7707b8b578b8d9975896e0a1ac719f361`. Live isolated E2E 1/1 in 2m09.910s observed victim-matched non-immune `SCUnitDamaged`, immune frames excluded, `SkillFired=True`, Retribution 2167, bloodstain 877 objId 44294, and crime branch; PEACE-BLOCK passed. Parser tests 2/2. WAR-HONOR deferred; broader PvP/honor scope remains open. |
| DOMINION-01 | Dominion/castle-siege: zones, settings, plans, phase schedule, tax rate | M9+ | 2 | 2 | U | 2 | 2 | U | NEW + promoted 2026-08-26 (`mechanics/dominion-domain.md` dossier): first real reconstruction of the dominion system — DominionManager loads siege_zones(6)/siege_settings(11)/siege_plans(158) from canonical compact data; additive MySQL `aaemu_game.dominions` (SQL/updates/2026-08-26_aaemu_game_dominions.sql + base file); CSUpdateDominionTaxRatePacket wired (policy validation → persist → echo); phase cron Peace→Declare→Warmup→Siege→Payoff announcing via SCSiegeAlertPacket (0xed, documented placeholder payload); DeclareDominion special-effect now persists instead of hardcoded broadcast; enter-world rebroadcast of stored dominions; persistence E2E across kill -9 PASS (branch d42e708f5→66f124533). Combat/siege-battle explicitly NOT implemented (later slices); declare-trigger UI path still UNKNOWN (pack-planting hypothesis from client data); S=U/H=UNKNOWN |
| FISH-01 | Fishing interaction, loot, labor, contest integration | M9.5 | U | 2 | U | 1 | U | U | Fishing audit. **2026-08-24 (cd5eedf11 / 33b4df563):** dossier `mechanics/fishing-domain.md` — basic 1.2 fishing is canonically encoded in plot 809 and the plot engine/reagents/labor/zone-loot-packs/radar/FishingLoot are all implemented + wired; `CastAt(position)` contract action added; **FishingVerificationE2eTests LIVE PASS** — labor −5, worm consumed via plot reagents, Fishing actability XP, loot item landed on bite (cast 2 of 2). W=2 (real engine path end-to-end); A=1 single-scenario live proof — sports-fishing stratum still orphaned (SpawnFishEffect unreachable, catch/convert/buy funcs stubbed); H=UNKNOWN |
| PVP-01 | Flagging, factions, damage, honor, death/recovery | Later | 2 | 2 | U | 2 | U | U | **2026-08-25 (mechanics/pvp-domain.md): C=2.** CanAttack resolution order reconstructed (null fail-open → zone/mother-faction shield → Retribution-flag target → ForceAttack attacker → ZONE-01 peace block → Hostile fallback); honor formulas verified (Conflict solo 10 / War solo 20 + 4/assist, 30 s assist windows, War victim −10 clamp ≥0, PvpHonorRate config); faction storage verified (system_factions/_relations + MySQL characters.faction_id); pirate punishment conversion engine-wired. **2026-08-27 (wave 8): W=2, A=2.** Historical live E2E PASS (`PvpHandshakeE2eTests`, 6/6 stages green: PROVISION, HOMELAND-SHIELD, RELOCATE-STEPPE, LIVE-ZONE-STATE, FLAG-FORCEATTACK, AGGRESS-ALLOWED, PEACE-BLOCK). Historical real damage frames (`SCUnitDamagedPacket` unpacked via Level 4 Deflate decompression in `BotTcpLink`), Retribution 2167, and bloodstain doodad 877 observed live on wire; targeted rig 6/6 green. PB-007 remains **OPEN, narrowed**: targeted rig evidence exercises real `Skill.Use`, same-faction `ForceAttack` HP decrease, Retribution, and first application/Refresh broadcasts; the historical live E2E record is retained, but no current source-pinned artifact proves a victim-matched, non-immune `SCUnitDamaged` frame. H=UNKNOWN |
| DUEL-01 | Invite, accept, bounds, result, cleanup | Later | U | 2 | U | 1 | U | N/A | `DuelManager`; duel audit. **2026-08-24 (f8252a37b):** headless verification rig — request → accept state transitions (IsInDuel) → stop cleanup + faction restoration; **found & fixed stuck-duel bug**: a failed flag-spawn left both duelists permanently IsInDuel (two NREs inside the stop path's catch-all: RestoreFaction bare indexer + flag delete path). W=2 (real engine path); A=1 rig-level — faction swap needs live-stack proof; **2026-08-25 (pvp-domain.md addendum b): bounds RESOLVED** — there is no geodata region and no ring packet; DuelManager spawns Combat Flag doodad template 5014 at the midpoint (Z snapped via GeoData.GetHeight), binds both UIs via SCDuelStatePacket, and enforces a hardcoded 75 m DistanceForSurrender per-second poll; duration flat 5-min timer. The old "bounds need live geodata" caveat reduces to verifying the flag spawns on terrain correctly on the live stack. H=UNKNOWN |
| CRIME-01 | Crime evidence/points, reporting, persistence | M9 | 2 | 1 | U | U | U | U | **2026-08-25 (mechanics/justice-domain.md): C=2.** CrimeManager fully wired — evidence doodads (bloodstains 877/878, footprints 3313/3314) → CSReportCrimePacket → CrimePoint/InfamyPoint property-setter threshold checks (Wanted 3710 @ 50, Pirate conversion @ Infamy 3000) → MySQL `crime` table via SaveManager dirty flush; wanted/arrest thresholds re-checked at login; packet table complete (all 12 justice C2G opcodes registered, 21/25 G2C sent by live code). W stays 1 — zero end-to-end/live-client proof (TrialData.cs:240 "verify packet order with a real capture"); A stays U (only GM CrimeFakeTrialSubCommand seam, no rig); H=UNKNOWN. **2026-08-26 (wave 7) evidence note:** crime-points vertical LIVE-PROVEN — JusticeCrimeE2eTests 8 stages incl. restart persistence + wanted seam PASS on the live stack; engine fix MarkDirty() added on the CrimePoint/InfamyPoint setters (silent-persistence-vanish bug — points mutated but never flushed). Grades stay conservative pending the next audit pass |
| TRIAL-01 | Arrest, jury selection, testimony, verdict, sentence | M9 | 2 | 1 | U | U | U | U | **2026-08-25 (mechanics/justice-domain.md): C=2.** TrialManager (1033 pp) full state machine — 11 TrialStep states, jury queues per mother-faction with eligibility gating, courtroom occupancy, 5 s update task, 5 guilt-tier secret ballot, sentencing math (CalculateJailTime: Σ evidence scores × infamy multiplier, pirates flat 40), skip-a-trial exploit guard (offline_guilty_time auto-verdict at login); loaded during world spawn. W stays 1 (jury summon packet ordering explicitly unverified vs live capture; orphaned G2C quartet); A stays U; H=UNKNOWN |
| PRISON-01 | Imprisonment, sentence time, labor/escape/release | M9 | U | U | U | U | U | U | No `PrisonManager` found; trace model/packet paths before scoping. **2026-08-25 (mechanics/justice-domain.md) annotation:** sentencing + imprisonment ARE implemented inside TrialManager — teleport-to-jail (Marianople Guard Barracks / Isle of Penance) + timed Prisoner_Nuian(631)/Prisoner_Haranyan(2028) buff for the sentence, offline guilty-time anti-exploit column. Labor, escape tunnels, guard NPCs, release-on-expiry logic: ABSENT entirely (buff expiry triggers no release logic) — that sub-scope honestly stays U |
| PARTY-01 | Invite/join/leave, leader, follow/assist, recovery | M7 | U | 2 | U | 1 | U | U | Party audit. **2026-08-21→23:** PartyInvite/PartyAccept contract actions through the real TeamManager engine paths (rig GameplayActorPartyTests 6/6); `PartyFollowAssistScenario` (rig 4/4); **party spike LIVE E2E PASS 2026-08-23 (c98da8a53)** — `PartySpikeScenario` m7-party-spike: 3-bot rally → assist → kill elite NPC 1870 inside the leash window over the N-actor bridge seam, with causal cast-effect traces (ActorAuditRecord v2: target_hp_before/after, effect_observed, effect_wait_ms). W=2 (invite/join/follow/assist/rally live-proven through real paths); **A=1 — partial scenario coverage** (roles, avoid-extra-pulls, resurrect, mount+travel, lifecycle fault matrix still open); H=UNKNOWN |
| EXPEDITION-01 | Expedition membership, roles, persistence | M9/M10 | U | 2 | U | 1 | U | U | `ExpeditionManager`; organization audit. **2026-08-24 (f8252a37b):** headless verification rig — full lifecycle through the real manager with capture-backed connections: create (party auto-join) → reply-accept outsider → leave → disband; create-without-party refused before mutation. W=2 (real engine path end-to-end); A=1 rig-level — persistence (terminal Save) is integration-env scope, no bot contract actions yet; H=UNKNOWN |
| CHAT-01 | Local/zone/party/expedition chat, moderation, bot identity | M7/M8 | U | 1 | U | U | N/A | U | `ChatManager`; social audit |
| ZONE-01 | Peace/conflict/war state transitions and PvP rules | Later | U | 2 | U | 1 | U | U | `ZoneManager`; conflict-state audit. **2026-08-24 (0482ba3f0): zone state machine data-wired + enforced** — hard-coded Conflict boot state removed → data-driven Peace default (legacy World.ConflictZonesStartAtConflict flag kept for tests); Peace-state PvP protection at the BaseUnit.CanAttack chokepoint (fail-open when no conflict entry; Hostile stays attackable). W=2 (real engine path end-to-end); A=1 rig-level state machine + enforcement tests — no live PvP scenario yet (kept honest); **2026-08-25 (mechanics/pvp-domain.md):** enforcement confirmed as exactly ONE hook inside CanAttack; missing for a real war cycle: war-declaration input (CSFactionDeclareHostile stub), runtime conflict seeding, war towers. H=UNKNOWN |
| ACTOR-01 | Observe/action lifecycle, rejection, timeout, idempotency | M5 | U | 0 | U | 0 | 0 | U | New contract; current source/test HEAD `792774d7707b8b578b8d9975896e0a1ac719f361` (`origin/develop`); behavioral gate evidence baseline `3871459d142fdd1767b9365a1de8d4cd3652ab0e` retains the normal-clone Release gate 2496 total/2495 passed/0 failed/1 skipped, compiler 0/0, MCP stdio 39 tools, with the sole live-rig skip identified above. PB-002 focused item-use 1/1 and related scoped results above. H remains U. |
| BOT-01 | Headless account/session/Character lifecycle | M6 | U | 0 | U | 0 | 0 | U | New fork capability |
| BOT-02 | Deterministic recovery + tick-budget compliance | M6 | U | 0 | U | 0 | 0 | 0 | Historical bounded Tier3 readiness at `4721cbd306cbf346bfe38b7373d5adf479b6231f`; six-hour canary executed with diagnostic failure and the corrected 12-hour testing/canary soak (SHA `1ce4664f96705850136dc9d46999070fac9763fb`) completed FULL with RSS within budget but `passed=false` on timing (region/tick breaches, classification UNKNOWN / host-level physics-thread stall versus scheduler/host steal; see current A5 boundary above), so no A5 pass or soak grade is claimed. **2026-09-01:** two distinct failure modes (region overrun vs tick invoke max) and the exact next calibration (bounded 6h rerun with 1s host-telemetry sidecar) are recorded in the read-only [A5 stall dossier](scorecard-explorations/mechanics/a5-physics-stall-investigation-2026-09-01.md); budgets NOT relaxed. **2026-09-02:** memory-pressure diagnosis from user/live operational evidence (prod CT133 1,647 physics-slow warnings over 9 days, both-world ~500–575 ms matching spikes; prod Game ~130,228 kB VmSwap on 8 GB CT with 512 MB zram, swappiness 60; comparison/contrast soak 0 KB swap on CT124 with 48 GB RAM, zero warnings in 12 h; live 573 ms spike coincided with .NET BGC thread, ~25 MB RSS drop, swap-in clustering — single reported coincidence, not causal proof) — a **strongly supported provisional infrastructure root cause** (Mai's CT133 diagnosis, user/live operational evidence) for the **user-reported current PROD CT133 only**, no longer merely UNKNOWN host scheduling for that environment; soak-time classification remains UNKNOWN (soak host had 0 swap, no in-soak host/GC telemetry — memory/swap does NOT explain the 12 h soak breaches); **A5 remains formally OPEN/UNCLOSED** until CT133 memory remediation is applied and a comparable post-change run confirms the warnings disappear; next action memory remediation first (preferred CT133 → 16 GB; alternatives `DOTNET_GCHeapHardLimit` calibration or disabling swap with OOM risk), before/after memory/swap/GC telemetry, then rerun the post-remediation soak; 1-hour calibration-lane telemetry run (2026-09-02) is no new soak result (host sidecar ~3,388 samples, 0 steal/CPU PSI/throttling, physics loop max 62 ms at boot and ≤ 40 ms steady, 0 in-window physics-slow warnings); planning item `A5-MEMORY-01` in the dossier (acceptance = before/after CT133 VmSwap/zram/GC/RSS telemetry plus post-remediation full soak with zero breaches); old 12 h report pre-remediation, no new soak pass claimed, budgets unchanged. **Post-remediation follow-up (2026-09-02, user/Mai operational evidence):** section 8 of the A5 dossier records the post-change observation (Game PID 3057037, deployment since 20:06 UTC, ~10.5 h; CT 16 GiB RAM / 8 GiB swap; cgroups `memory.max=max`/`memory.swap.max=max`, zero OOM/max hits; CT 4.2 GB / container 2.8 GB; Game VmRSS 2.67 GB, VmData 4.27 GB, VmSwap 0 kB vs pre-restart ~129 MB; stack game 2.6 GiB / db 467.5 MiB / login 43.2 MiB / adminer 8.8 MiB / register-api 15 MB; GC trace capture alive 5.3 MB and growing; GC events in nettrace) — 17 physics warnings across the ~10.5 h observation (worst 340 ms) and 22 spikes in the first 2 h post-restart (worst 807 ms) as distinct reported windows/classes; 500 ms+ signature absent in the later observed period (the ~10.5 h window's worst is 340 ms) — the 807 ms first-2 h spike predates that absence, which is not claimed for the first-2 h window; **strongly supports** the prod CT133 memory-pressure/swap hypothesis, **not fully proving** it (residual ~300 ms events keep another cause open); historical 12 h soak classification remains UNKNOWN; no A5 pass claimed; budgets unchanged; next closure criteria = continue GC/nettrace capture, correlate residual warnings with GC/thread/process/host telemetry, then a comparable post-change A5 soak with zero budget breaches before closing A5; labeled user/Mai operational evidence, not H/human gameplay and not independently reproduced here.|
| AGGRO-PACK-01 | NPC aggro-link packs: shared-pull via `aggro_links`/`npc_aggro_links` membership | Later | U | 0 | U | 0 | U | U | NEW 2026-08-31 (`mechanics/undefined-world-mechanics-2026-08-31.md`): truly undefined — `aggro_links` 130 named packs (`10` 집단 생활 동물류, `101` 인던_하디르의농장, `27` 십자별 평원 - 일리온 원혼 무리) + `npc_aggro_links` 643 rows / 572 distinct NPCs / 126 links / 111 multi-member packs; **neither table read anywhere in C#**. NpcManager.cs:547-560 loads only per-NPC helper columns into `NpcTemplate`; the AI help path (AI/v2/Framework/Behavior.cs:375-418) is a distance + `AggroLinkSpecialRuleKind` faction heuristic that never consults pack membership. Pack members (e.g. wraiths 2325-2329/2441, trolls 2024/2025/2098) won't shared-pull as retail. Distinct from the catalogued `quest_act_obj_aggro` objectives (PB-002). W=0/A=0; H=UNKNOWN |
| RESPAWN-LADDER-01 | Data-driven death/resurrection wait ladder (incl. siege ladder + penalty window) | Later | U | 0 | U | 0 | U | U | NEW 2026-08-31 (`mechanics/undefined-world-mechanics-2026-08-31.md`): data-only / hardcoded mismatch — `resurrection_waiting_times` 10 rows (id1→0/20, 2→5/15, 3→45/10, 4→90/5, 5-10→180/0, penalty 600 everywhere) never read; `CharacterCombat.cs:31-32` hardcodes `DeathWaitTimesSeconds=[15,30,60,90,120,150,180,210,240]` + reset 5 min, ignoring the canonical ladder, its siege variant, and the 600 s penalty window; `RespawnCooldownDurationMs=300_000` also hardcoded. In-world respawn countdown (`SCUnitDeathPacket.resurrectWaitingTime`) and post-revive penalty diverge from 1.2 data. Refines COMBAT-01 (PvE death/resurrection plumbing implemented; this is the template-data gap beneath). W=0/A=0; H=UNKNOWN |
| AUCTION-BANK-DOODAD-01 | Auction-House/Bank UI doodad funcs (`doodad_func_auction_uis`/`bank_uis`, spawned kiosk 7983) | Later | U | 0 | U | 0 | U | U | NEW 2026-08-31 (`mechanics/undefined-world-mechanics-2026-08-31.md`): truly undefined — 2+2 func-table rows reference doodad templates 7983 "무인 창고" / 6669; **7983 is spawned** in `Data/Worlds/arche_mall_world/doodad_spawns.json` ("Auctioneer/Warehouse" @ 3452.5, 4289.4, 108.5, func-group 22065). `DoodadFuncAuctionUi`/`DoodadFuncBankUi` are Logger.Trace no-ops and the tables are never SELECTed → `DoodadFunc.Use` template null → the Mirage Island kiosk is non-functional. The hardcoded NPC open path (CSStartInteractionPacket.cs:36-56 Banker/Auctioneer) is unreachable too: zero `npcs` with `banker=1` or `auctioneer=1`. Adjacent to STORAGE-01 (not promoted). W=0/A=0; H=UNKNOWN |
| REGRADE-01 | Gear regrading: spend regrade charms/scrolls to raise equipment tier with success/downgrade odds | Later | U | U | U | U | U | U | NEW 2026-08-25 (generated/mechanic-inventory-2026-08-25.md §3#1): item_grades/_grade_buffs/_enchanting_supports/_distributions + equip_slot_enchanting_costs tables; SCGradeEnchantResult/Broadcast G2C confirmations; GradeEnchant refs in ItemManager. Own dossier pending |
| SOCKET-01 | Gem socketing: insert lunastones/lunagems into gear sockets with per-grade chance/level limits | Later | U | U | U | U | U | U | NEW 2026-08-25 (census §3#2): item_sockets/_chances/_level_limits/_num_limits + item_enchanting_gems; SCItemSocketingLunastone/LunagemResult packets. Own dossier pending |
| GLIDER-01 | Glider flight: deploy/hang/unhang gliders (incl. costume wings-as-glider) for controlled aerial traversal | M7+ | U | U | U | U | U | U | NEW 2026-08-25 (census §3#3): CSHang/UnhangPacket, flying_state_change_effects; glider traces in ItemDetailType/BackpackType/UnitRequirementsGameData; no dedicated manager. Own dossier pending |
| MUSIC-01 | Music: compose MIDI songs in-game, save/share notes, perform via instruments with note limits | M9 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#4/§4#2): MusicIdManager/MusicManager full surface (SaveSong/UploadSong/CreateSheetMusic/MIDI cache) + 4 CS/2 SC packets; wiring surprise: music_note_limits 0% wired. Own dossier pending |
| CASHSHOP-01 | In-game cash shop (ICS): browse SKU menus, buy goods with credits, credit dispersion | M9 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#5): CashShopManager built out (SKUs/ShopItems/MenuItems/CreditDisperseTick); CSICS* ×4, BuyCoinItem, SCICSCashPoint. Own dossier pending |
| PREMIUM-01 | Premium/patron service: purchase premium status granting benefits (labor cap 5000, point accrual, perks) | M9 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#6): PremiumServiceBuy/List/Msg + PayChargeMoney + SCPremiumPoint* wired; wiring surprise: all four premium_* tables ZERO-wired while the premium labor cap is hardcoded in TimedRewardsManager. Own dossier pending |
| ACHIEVEMENT-01 | Achievements: track completion objectives, grant rewards/items, notify client | M9 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#7/§4#1): wiring surprise — achievements + pre_completed_achievements already 100% data-wired with AchievementGameData loader and five G2C packets, yet never entered the ledger. Own dossier pending |
| ACTABILITY-01 | Actability (vocations): proficiency gain per activity + expert-limit expansion/upgrade/downgrade purchases | M4 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#8): actability_categories/groups, deco_/loot_actability_groups, expert_limits, expand_expert_limits; Expand/Upgrade/DowngradeExpertLimit opcodes; audit scope merges with LABOR-01 (ChangeLabor already grants actability XP). Own dossier pending |
| APPELLATION-01 | Appellations: earn titles from quests/achievements and equip one for display/stats | M9 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#9): appellations 100% wired; CSChangeAppellation; quest_act_supply_appellations. Own dossier pending |
| FACTION-01 | Reputation factions: standing with system factions, declare hostility, immigrate between origins | Later | U | U | U | U | U | U | NEW 2026-08-25 (census §3#10): system_factions/_relations + FactionManager; DeclareHostile + 4 immigration opcodes exist but are log-only stubs (cross-ref pvp-domain.md §5.2). Own dossier pending |
| PORTAL-01 | Portal/teleport network: register portal book points, recall, use teleport reagents, nui/navi teleports | M4 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#11): PortalManager, return_points/district_return_points; UsePortal/UseTeleport/DeletePortal/NaviTeleport family; SCCharacterPortals/SCPortalInfoSaved; radar/navi map plumbing folded into this scope. Own dossier pending |
| UCC-01 | UCC creativity: upload custom emblems/text via stream channel, imprint onto items/doodads/sails | M9 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#12): full CT* stream UCC protocol (upload/download), ucc_applicables, imprint_/cleanup_ucc_effects, CSSaveDoodadUccString, SCItemUccDataChanged. Own dossier pending |
| BUFF-01 | Buff framework as player-facing layer: gains, stacking, tolerance, dispel, mount/combat buff interactions | M2/M5 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#13): buffs domain 10 tables 70% wired incl. buff_effects/modifiers/triggers/tolerances/mount_skills; LearnBuff/RemoveBuff opcodes — cross-cutting role, no prior row despite every combat system depending on it. Own dossier pending |
| LOOT-01 | Loot: drop-pack rolls, personal/free-for-all/dice group rules, bag opening | M2/M5 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#14): loots/loot_groups/loot_pack_dropping_npcs 100% wired; LootOpenBag/LootItem/LootDice/RollDice + ChangeLootingRule opcodes. Own dossier pending |
| STORAGE-01 | Storage: bank/coffer access via doodads, item split/swap in coffers, money deposit/withdraw | M3b | U | U | U | U | U | U | NEW 2026-08-25 (census §3#15): DoodadCoffer model; CSCofferInteraction/SwapCofferItems/SplitCofferItem; doodad_func_bank_uis/coffers/coffer_perms; Deposit/WithdrawMoney already exercised by the m8 economy cycle. Own dossier pending |
| BAGEXPAND-01 | Bag expansion: purchase extra inventory/bag slots (bag_expands tiers) | M4 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#16): bag_expands table + CSExpandSlotsPacket; default_inventory_tabs/tab_groups. Own dossier pending |
| REPAIR-01 | Repair: restore durability on worn gear, pet items, slave equipment, and placed property | M4 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#17): RepairAllEquipments/RepairSingleEquipment/RepairPetItems/RepairSlaveItems opcodes; PropertyRepairService + PropertyRepairScanner; repairable_slaves. Own dossier pending |
| BEAUTY-01 | Beauty salon: paid appearance edits (face/hair/skin/custom presets) outside character creation | M9 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#18): CSBeautyshopData/Enter/ExitBeautySalon; SCToggleBeautyshopResponse; character_customizing_hair_assets/custom_face_presets/hair_colors/skin_colors/face_*_maps/total_character_customs. Own dossier pending |
| APPEARANCE-01 | Item look-change (transmog drops) and armor dyeing with dye colors | M9 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#19): item_look_converts family ×4 tables; CSChangeItemLook/ConvertItemLook; item_dyeings/dyeable_items/dyeing_colors. Own dossier pending |
| SOCIAL-01 | Social graph: friends, family (shared-cost guild-lite), blocklist, player inspect/detail | M7/M8 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#20): FriendMananger + FamilyManager; full friend/family/block opcode sets; CSCharDetail/RequestCharBrief. Own dossier pending |
| EMOTE-01 | Emotes: expressive character animations with express-text templates | M8 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#21): express_texts 100% wired; ExpressTextManager (incl. stray-space filename quirk); CSExpressEmotionPacket. Own dossier pending |
| INSTANTGAME-01 | Instanced arenas/battlefields: apply/join, scoring, killstreaks, end rewards | M7+ | U | U | U | U | U | U | NEW 2026-08-25 (census §3#22): InstantGameManager; battle_fields 50% wired; Apply/Join/Cancel/LeaveInstantGame + EnteredInstantGameWorld; SCInstantGameStart/End/Kill/Killstreak/AddPoint; upstream #1323 arena-scoring bug noted. Own dossier pending |
| RANKS-01 | Rankings: periodic leaderboards (combat/economy scopes) with reward mail-outs | M9/M10 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#23): ranks/rank_rewards/rank_scope_links/rank_scopes all ZERO-wired (zero-data-wired list); SCRankAlarmPacket. Own dossier pending |
| TOWERDEF-01 | Tower-defense events: wave-based base defense with progress targets per zone | M9/M10 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#24/§4#5): wiring surprise — silently the BEST-WIRED missing system: all four tower_def_* table groups 100% wired, TowerDefGameData loader, full SCTowerDef List/Start/WaveStart/End family, no row anywhere until now. Own dossier pending |
| RACETRACK-01 | Race tracks: scheduled mount/vehicle races on shaped circuits | M10 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#25/§4 honorable mention): race_tracks/race_track_shapes tables present with ZERO .cs references — the purest canonical-data-without-code gap found. Own dossier pending |
| BOOK-01 | Readable books: lore pages collected/read in-world | M9 | U | 0 | U | 0 | U | U | NEW 2026-08-25 (census §3#26); **verified UNWIRED 2026-08-31** (`mechanics/undefined-world-mechanics-2026-08-31.md`): books 72 / book_pages 1206 / book_page_contents 1873 (Korean lore text) / book_elems 846; `item_open_papers` 551 rows (551 distinct items, 541 valid `book_page_id` links; 491 quest-category, 53 book; e.g. 29236 → book 10, 29237 → book 11, 20031 → page 66). `ItemImplEnum.OpenPaper=23` has **no item handler**, **no book-render packet** exists, and `DoodadFuncOpenPaper` is a Logger.Trace no-op — the full readable-book content graph and item→page links are unreachable in-game. Data-only / unwired. W=0/A=0; H=UNKNOWN |
| CINEMA-01 | Cinematics/tutorials: quest-triggered camera scenes with captions/subtitles | M9 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#27): cinemas/cinema_captions/subtitles/effects (long-standing "cinema zero-wired" watch item); Started/CompletedCinema opcodes + CSSaveTutorial. Own dossier pending |
| GATHER-01 | Wild-node gathering: logging/mining/herbalism/soil gathering on natural spawn nodes (labor-gated, distinct from FARM-01 planting) | M3 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#28): doodad_func_ore_mines/rock_mines/fiber_collects/soil_collects/tree_byproducts_collects/seed_collects/spice_collects/medicalingredient_mines/crystal_collects. Own dossier pending |
| TAX-01 | Taxation: recurring house tax bills, payment windows, national/dominion tax rates | M3 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#29): taxations 100% wired, TaxationsManager; ConstructHouseTax/RequestHouseTax/ChangeHousePay; SCHouseTaxInfo + National/DominionTaxRate packets; MailForTax weekly bills ride MAIL-01. Own dossier pending |
| PRIESTBUFF-01 | Priest blessings: purchase temporary priest buffs at shrines/vendors | M9 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#30): priest_buffs table + CSBuyPriestBuffPacket. Own dossier pending |
| PUBLICFARM-01 | Public farms: shared community farmland where anyone may plant/harvest with risk | M3 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#31): common_farms/farm_groups; PublicFarmManager. Own dossier pending |
| ACTIONBAR-01 | UI persistence: action-slot layouts, hotkeys, and client UI data saved server-side | M2 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#32): CSUpdateActionSlot; hotkeys/default_action_bar_actions; SaveUIData/RequestUIData session opcodes. Own dossier pending |
| MOULD-01 | Mould/stamp crafting: craft stamp kits to imprint designs onto furniture/paper (UCC-adjacent) | M9 | U | U | U | U | U | U | NEW 2026-08-25 (census §3#33): mould_packs/_pack_items/moulds ZERO-wired (zero-data-wired list); doodad_func_stamp_makers/mould_items/moulds. Own dossier pending |

Add mechanics as SQL/code/runtime exploration reveals them; use stable IDs so
> **2026-08-28 source/evidence checkpoint:** current source/test audit baseline is
> `7a572c08a32162988dedbf400bd9f8b608fb1974` (`origin/develop`). The full
> normal-clone gate cited in historical evidence remains at source/test HEAD
> `792774d7707b8b578b8d9975896e0a1ac719f361`: **2496 total / 2495 passed / 0
> failed / 1 skipped**, compiler **0/0**, MCP stdio **39 tools**. The sole skip
> is `Provision_Activate_Persist_Deactivate_RoundTrip`, requiring
> `AAEMU_LIVE_RIG=1` and `AAEMU_E2E_DB_PASSWORD`; no different full-gate count
> is claimed for the 7a572 audit. Runtime evidence uses `E2eStack.SourceRevision`
> with unknown fallback.
>
> **M1 loop closure:** the player loop is clean Nuian Solzreed quest discovery,
> ordinary objective pursuit and turn-ins, first-mount unlock, and restart
> persistence. `LevelingLoopScenario` closes only the bounded autonomous
> 254→255 PlayerBot loop (`Observe → Discover → legal lowest-level choice →
> objective pursuit → turn-in → re-discover`): focused test **1/1** and
> `LevelingLoopScenarioRigTests` **7/7** at source/test baseline
> `7a572c08a32162988dedbf400bd9f8b608fb1974`, using the existing
> `scorecard-explorations/generated/leveling-loop-2026-08-25.md` report and
> JSONL trace. `M1M2ReplayScenario` remains an ordered scripted proxy
> (16 quests, 55 fixture actor records, fixture `Level=6` setup, no real-mount
> criterion); it does not close full-route autonomous decision parity.
> Josh's first-mount, restart, Bloody Hand, bounty-board, and client-feel
> checks remain separate H/UAT.
>
> **PB-002 interaction candidate:** landed item-use facts remain unchanged:
> `QuestActObjItemUse` through real `GameplayActor.UseItem` for quest 252 (NPC
> 7653, item 7738, use skill 11596, act row 1600/detail 43) and fail-closed
> quest 64 control. The canonical interaction candidate failed for quest 270,
> doodad 687, interaction skill 11229: the real path reaches `Doodad.Use`, but
> the spawned fixture exposes no phase functions. No implementation landed;
> the broad PB-002 claim remains open.
>
> **PB-007 narrow closure:** the live handshake result is behavioral evidence
> at baseline `3871459d142fdd1767b9365a1de8d4cd3652ab0e`; current source/test
> HEAD is `792774d7707b8b578b8d9975896e0a1ac719f361`. The checked-in report and
> historical failure context remain preserved; WAR-HONOR remains deferred.
>
> **Soak boundary (historical wording superseded):** the six-hour dormant-timer
> canary DID execute and produced
> `/root/aaemu-e2e-a5-tier3-sixhour/logs/g2-a5-tier3-sixhour-report.json`
> (360.00003 minutes / 361 samples). It is a testing/canary diagnostic failure:
> RSS assertion failed on the pre-quiescence baseline (1207.9MB baseline,
> 5749.4MB peak, 3744.1MB final, budget +512MB), not yet classified as a leak.
> A5 pass, live human gameplay, and H evidence are not claimed. Correction
> `ccd4ea857` adds `A5_WARMUP_READY`, post-quiescence baseline, startup-peak
> separation, fail-fast post-baseline RSS breach, and FULL/PARTIAL semantics;
> a preferably 12-hour corrected rerun remains pending. Historical ownership
> details and prior failed report/log provenance remain preserved.
> **Corrected 12-hour testing/canary soak (2026-08-30, SHA
> `1ce4664f96705850136dc9d46999070fac9763fb`):** FULL — 720.000044 minutes /
> 721 samples; DormantSpecs 1000/1000, embodied 0, materializations/
> dematerializations 0, scheduler queues/failures/save-skips 0, DB writes 0,
> RSS baseline 2383.4MB, startup peak 2471.3MB, steady peak 2539.3MB, growth
> 155.9MB < 512MB. `passed=false` on timing only: seven distinct breach
> samples (six failure strings after dedupe) — region 299/288/308/291/297/291ms
> (budget 200) and tick max 282.9ms (budget 250). Triage: 571 ActiveRegionTick
> overruns in the 12h game log (570 in window), recurring ~76s cadence,
> 566/571 same-second with physics-slow warnings, deferred 0 characters;
> physics 278–554ms tracks the stalls. Classification **UNKNOWN / host-level
> physics-thread stall versus scheduler/host steal** — not a confirmed code
> regression, not a pass. Next: isolate/inspect testing-host CPU steal and
> physics-thread diagnostics, bounded timing reproduction; budgets not
> relaxed. Warmup correction validated; timing triage remains open. Evidence
> is testing/canary operational, not live human gameplay.
> **2026-08-26 recovery scorecard update (develop @ e5db6d390):** recovery
> contents are confirmed on develop: grounding `38c4997d3`, recovered
> Retribution wire-test merge `a4f7820ba`, and merchant merge `e5db6d390`;
> earlier committed wave-7 features remain in ancestry. G3-B5 scenario library
> and PLAYER_MODE/TEST_MODE leakage audit remain DONE (7 scenarios indexed;
> all three seams proven unreachable with 6 negative tests). DOMINION-01
> slice-1 remains LANDED (tax round-trip, phase cron, kill -9 persistence;
> combat deferred).
>
> **PB-005 grounding = FIXED-PARTIAL:** positive-only clamp + intentional
> aerial/water/structure whitelist are landed; terrain-only replay corrected
> 593 non-whitelisted severe-positive rows and left 702 whitelisted rows
> unchanged. Cave/deck/submerged behavior and duplicate-row decisions remain
> open; no grade inflation.
>
> **Historical PB-007 context (2026-08-26, retained):** the prior rig-only
> result and immune-tagged/untrusted live result did not satisfy the narrow
> victim-matched non-immune `SCUnitDamaged` requirement; the current
> source-pinned report above supersedes that status without claiming all PvP or
> honor scope complete.
> The merchant trio is landed (funds gate `cb514c42`, buyback refund
> `beaf9b82e`, grant-failure rollback `3ba33b3af`, merged by `e5db6d390`) and
> the live economy conservation E2E passed across kill -9 restart. MERCHANT-01
> remains W=2/A=2 with **H=U**. Mail S3 is incomplete/uncommitted in
> `.worktrees/mails3`; no Mail S3 grade is claimed. H stays UNKNOWN everywhere.
> **2026-08-26 Mail S3 recovery note (commit `31045d033`, evidence):** the
> previously incomplete/uncommitted attach-item slice is now landed and
> accepted by the authenticated real-packet E2E
> `MailS3RestartE2eTests.Mail_EquipmentAndCopper_SurviveRestart_AndTakeByRealPackets`
> (PASS 1/1, 2m39s, isolated MySQL/Docker). It covered
> `CSSendMailPacket`, mailbox proximity, kill-9/restart, `SlotType.Mail=5`,
> receiver retargeting, unread recount after world registration (1), read
> transition (1→0), `CSListMail`/`CSReadMail`,
> `CSTakeAttachmentSequentially`, exact instance detail/grade/durability/
> rune/temper fidelity, copper transfer, and `CSDeleteMail` persistence
> deletion. Ownership guards are landed. This supersedes the prior
> "uncommitted" status while preserving the earlier return/expiry and
> security findings; `0x0a2` remains STRONGLY_INFERRED pending real-client
> capture, and COD/expiry gaps remain open. The lifecycle fix moves unread
> recount until after `TryAddCharacter` and before human client
> initialization.
> **2026-08-25 scorecard update (completeness-census wave, through develop @
> 214bed834):** master mechanic inventory landed
> (generated/mechanic-inventory-2026-08-25.md) — 65 canonical player-facing
> 1.2 systems enumerated across opcodes/data/managers vs 31 previously
> tracked; **33 NEW stable-ID rows added to the Global mechanic ledger above**
> (REGRADE-01 … MOULD-01, all dimensions U pending their own exploration
> dossiers → ledger coverage 64/65 ≈ 98%). Census wiring surprises promoted
> into evidence cells: ACHIEVEMENT-01 tables 100% data-wired (loader + 5 SC
> packets), TOWERDEF-01 all four tower_def_* groups 100% wired (best-wired
> missing system), music_note_limits/premium_*/ranks/moulds zero-wired, race
> tracks zero .cs references · Grade promotions from today's six domain
> dossiers — MERCHANT-01 W=2/A=2 (the stale row's wiring/live evidence was
> promoted here; at that point the funds-gate `&&`, buyback
> refund-on-refused-move, and grant-failure bugs were documented OPEN, then
> fixed and merged in the 2026-08-26 recovery) · CRIME-01 + TRIAL-01 C=2
> (justice-domain: managers fully wired, packet tables complete/near-complete;
> W stays 1 — zero E2E proof; prison labor/escape honestly absent) · PVP-01
> C=2 (pvp-domain: CanAttack chokepoint ordering + honor formulas + faction
> storage reconstructed; W stays U until the flagged-aggression E2E) ·
> Evidence notes: MAIL-01 ownership-check gaps (4 of 5 receive paths lack
> ReceiverId checks — security-grade finding) + instance-faithful attachment
> verdict (mail-domain); INDUN-01 exit path proven (PB-003 closed,
> party-clear-then-exit E2E 11/11); DUEL-01 bounds resolved (flag doodad
> 5014 + hardcoded 75 m poll — geodata caveat reduced). H stays UNKNOWN
> everywhere (hard rule — never recorded as H=2).

> **2026-08-24 scorecard update (through develop @ cab6e4dc9 → f8252a37b):**
> FISH-01 promoted W=2/A=1 — fishing dossier + CastAt(position) contract
> action + FishingVerificationE2eTests LIVE PASS (labor/worm/proficiency/loot
> through plot 809) · DUEL-01 promoted W=2/A=1 — headless lifecycle rig +
> stuck-duel bug found & fixed (faction-restore NRE in the stop catch-all) ·
> EXPEDITION-01 promoted W=2/A=1 — full lifecycle headless rig through the
> real ExpeditionManager · QUEST-01 evidence note — ConReportJournal wired-
> noop fixed (466 quests gated on the journal report auto-passed; 59 instantly
> completable) + ConReportDoodad FinalizeQuest double-subscribe leak;
> golden-route contract replay re-PASS on current tip · M1/M2 sweep: quest act
> audit of all 50 families — no other stubs; ConAcceptComponent flagged
> NOVEL-MECHANICS (Josh design call).

> **2026-08-24 scorecard update (through develop @ 3a534b539):** ZONE-01
> promoted W=2/A=1 — data-driven Peace boot state + Peace PvP protection at the
> BaseUnit.CanAttack chokepoint; state machine + enforcement tested rig-level,
> no live PvP scenario yet · MATE-01 promoted W=2/A=1 — mate equip-pack data
> loaded + fail-closed IsMateEquipAllowed legality rig-tested, no live equip
> E2E · TRANSFER-01 promoted W=2/A=1 — CSBoardingTransferPacket TlId shadowing
> fixed; TransferRideE2eTests live board/ride/disembark PASS · ITEM-01 evidence
> note — item_proc_bindings loader + UnitProcs factory seam (grades
> conservative) · HOUSING-01 evidence note — two-thread build-race regression
> added (grades unchanged) · BOT-02/scheduler-soak note — STAGE 1 executed
> (~90k steps, 0 failures; staged ladder continues). H stays UNKNOWN everywhere
> (hard rule — never recorded as H=2).

> **2026-08-23 scorecard update (through develop @ f3bb787ce):** AUCTION-01
> promoted W/A/R = 2 — live E2E incl. kill -9 restart pin, strongest of the
> sweep · TRADE-01 W=2/A=1 via trade handshake rig + engine fixes (A stays
> honest: rig-level) · PARTY-01 W=2/A=1 via the party spike live E2E
> (c98da8a53) · MAIL-01 A=1 — return + expiry implemented and rig-tested
> (CSReturnMailPacket opcode still an unregistered 0xfff placeholder) ·
> QUEST-01 evidence note: EtcItemObtain credit path closed (~51 live quests).
> H stays UNKNOWN everywhere (hard rule — never recorded as H=2).

## Zone and instance content coverage

Global mechanics and local content are orthogonal. A zone report references
the global mechanic IDs it exercises, then grades its own content surfaces:
quest chains; NPC spawns; Doodad spawns/interactions; merchants/services;
spheres/triggers; transfers/portals; terrain/navigation/spawn-Z; human route;
and restart behavior. Main-world coverage uses the canonical zone-group ID when
known plus every member zone key; instances use the exact
`Data/Worlds/instance_*` key. Do not use a free-form zone name as the only
identifier.

| Zone key | Scope | Quests | NPCs | Doodads | Services | Triggers/transfers | Nav/terrain | Human | Restart | Evidence |
|---|---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|---|
| Solzreed / zone keys `9,124,125` (group ID to verify) | M1-M4 golden route | 1 | U | U | U | U | 1 | U | U | `Golden-Route-Solzreed.md`; `runnability.md`; `spawn-z-fix.md` |

Create one row/report per audited zone or instance. Do not expand every map
area up front: prioritize the golden route, adjacent travel/trade zones, then
zones required by a milestone or an observed defect.

## Domain scorecard

| Domain | Tables | Data-wired | % | Managers |
|--------|--------|-----------|------|----------|
| misc | 206 | 114 | 55% | — |
| doodads | 135 | 123 | 91% | DoodadIdManager, DoodadManager |
| quests | 85 | 70 | 82% | QuestIdManager, QuestManager |
| items | 53 | 31 | 58% | — |
| npcs | 18 | 12 | 67% | NpcManager |
| fx-visuals | 15 | 0 | 0% | — |
| slaves | 15 | 9 | 60% | SlaveManager |
| instances | 14 | 14 | 100% | — |
| buffs | 10 | 7 | 70% | — |
| skills | 10 | 5 | 50% | SkillManager, SkillTlIdManager |
| spheres | 10 | 9 | 90% | SphereQuestManager |
| equipment | 9 | 6 | 67% | — |
| housing | 8 | 3 | 38% | HousingIdManager, HousingManager, HousingTldManager |
| plots | 6 | 6 | 100% | PlotManager |
| characters | 5 | 3 | 60% | CharacterIdManager, CharacterManager |
| crafting | 5 | 4 | 80% | — |
| siege | 5 | 0 | 0% | — |
| loot | 4 | 4 | 100% | — |
| mates | 4 | 0 | 0% | MateIdManager, MateManager |
| merchants | 4 | 2 | 50% | — |
| premium | 4 | 0 | 0% | — |
| ranks | 4 | 0 | 0% | — |
| specialty-trade | 4 | 3 | 75% | — |
| towerdefense | 4 | 4 | 100% | — |
| transfers | 4 | 4 | 100% | TransferManager |
| zones | 4 | 3 | 75% | ZoneManager |
| auction | 3 | 0 | 0% | AuctionIdManager, AuctionManager |
| bubbles | 3 | 1 | 33% | — |
| models | 3 | 0 | 0% | ModelManager |
| moulds | 3 | 0 | 0% | — |
| shipyards | 3 | 2 | 67% | ShipyardIdManager, ShipyardManager |
| world | 3 | 0 | 0% | WorldIdManager, WorldManager |
| achievements | 2 | 2 | 100% | — |
| battlefields | 2 | 1 | 50% | — |
| combat | 2 | 1 | 50% | — |
| race-tracks | 2 | 0 | 0% | — |
| sounds | 2 | 0 | 0% | — |
| appellations | 1 | 1 | 100% | — |
| express-text | 1 | 1 | 100% | — |
| fishing | 1 | 1 | 100% | — |
| gimmicks | 1 | 1 | 100% | GimmickIdManager, GimmickManager |
| music | 1 | 0 | 0% | MusicIdManager, MusicManager |
| taxation | 1 | 1 | 100% | TaxationsManager |

> Quest-runnability (M2a/M2c + WI-2 + WI-3 + WI-4 + WI-5 + WI-7 + WI-8 + WI-9 + WI-11b + WI-12, band 0-55 + lvl-99 straggler census 2026-08-10, FINAL G1 CENSUS on merged develop): **4573/4573 quests runnable, 0 FAIL, 14 documented SKIP** across the
> 4587-quest scenario-harness census (297 dropped quest_contexts rows excluded — 305 registered drops, 8 of which are orphaned contexts without rows; register is the source of truth). Denominator reconciliation (WI-12): 4,876 quest_contexts rows − 297 registered drops = **4,579 live contexts** = 4,573 PASS + 6 kept-by-ruling doc-SKIP (3419/4967 ltd, 315/1576/1728/2046 no-components), 0 unexplained; the G1 audit estimate 4,735 (4,876 − 141) shrinks by the WI-6 drop (6069, −1) and WI-11a drop (−155) to the final 4,579 — every live context is PASS or registered-drop or documented-SKIP, zero unexplained FAIL/SKIP. **Band 1-10: 560 PASS / 0 SKIP / 0 FAIL = 100.0% PASS-or-doc-SKIP** of
> 560 non-dropped (668 − 108 dropped). **Band 11-20: 609 PASS / 0 SKIP / 0 FAIL = 100.0%** of 609 non-dropped (626 − 17 dropped).
> **Band 21-30: 847 PASS / 0 SKIP / 0 FAIL = 100.0%** of 847 non-dropped (0 dropped).
> **Band 31-40: 643 PASS / 0 SKIP / 0 FAIL = 100.0%** of 643 non-dropped (0 dropped) — the WI-7 T13 sweep drove all 643 contexts (631 in t13, 12 sampled in earlier tiers), zero harness SKIPs as predicted.
> **Band 41-50: 1589 PASS / 2 SKIP / 0 FAIL = 100.0% PASS-or-doc-SKIP** of 1591 non-dropped (1592 − 1 dropped, 6069 WI-6) — the WI-8 T14 sweep drove all 1591 contexts (1528 in t14, 63 sampled in earlier tiers); the 2 SKIPs are 3419/4967 (let-it-done without report act — Josh NO-GO keep ruling, WI-6 register §8).
> **Band 51-55: 268 PASS / 0 SKIP / 0 FAIL = 100.0% PASS-or-doc-SKIP** of 268 non-dropped (0 dropped) — the WI-9 T15 sweep drove all 268 contexts (264 in t15, 4 sampled in earlier tiers: 6095 t3 / 6578 t2 / 6600 t2 / 6615 t2).
> **Lvl-99 straggler 3465: 1 PASS / 0 SKIP / 0 FAIL = 100.0%** (1 non-dropped) — top-level quest outside every banded tier; a no-acts shell (4 components, 0 acts) that the harness walks Start→Progress→Ready→Reward→Persist via the empty-comp auto-pass path, verdict PASS.
> **Band 0/null (WI-11b + WI-12, 2026-08-10, t_8ec705f0): 59/60 contexts driven in the new t16 tier (56-context sweep handoff D2/D3/D4/D5 + the 4 A2 keeps; 6250 rides T3 = 60/60 accounted) — 56 PASS / 0 FAIL / 4 SKIP = 100.0% PASS-or-doc-SKIP.** D2 old Sunny (13/13 PASS — act-less superseded line, vacuous shells); D3 tutorial sphere steps (12/12 PASS — 33 accept-sphere acts reference spheres 1982-2014, ALL present in the spheres table; 2617-2619 are single empty Start comps the engine completes via the kind-chain walk; 11 of the 33 sphere_quests rows (1098-1130) reference sphere ids missing from the spheres table — inert data, the engine consumes sphere ids from the accept acts, not sphere_quests); D4 real content (22/22 PASS — Cradle chain 1394-1485, Blue Salt 5307-5314, dailies 5459/6222/6223/8000004, event/title/library quests all drive full lifecycle; 6250 already PASS in T3; **8000004 flipped FAIL→PASS after BUG-014 fix merged @ 4b73b63ac**); D5 test/dummy (9/9 PASS); A2 unit-req keeps (4 SKIP "no components" — zero-component shells kept by Josh's Q2 NO-GO ruling, documented in the triage doc §3 A2, not dropped). The WI-11b first-sweep FAIL was quest 8000004's RESET fidelity stage — **BUG-014 (REAL engine defect)**: the completed-block id is a ushort key and `(ushort)(8000004/64)` wraps 125000 → 59464, so ResetDailyQuests recomputes questId 3,805,700 and can never clear the completed bit for quest ids ≥ 4,194,304 — 8000004 is permanently daily-locked after first completion (bugs/014-quest-completed-block-ushort-wrap.md; repro probe + evidence on the card). **FIXED 2026-08-10 (t_8b47a3bf, fix/bug-014-quest-completed-block-uint @ 4b73b63ac): completed-block key ushort→uint, Rei gate PASS (t_5c09fdf9, isolated clone, 5/5 rig incl. HighIdDailyQuest pin, full gate 1494/0/1), merged to origin/develop.** Two harness/generator calibrations were required to sweep band 0: (1) NULL LEVEL (quest 1576) now normalizes to 0 exactly like the engine (GetByte("level", 0), QuestManager.cs:565) — a null template.level crashed the C# byte deserializer; (2) the rig character's level is clamped to ≥1 (max(1, template.Level)) because the engine's exp curve explicitly rejects level-0 units (GetLevelFromExp ThrowIfZero, ExperienceManager.cs:76) — a level-0 character completing a SupplyExp reward (6229/6314/6355) threw; the template keeps the data-true level 0. All 56 sweep contexts accounted: 55 driven in t16 (all PASS post-fix) + 6250 in t3 (PASS). No drops decided or executed in this card.
> All SKIPs documented-SKIP with reason (14): 8 orphaned contexts (no quest_contexts row; 6069 was the
> let-it-done-without-report-act SKIP but is now DROPPED — WI-6 triage ruling 2026-08-09, register §8,
> drop execution t_6810ebd4, merged t_ec1a3326) + 2 kept-by-ruling ltd quests (3419/4967, WI-8 census) + 4
> kept-by-ruling no-components (315/1576/1728/2046, WI-11b A2 keeps — zero-component shells, do-not-delete
> labels, triage doc §3 A2) — the WI-2
> CrimePoint closure closed the last 2 census SKIPs (2916/2926) and added the t9 tier so the five level-41-50
> carriers (2935/2936/5197/5198/5494) are sampled and PASS — 7/7 CrimePoint contexts driven; the WI-3 AbilityLevel
> closure closed the AbilityLevel objective family and added the t10 tier so the nine level-50 single-ability
> carriers (6070/6075-6082) are sampled and PASS — 10/10 AbilityLevel contexts driven (6069 dropped, not counted),
> 5967 (all-abilities branch) flipped SKIP→PASS; the WI-4 MateLevel closure added the t11 tier so the four level-50
> carriers (5465/5466/5812/5813) are sampled and PASS — 6/6 MateLevel contexts driven (5430/5464 flipped
> SKIP→PASS in T3; 6015 is an orphaned context, excluded from t11 so the census gains no new orphan SKIP); the
> WI-5 CompleteQuest closure added the t12 tier so the nine level-50 carriers (5816-5821/5862/5868/5911) are
> sampled and PASS — 11/11 CompleteQuest contexts driven (5814/5815 flipped SKIP→PASS in T3). Band-21-30 sweep
> calibration: kind_id-1 None components (legacy task-board
> step, engine walks Start→None→Supply) now emitted as "None" — 5 quests flipped FAIL→PASS (275/281/305/371/604).
> Wave-1+2 closures flipped 73 SKIP→PASS cumulative (36 wave-1 + 37 merged-line incl. 1702 multi-gap); wave-3
> ZoneKill closure flipped 23 more (73 + 23 = 96 cumulative); WI-2 CrimePoint closure flipped 2 more census SKIP→PASS
> (2916/2926) + 5 unsampled carriers → 7/7 driven (98 cumulative); WI-3 AbilityLevel closure flipped 5967 + 9
> unsampled carriers → 10/10 driven (108 cumulative, 6069 dropped not counted); WI-4 MateLevel closure flipped 5430/5464 + 4 unsampled
> carriers → 6/6 driven (114 cumulative); WI-5 CompleteQuest closure flipped 5814/5815 + 9 unsampled carriers →
> 11/11 driven (125 cumulative); WI-7 T13 sweep drove band 31-40 643/643 PASS (631 new t13 manifests, 12 sampled
> earlier) with zero harness SKIPs as predicted; WI-8 T14 sweep drove band 41-50 1591/1591 PASS-or-doc-SKIP
> (1528 new t14 manifests, 63 sampled earlier, 6069 dropped excluded) — 1589 PASS / 2 SKIP (3419/4967 kept-by-ruling) /
> 0 FAIL; WI-9 T15 sweep drove band 51-55 268/268 + the lvl-99 straggler 3465 = 269/269 PASS-or-doc-SKIP
> (264 new t15 manifests + 3465, 4 band contexts sampled earlier: 6095/6578/6600/6615) — 265 PASS / 0 SKIP / 0 FAIL,
> zero first-sweep FAILs and zero new SKIPs (3465 is a no-acts shell; the band's 6 CheckTimer carriers 6108/6131/6154/
> 6162-6164 PASS via the auto-pass kind — WI-10 owns driver-fidelity for that family); the 10 first-sweep FAILs were TWO harness expectation-model gaps + ONE real engine bug, all fixed with
> engine-source evidence: (1) score-quest under-credit — generator fired count events but the engine score branch
> needs Σ Count×Objective ≥ Score (MaxObjective = Score/Count+1 proves the data intends objectives beyond the
> displayed count); now fires scaled events (7 quests: 3076/3089/3625/4343/5062/5063/5064); (2) Ready-step OR
> semantics — QuestComponent.RunComponent ORs Start/Ready acts, so an always-true act (SupplyRemoveItem) advances
> past Ready without the report event (5174/5722); (3) QuestActConReportJournal subscribed in InitializeAction
> (step-entry) instead of InitializeQuest (ctor) like its ReportNpc/ReportDoodad siblings — ltd quests stuck at
> Progress never enter Ready, so the journal report could never fire (3630); subscription moved to ctor, sibling
> pattern. zero PASS→SKIP regressions across every sweep. WI-10 (2026-08-10, t_abafd918) added driver-fidelity
> probe stages to the census manifests: TIMEOUT (37 CheckTimer quests — driver fires the timeout task's exact
> body QuestManager.OnTimerExpired on a fresh probe and asserts FailQuest; 7 ineligible engine-grounded: 6 rest
> at Ready so the timer is already removed at end-state entry, 1897 never enters the CheckTimer comp), RESET
> (602 daily/repeatable quests — engine ResetDailyQuests + AddQuest re-accept, QuestDailyLimit gate; detail
> Daily 7/DailyHunt 10/DailyLivelihood 11/DailyGroup 12 = the exact set ResetDailyQuests clears), GUARD_DIED
> (3 escorts — dead-guard probe per BUG-008 semantics: RunAct false ⇒ stall at the guard kind; 1313 skipped
> engine-grounded: Start comp ORs its acts so the always-true CheckTimer carries the step). 642 probe stages
> all PASS on the merged census — 4518/4518 runnable, 0 FAIL, 10 documented SKIPs unchanged. New rig pins:
> QuestCheckTimerRigTests 2/2 (timer registered at accept → expiry fires FailQuest), QuestDailyResetRigTests
> 4/4 (completed daily refused → ResetDailyQuests clears → re-accept; repeatable re-accepts immediately),
> QuestCheckGuardRigTests 3/3 (alive → true; dead → false + stall; npcId-0 unresolvable → false + stall).
> Census regen deterministic (byte-identical ×2); band denominators + zone coverage (Gweonid/Lilyut/Mahadevi/
> Tiger Spine/Falcony/Sunny Wilderness/Ancient Forest/Marionople/Two Crowns/White Forest/Singing Land/Sunrise
> Peninsula) in runnability.md (census-meta.json-driven). Fail-before states on the
> wave-1/wave-2 rig commits (2283c0df/7a1145be). Watch items: EtcItemObtain engine no-op, cinema zero-wired,
> honor zero-wired (zero-wired-domains.md), ZoneKill ZoneId unenforced (§2.4, zero-wired-domains.md §9).
> See scorecard-explorations/runnability.md + zero-wired-domains.md §8/§9.

## Zero-data-wired domains (data exists, server ignores it)

- **fx-visuals** (15 tables): fx_cam_fovs, fx_cgas, fx_cgfs, fx_chrs, fx_decals, fx_group_fx_items...
- **siege** (5 tables): siege_items, siege_plans, siege_settings, siege_ticket_offense_prices, siege_zones
- **mates** (4 tables): mate_equip_pack_groups, mate_equip_pack_items, mate_equip_packs, mate_equip_slot_packs — **WIRED 2026-08-24 (0482ba3f0):** all four loaded in MateGameData; fail-closed equip legality at MateEquipmentContainer.CanAccept (MATE-01 W=2)
- **premium** (4 tables): premium_benefits, premium_configs, premium_grades, premium_points
- **ranks** (4 tables): rank_reward_links, rank_rewards, rank_scope_links, rank_scopes
- **auction** (3 tables): auction_a_categories, auction_b_categories, auction_c_categories
- **models** (3 tables): model_attach_point_strings, model_bindings, model_quest_cameras
- **moulds** (3 tables): mould_pack_items, mould_packs, moulds
- **world** (3 tables): world_groups, world_spec_configs, world_var_defaults

## Upstream issue tracker — known gaps

- 67 open issues: 50 bug · 30 quest · 9 missing-data · 4 enhancement · 3 skill

### Quests reported broken (playtest targets, by ID)

1208, 1255, 1256, 1257, 1258, 1259, 1260, 1261, 1262, 1263, 1264, 1265, 1266, 1267, 1268, 1269, 1270, 1271, 1272, 1274, 1275, 1276, 1277, 1278, 1279, 1280, 1281, 1282, 1329, 1450

## Fork fixes (our lane, no upstream PR)

- **BUG-006 — kill-acceptor quests can never start (FIXED on `fix/quest-kill-acceptor`, 2026-08-03).**
  `QuestActConAcceptNpcKill.RunAct` was a copy-paste of the Npc accept check, and no code
  path ever set a Kill acceptor. Added `QuestAcceptorType.Kill`, wired
  `DoOnMonsterHuntEvents` (the Npc.cs death path funnel, Npc.cs:877/986/1019) to start
  matching quests with the Kill acceptor, and fixed `RunAct` to match. Live data check:
  **380 quests** had ALL Start acts as kill-accepts (e.g. 182, 205, 556, 913, 1057, 1208)
  — all now startable on kill. Quest 1119 (upstream #1208) is actually a plain
  Npc-accept quest (Npc 2237), not part of this family.
- **BUG-008 — QuestActCheckGuard silently auto-completes (FIXED on `fix/quest-check-guard`, 2026-08-04).**
  `RunAct` returned true unconditionally, so 6 escort/protect quests' guard objectives
  always passed (silent false positive). Now resolves the guard NPC in the owner's world
  (`ParentWorld.GetNpcByTemplateId`) and returns true only when present and alive; dead,
  despawned, or unresolvable → false. 3 new `QuestActCheckGuardTests` (dead/missing
  cases failed before the fix). Full gate 1085/1085. Catalog: bugs/008-check-guard.md.

- **BUG-009 — item-group gather/use objectives stall (FIXED on `fix/quest-item-group-objectives`, 2026-08-04).**
  `QuestActObjItemGroupGather`/`QuestActObjItemGroupUse` RunAct fell through to the base
  stub ("not implemented", returns false) — 9 act rows stall: 4 live gather quests
  (5490 신기루 섬을 깨끗하게, 6578 이이제이, 6600 보다 더 강력한 힘, 6615 신의 방패
  정식 대원이 되다!) + test quest 5489 (use), 4 orphaned contexts (1955/1957/2140/1958).
  Both acts now implement real objective counting following their single-item siblings,
  group-expanded via `QuestManager.GetGroupItems`/`CheckGroupItem` (any group item
  counts). Gather also mirrors cleanup/destroy-on-drop item removal. 14 new unit tests.

- **BUG-010 — Helpers.UnixTime(long) clamps every timestamp > 59s to DateTime.MaxValue (FIXED/CLOSED on `fix/bug-010-unix-time`, 2026-08-04 — Rei attestation comment 2532, PASS).**
  The range check compared `time > DateTime.MaxValue.Second` — and `DateTime.MaxValue.Second == 59` —
  so any unix-seconds value > 59 decoded to `DateTime.MaxValue`. Every CheckTimer quest restored
  via `Quest.ReadData` got `Time = DateTime.MaxValue` (byte-diff proof: time field 1785894127s →
  253402300800s for census quests 350/4292/1313), `LeftTime` int-overflowed, timer never expired.
  Now clamps against the exact max representable unix-seconds value (integer ticks math,
  253402300799; `(long)TotalSeconds` double-rounds to 253402300800 which AddSeconds can't hold).
  8 new `HelpersTests` incl. 2026-timestamp round-trip; census regen flipped 350/4292/1313
  PERSIST:Fail → PERSIST:Pass with zero other verdict changes. Gate 1129/1129. Catalog: bugs/010-unix-time-maxvalue.md.
  **Census headline after closeout: T1 88/97 PASS (9 FAIL / 0 SKIP), T2 22/35 PASS (7 FAIL / 6 SKIP).**
  Remaining FAILs were harness-gap (1897 SUPPLY/PROGRESS/REWARD etc., tracked under t_71ac7013) and
  have since been calibrated away — runnability line is GREEN (M1-5 entry below).

- **BUG-007 — quest data defects fail silently (FIXED on `feat/quest-sanity-verifier`, 2026-08-04).**
  New `QuestSanityVerifier` (startup cross-check at end of `QuestManager.Load`): collects
  unknown/uninstantiated/detached act types, broken component/quest/item-group refs,
  M1-2 known stubs, orphaned rows and the alias-dormancy verdict — logged loudly
  (Error/Warn/Info), never throws (matches loader behavior). 14 unit tests cover every
  finding class. Full defect catalog: bugs/007-quest-sanity-verifier.md.

- **BUG-011 — QuestActCheckSphere can never pass + sphere entry crashes (FIXED on `fix/quest-check-sphere`, 2026-08-04).**
  CheckSphere is a check act (no objective counter — loader assigns
  `ThisComponentObjectiveIndex = 0xFF`), but `RunAct` read the counter (always 0 →
  never passes) and `OnEnterSphere`/`OnExitSphere` wrote it (Objectives[0xFF] →
  IndexOutOfRangeException). Now `RunAct` evaluates the owner's LIVE position against
  the component's quest spheres (mirrors QuestActCheckGuard), and sphere events only
  request re-evaluation. Live data: exactly 1 quest_context (1033, Progress component
  5065 → sphere 945); the other 10 act rows are orphans. 8 new `QuestActCheckSphereTests`
  (fail-before: 1 assertion + 3 IndexOutOfRangeException). Catalog: bugs/011-check-sphere-0xff.md.
- **BUG-012 — CharacterAbilities KeyNotFoundException 'General' on quest exp rewards (FIXED on `fix/char-abilities-general`, 2026-08-04).**
  `CharacterAbilities` ctor seeds `Fight(1)`..`Love(10)` only, but `AbilityType.General == 0`
  (Ability.cs:5) is never seeded and ability1/2/3 come from the client create packet / DB
  with no server-side validation — `AddActiveExp` indexed `Abilities[Ability1]` and threw
  `KeyNotFoundException 'General'` (census REWARD:Fail 250/6578/6600/6615 via
  QuestActSupplyExp → Character.AddExp). Both exp paths (`AddActiveExp`, `AddExp`) now
  guard with `Abilities.TryGetValue` — unseeded abilities are skipped, character exp
  intact (granted before the call), no bogus General row persisted. 6 new
  `CharacterAbilitiesTests` (3 General-slot no-throw + None + seeded-ability controls).
  Full gate 1127/1127. Catalog: bugs/012-abilities-general-key.md.

- **A4 save-path fix — SaveManager dirty-tracking (MERGED to fork develop @ 5ed5d6493, 2026-08-10 — t_8c18eb1c, Rei gate ACCEPT t_53025996).**
  Kimi audit finding (t_0fda3cd3, ROADMAP G2-A4): `SaveManager.DoSave` ran a full
  REPLACE for every in-world character every cycle (SaveManager.cs:94) — at 1,000 bots
  the periodic save rewrote ~1,000 full character rows + sub-collections (options,
  abilities, skills, quests, mates, …) each cycle even when nothing changed. Fix
  (a0277ad07, 20 files +404/−15): per-character dirty tracking — `Character.IsDirty`
  (default true: first cycle persists everyone, then settles into dirty-only) +
  `MarkDirty()` at every save-relevant chokepoint (SetPosition + bot movement paths,
  Hp/Mp value-compare props, Money/Money2/Experience, options/action slots/quests/
  skills/abilities/actability/appellations/portals/friends/blocked/mates, persistable
  buffs); `Save()` clears IsDirty on success; `SaveDirectlyToDatabase` stays
  unconditional (disconnect path unchanged — E2E restart-persistence contract intact).
  `DoSave(bool saveAllCharacters = false)` force-all seam — shutdown (StopAsync /
  ShutdownTask) and `/save` + `/shutdown` persist everything; `GetCharactersToSave()`
  extracted as a testable seam. Evidence: SaveManagerTests 10/10 (incl. 1,000-character
  simulated load: all-clean → 0, touched-subset → dirty-only, force-all → all); branch
  gate 1481/0/1; merged-tree gate 1575/0/1; M2bE2e restart-persistence 5/5
  (t_2ee39438). A4 acceptance (autosave p95 < 2s at 250 chars, zero `_isSaving` skips)
  remains a milestone-gate measurement.

- **M1-5 — quest scenario harness census COMPLETE (feat/quest-scenario-harness, 2026-08-04).**
  Harness (driver + manifest loader + tier runner) drives every manifest quest through
  START→PROGRESS→READY→REWARD→PERSIST with per-stage verdicts. Census over 3 tiers: T1 Solzreed
  97/97 PASS, T2 families 29/29 PASS (+6 SKIP orphaned contexts), T3 stratified act-family census
  27/27 PASS (+27 SKIP: unsupported act families + orphaned data). **Headline: 153/153 quests
  runnable** across 186 sampled quests (0 FAIL — every driven quest completes its lifecycle).
  Remaining SKIPs: 8 orphaned quest_contexts (data) + 25 harness gaps (14 unsupported act
  families — ObjZoneKill, ObjAggro, ObjCompleteQuest, EtcItemObtain, …; queue in
  scorecard-explorations/runnability.md). Gate 1148/1148.
  **Post-fix census regen (2026-08-05, fix/next-missing-776-777 @ aa35a503 merged, Rei gate PASS
  t_d8a8c798):** verdicts byte-stable — 153/153 runnable, 0 FAIL, 33 SKIP (census FAIL/SKIP deltas:
  none; the defect was a load-time verifier finding, never a scenario stage). 330/776/777
  COMPONENT_NEXT_MISSING → 0 via QuestDataOverlay (1520→1521, 3480→3482, 3488→11591): real-load
  census 0 ERR / 0 COMPONENT_NEXT_MISSING over 4775 quests. Gate 1216/0/0. Evidence:
  scorecard-explorations/next-missing-776-777.md.
  **Post-fix census regen (2026-08-05, fix/act-ref-2145 @ 82834da7 merged, Rei gate PASS
  t_53baa876):** verdicts byte-stable again — 153/153 runnable, 0 FAIL, 33 SKIP (census
  FAIL/SKIP deltas: none; the 2 pruned dangling ConAcceptComponent acts — 2145→2146 + sibling
  1960→1961 — sit on quests outside the 186-quest census sample, dead cat-34 crafting chain).
  ACT_REF_MISSING_QUEST real-data census: fail-before 2 rows → pass-after 0 (drift accept_comps
  384→382, quest_acts 26886→26884, −2/−2 exactly). Gate 1216/0/0 (incl. rig class 2/2).
  Evidence: scorecard-explorations/act-ref-2145-rig.md.
  **Post-fix census regen (2026-08-05, fix/no-start-1533 @ 74fb7762 merged, Rei gate PASS
  t_f884383f):** verdicts byte-stable — 153/153 runnable, 0 FAIL, 33 SKIP (census FAIL/SKIP
  deltas: none; the DROPPED QUEST_NO_START cluster 1533–1548 — 23 legacy tutorial shells, zero
  Start components + zero accept surfaces, provably never acceptable — sat outside the 186-quest
  census sample). QUEST_NO_START real-data census: fail-before 23 quests/exit 1 → pass-after 0
  (drift quest_contexts 4876→4853, quest_components 17851→17826, quest_acts 26886→26844 —
  −23/−25/−42 exactly; 9/9 unit_reqs collision rows untouched). Gate 1223/0/0 (fast +
  CI-parity coverage, Login.IntegrationTests 6/6; 1 pre-existing %db_port% env artifact).
  Evidence: scorecard-explorations/no-start-cluster-1533-1548-evidence.md +
  fix-no-start-1533-passafter.md.
  **Post-fix census regen (2026-08-06, fix/no-components-1391 @ b1e2231c merged, Rei gate PASS
  t_a56e8e2d):** verdicts byte-stable — 153/153 runnable, 0 FAIL, 33 SKIP (census FAIL/SKIP
  deltas: none; quest 1391 — an empty-template dummy shell with 0 components/0 acts, provably
  never acceptable — sat outside the 186-quest census sample). QUEST_NO_COMPONENTS real-data
  census: 1391 dropped via SQL/patches/compact/2026-08-05-drop-1391.sql (drift quest_contexts
  4876→4875, −1 exactly; nothing to cascade in components/acts; the only unit_reqs touch, id
  33609, is a Skill-owned sphere ref — left in place). Allowlist 132→131 ids (1391 removed so a
  regression re-reports at WARN, was allowlist-masked INFO). Rig flipped pass-after 2/2 (template
  absent + regression guard); verifier 27/27. Gate 1210/0/0 (fast + CI-parity coverage,
  Login.IntegrationTests 6/6; 1 pre-existing %db_port% env artifact). Evidence:
  scorecard-explorations/no-components-1391-rig.md (§7 pass-after).

### System-level bugs (non-quest)

- #696 [skill] [BUG] Tree thinning of old trees doesn't work as intended
- #920 [bug] [BUG] Ezna misses a lot of things
- #949 [bug] [BUG]  Pack that disappeared
- #972 [bug] [BUG] Red farm hauler
- #973 [bug] [BUG] Letter box
- #974 [bug] [BUG] Letter box  Shipping problem
- #978 [skill] [BUG] [Skill] (24353) Fortuna Die does not function correctly
- #985 [question] [BUG] Save character database
- #1011 [bug] [BUG] Harani main quest 3509 invisible quest npc
- #1033 [missing functionality] [BUG] Issue with NavMesh on the main_world, NPCs and monsters not being on the correct "height"
- #1046 [question] [BUG] with item
- #1047 [bug] [BUG] Quest NPC Nubo spawned inside mountain
- #1091 [bug] [BUG] <with farm hauler>
- #1152 [feedback to address] [BUG]  Treasure map
- #1168 [missing functionality] [BUG]  the packs in the merchant ship disappear
- #1170 [bug] [BUG]  Sometimes a player character looses its model and items (It happens randomly)
- #1175 [bug] [BUG] Return to email sender
- #1323 [bug] [BUG] PvP Arena scoring not working
- #1425 [bug] [BUG] NPCs and monsters floating above ground on develop
- #1491 [bug] [BUG] ActiveRegionTick is subscribed synchronously and starves the 100 ms AI tick

## Canonical resources — how 1.2 mechanics actually worked

| Resource | Use | URL |
|----------|-----|-----|
| ArcheAge Fandom Wiki | feature/mechanic reference (trade packs, labor, housing) | https://archeage.fandom.com/wiki/ArcheAge_Wiki |
| Ten Ton Hammer 1.2-era guides | trade pack economy, shipbuilding (2014 era = 1.2) | https://www.tentonhammer.com/guides/archeage-trade-pack-guide |
| AAEmu wiki (in-repo) | project's own component/architecture docs | Docs/wiki/ |
| AAEmu GitHub issues | known-broken list (50 bug / 30 quest / 9 data) | https://github.com/AAEmu/AAEmu/issues |
| compact.sqlite3 | the canonical 1.2 data surface (679 tables) | server: .server_files/AAEmu.Game/Data/ |
| game_pak (r208022) | client-side assets the server references | server: .server_files/AAEmu.Game/ClientData/ |
| ArcheAge Classic / ArcheRage | private-server behavior reference (what "working" looks like) | https://aa-classic.com |
