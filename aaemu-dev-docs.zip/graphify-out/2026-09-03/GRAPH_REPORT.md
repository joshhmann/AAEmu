# Graph Report - aaemu-dev  (2026-09-03)

## Corpus Check
- 8098 files · ~3,878,089 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 28232 nodes · 69667 edges · 1094 communities (962 shown, 132 thin omitted)
- Extraction: 93% EXTRACTED · 7% INFERRED · 0% AMBIGUOUS · INFERRED: 4804 edges (avg confidence: 0.8)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `3855e39f`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- AAEmu.Commons.Network
- AAEmu.Game.Core.Managers.World
- GamePacket
- AAEmu.Game.Models.Game.Char
- .Write
- PacketStream
- DoodadFuncTemplate
- EffectTemplate
- AAEmu.Game.Core.Managers
- ActorRequest
- .WriteBc
- Character
- BaseUnit
- AAEmu.Game.Models.Game.Quests.Static
- AAEmu.Game.Models.Game.NPChar
- FactionsEnum
- SpecialEffectAction
- AAEmu.Game.Models.Game.Items
- AAEmu.Login.Core.Network.Connections
- GameplayActor
- ICharacter
- Quest
- AAEmu.Login.Core.Network.Login
- IMessageOutput
- SubCommandBase
- BotTcpLink
- AAEmu.Game.Models.Game.Units.Movements
- SkillCastTarget
- GameConnection
- PopulationDirector
- QuestActTemplate
- BotScheduleService
- IItemManager
- GameplayActorTestRig
- SkillCaster
- PlayerBotRuntime
- WorldTemplate
- StreamPacket
- PacketMarshaler
- Slave
- WorldManagerTests
- EventArgs
- GameServerId
- ICommand
- AAEmu.IntegrationTests.E2e
- ItemContainer
- NpcAi
- BotPresenceCoordinator
- .Run
- .SendDefaultHelpText
- Dungeon
- ILoginClient
- GameplayActorTests
- .SendNormalText
- LevelingLoopScenarioRigTests
- Doodad
- AAEmu.Game.Models.CryEngine.Objects
- BotDriveBridge
- TeamManager
- WorldInstance
- ItemTask
- A5Tier3AcceptanceProbeTests
- Npc
- Race
- .Call
- StreamConnection
- ILoginSession
- .CreateItemManager
- SlaveLifecycleTests
- .ValidatePlacement
- .Create
- .CreateActor
- .SetPosition
- HeadlessSession
- LoginController
- AAPak
- BaseMail
- Quest
- .NewBot
- PhysicsManager
- TrialManager
- BotNetworkSession
- LevelingLoopScenario
- .CreateConnection
- DoodadManagerTests
- ShipShipInteraction
- Transfer
- NpcTemplate
- .CreateCharacterManager
- .OkJson
- AuctionManager
- PasswordServiceTests
- .JoinActorWorld
- HousingManager
- ILoginConnection
- .Run
- GameObject
- House
- ArchaeologyService
- NpcSpawner
- AccountId
- PROJECT-CONTROL.md
- .Run
- .BadRequestJson
- .OpenDb
- Mate
- .EnsureUp
- Singleton
- ActorAuditRecord
- BotActionCommandQueue
- .Run
- BotAdminService
- WaterBodies
- CharacterQuests
- TaskManagerTests
- WorldManager
- .Validate
- BotRoamStepExecutor
- .Evidence
- IIdManager
- AAEmu.Game.Core.Network.Stream
- BaseCombatBehavior
- Task
- A3StormProbeTests
- NodeCell
- BotPresenceManifestTests
- M4ExitIntegratedSessionTests
- .StockItem
- Gimmick
- HousingM3aConstructionTests
- WorldInstance
- ICommandV2
- .Rollback
- IdManager
- PlayerBotMetadataStore
- .BagCount
- ShipTuningDebug
- HomesteadPlacementScenarioTests
- .SendMessage
- ClientFileManager
- BaseCombatBehavior
- HousingStorageFurnitureTests
- PakArchiveServiceTests
- LoginConnection
- ArchaeologyServiceTests
- .Run
- .Summon_Bind_HelmSteer_Despawn_Rowboat_OnLiveServer_EndToEnd
- ItemTemplate
- ICharacterManager
- .Plant
- ItemTests
- .Setup
- .SetObjective
- .Board_RideRouteSegment_Disembark_OnLiveServer_EndToEnd
- .GetType
- BotScheduleServiceTests
- DormantBotRegistry
- IInitializable
- ItemManager
- AreasMissionReader
- QuestSanityVerifierTests
- TimedRewardsManager
- ScalingProbeTests
- .Indun_PartyOfTwo_EntersHadirFarm_FightsAndCompletes_OnLiveServer
- ArchaeologyDomainTests
- EndianBitConverter
- PopulationDirectorTests
- SphereQuestManager
- TickManager
- MailExpiryRestartTests
- BotControlApiTests
- HeadlessSessionProvisioningLiveTests
- Zero-Wired Domains — Nitty-Gritty Report
- CashShopManager
- ExperienceManagerTests
- AreaTrigger
- SpawnManager
- AAEmu.Game.Models.Game.Achievement.Enums
- Transform
- CropHarvestLoopRig
- IDisposable
- .HandleAsync
- .CreateConnection
- .Spawn
- DuelManager
- Behavior
- .Apply
- Simulation
- .Cast_FishingSkillAtWater_BiteLoop_OnLiveServer_EndToEnd
- .Indun_PartyOfTwo_ClearsHadirFarm_ExitsThroughRealPortal_OnLiveServer
- CrimeManager
- INameManager
- UnitRequirementsGameData
- IBuffs
- BotActionModels.cs
- AuctionHouseRestartE2eTests
- A5AcceptanceProbeTests
- LoginConnectionFactoryTests
- .SummonMate
- LoginPacket
- GameplayActorHouseBuildActionsTests
- PortalManager
- Shipyard
- .CreateManager
- NpcLineOfSightTests
- AGENTS.md — AAEmu
- Archaeology MCP — Read-Only Acceptance Report (2026-08-31)
- ArchaeologyService
- IBotStepExecutor
- GameScheduleManager
- SkillTemplate
- M3aExitScenarioTests
- LootingContainer
- MailOwnershipGuardTests
- PlayerBotScheduler
- FormulaManager
- NameManager
- MateGameData
- Buffs
- NpcGroundingPolicyTests
- BuffTests
- NoBuffBuffs
- SchedulerSoakStage1Runner
- .Evaluate
- AiGeoDataManager
- Task
- PressureSample
- IDominionManager
- FamilyManager
- Item
- SkillManagerTests
- IdleBehavior
- M3bExitPersistenceE2eTests
- gen-manifests.py
- EconomyDayCycleScenarioRigTests
- .BoardVehicle
- .Run
- BuffTemplate
- ILoadable
- .View
- AreaMissionNode
- Buff
- ItemProcBindingTests
- .DiscoverRoutesFromType
- RequestController
- ArchaeologyMcpServerTests
- Rig
- DominionManager
- SaveManager
- QuestManager
- .VerifyLoadedState
- SlaveGameData
- BigMonsterAttackBehavior
- .CreateCraftRig
- ArcheAge Slums — Roadmap & Milestones (locked-shape 2026-08-03; version number retired 2026-08-04 — v1/v4/v6/v7 label drift, the date is canonical)
- Navigation Domain — System Archaeology Dossier
- DominionScheduleTests
- ShipController
- PvpAggressionSeamRigTests
- BaiNavigationRigTests
- A5 Physics / Tick Timing Stall Investigation Dossier (2026-09-01) — read-only
- BotScenarioTemplate.cs
- .Harvest
- ModelManager
- AttachPointKind
- TradeManager
- NodeCell
- SummonSlave
- FloatingSkillController
- ArsServiceTests
- Partial-Wiring Deep-Dive: housing, auction, specialty-trade, items, mates, models
- SkillManager
- SkillObject
- WorldConfig
- PositionAndRotation
- ForceGenerator
- .RunStageAsync
- Gemini Handoff — AAEmu
- 1. (a) Character foot movement — walk/run, CSMoveUnitPacket, broadcasts, stop/halt
- Rig
- .SetupQuest
- MailTaxLifecycleTests
- AAEmu.Game.Services.WebApi
- .GetByType
- HeightmapTester
- .BotControlMcp_Sidecar_LiveEvidence
- BotScenarioRigTests
- MailCodLifecycleTests
- PvpFlaggingRigTests
- NpcMoveTowardsTests
- .SeedSingletons
- JOSH-QAT-PACKET-M4-M5.x
- Undefined World Mechanics Dossier (2026-08-31) — read-only census of data/code surfaces with no gameplay consumer
- e2e-common.sh
- STATUS — ArcheAge Slums (fork joshhmann/AAEmu)
- FriendMananger
- BuffTrigger
- AAEmu setup — reference
- IItemIdManager
- GradeTemplate
- GameService
- PhysicsTelemetryTests
- NpcGameData
- .SendPacketAsync
- .CreateRig
- .M3aM4EconomicReplay_OnFixtureWorld_PassesConservationAndLifecycle
- SpecialtyManagerTests
- AAEmu.UnitTests.Game.GameData
- GameControllerTests
- AAEmu.ArchaeologyMcp
- ISession
- BotAccountProvisioningService
- .DriveVehicle
- .HandleChannelingFinish
- AAEmu.Game.Models.CryEngine.Entities
- BaiReader
- .SendMessage
- WorldSpawnPosition
- SkillModifiers
- ActiveRegionTickSpawnerScanTests
- SubCommandBaseTests
- Active skills
- Parameters
- Параметры
- Quest Runnability — M1-5 + M2 (wave closures + band 1-55 + lvl-99 straggler census)
- FileManager
- .GetFileContents
- IReadOnlyList
- CharacterMails
- .Resolve
- ShipStaticBarrier
- .ForceState
- PacketCaptureSession
- SHIPS-01 Domain Dossier (2026-08-25 exploration)
- BaseBaiLoader
- AAEmu.Game.Core.Network.Login
- BotAppearanceFactory
- BotPath
- AAEmu.Game.Models.Spheres
- XmlWorldZone
- ScriptCompiler
- BotAppearanceFactoryTests
- .Rig
- QuestNoStartClusterTests
- Session
- GameplayActorB1ContractLayerTests
- PhysicsTelemetry
- .CreateRig
- CharacterSkills
- Task
- QuestActObjItemGroupUseTests
- LeapSkillController
- LivestockInteractionTests
- M3bFurniturePersistenceTests
- Unit Test Implementation Plan (xUnit) in `AAEmu.UnitTests`
- FAQ
- QuestActObjAbilityLevel — Research Dossier (2026-08-30)
- M3 Canonical Circle-Back Audit — HOUSING-01 / FARM-01 / PROPERTY-01 vs live 1.2
- WI-11a — Band 0/null triage: classification + drop-decision evidence
- RecordingExecutor
- NetMissionReader
- StubExpeditionIdManager
- TimeManager
- BotParitySeedingTests
- Task
- FlytrapAttackBehavior
- AbilityType
- .Apply
- UnitCooldownsTests
- .EconomyCycle_LedgerReconciles_AcrossGameProcessRestart
- .M51_AttachedPackOnSlave_LoadedViaRealContractAction_SurvivesKill9_ByteEqual
- M3bFurniturePersistenceE2eTests
- WebApiSessionTests.cs
- ArcheAge 1.2 Data-Wiring Scorecard
- QuestActObjMateLevel — Research Dossier (2026-08-30)
- Client
- Server
- AnimationManager
- PlayerBotAuditSink
- PublicFarmManager
- EquipItemTemplate
- WebApiServer
- SubCommandParameterBase
- .Execute
- UnitTests
- Program
- Dropped Content Register — quest_contexts & dangling rows
- .HandleAsync
- Helpers
- SaveManagerTests
- SpecialtyManager
- ItemConversionGameData
- CharacterCraft
- 4. Конкретные сценарии тестирования
- 📁 Test Files Overview
- 📁 Обзор тестовых файлов
- NPC Visual Behavior — float / sit-pose / cloth / targeting (Recon B)
- AAEmu.Game.csproj
- AccessLevelManager
- CommandManager
- GameScheduleManager.cs
- BuffGameData
- IGameDataLoader
- LootPack
- EquipmentContainerLevelGateTests
- .Apply
- .GetList
- DiscordBotService
- HousingBuildRaceProtectionTests
- .SetupQuest
- ModelsJsonConverterTests
- .Load
- AAEmu Unit Tests
- Housing Placement Mechanic — Canonical 1.2 Behavior + Data (HOUSING-01 dossier #1)
- PVP-01 Domain Dossier (2026-08-25 exploration)
- 4. Proposed update list for the M0 milestone state
- AAEmu.UnitTests
- .Write
- AiPathsManager
- MailIdManager
- PropertyRepairService
- SubZoneManager
- ZoneManager
- SilentCatchLoggingTests
- Character
- CharacterPortals
- OnEnterSphereArgs
- PlotEventTemplate
- .BotControlApi_ActionSurface_LiveEvidence
- SchedulerSoakStage1Tests.cs
- QuestScenarioManifest
- Per-commit verdicts (oldest first)
- NPC Pathing Recon — "enemies walking INTO hills" (server-side)
- FIXED (evidence retained)
- SourceCatalog
- McpServer
- .NextPrime
- .ShouldLoadPersistentDoodad
- MusicManager
- ZoneConflict
- AiGameData
- NpcGroupGameData
- BuffModifiers
- CastAction
- JsonPosition
- DominionRestartPersistenceE2eTests
- Login Server Networking
- AAEmu.UnitTests.Commons.Utils
- .Build
- SkillTests
- .CreateManager
- Game Objects
- ECONOMY Domain Dossier — MERCHANT-01 / LABOR-01 / ECON-01 / MAIL-01 (2026-08-25 exploration)
- ActionMcpServer
- AIManager
- BotAccountProvisioningServiceTests
- ActorRequest.cs
- .SetupThreeActorRig
- FeatureSet
- IZoneManager
- FakeZoneManager
- RoamingBehavior
- HoldPositionBehavior
- AAEmu.Game.Models.Game.Duels
- GimmickMovementHandler
- .SetupActAndQuest
- PlotNode
- StormShipLogic
- Program
- .CalculateAngleFrom
- CharacterAbilitiesTests
- QuestScenarioVerdict
- JOSH-QAT-WAVE4
- JUSTICE DOMAIN Dossier — CRIME-01 / TRIAL-01 / PRISON-01 (2026-08-25 exploration)
- AAEmu Fork — Fix/Feature Workflow (Tai's playbook, v4)
- ArchaeologyMcpServer
- MySqlConnectionFactory
- .Snapshot
- AreaShape
- SCMateEquipmentChangedPacket
- RoadMissionReader
- AbilityItems
- CharacterBlocked
- QuestActConAcceptItem
- NumericExtensions
- SqliteTestBase
- test-aaemu-assets.sh
- M1 Data-Defect Backlog — classification of verifier census findings (fix vs drop)
- Golden Route — Solzreed (Nuian)
- Track B: Manual setup workflow
- WI-6 — Band 41-50 ltd triage: quests 3419 / 4967 / 6069
- Archaeology Data-Source Inventory — Dossier (2026-08-30)
- Follow-up 2026-08-31 (second pass) — rebuilt server, fixes verified
- DOMINION-01 Domain Dossier (2026-08-25 exploration)
- MAIL-01 Domain Dossier (2026-08-25 exploration)
- Spawn-Z Data Defects — Classification + Correction (fix/npc-spawn-z)
- IBotControlClient
- .UnixTime
- GameplayActorCastEffectTests
- ShutdownTask
- WaypointSurfaceNavigationReader
- WildBoarAttackBehavior
- CharacterMates
- Aggro
- .SetupActAndQuest
- PlotState
- PlotTargetInfo
- WanderingSkillController
- .BuildAreaSkill
- .Execute
- .Execute
- TimeSpanExtensionsTests
- .BuildState
- .CapturedMails
- .RegisterManifestItems
- Dependencies and Downloads
- Documentation Map
- FEATURE TEMPLATE — Track 2 / our-lane feature (strict workflow, fork-only)
- FIX TEMPLATE — Track 1 canonical fix (strict workflow, lane gate: NO upstream PR)
- M1 Data-Defect Backlog — classification of verifier census findings (fix vs drop)
- A5 Physics / Memory Investigation — Durable Handoff (2026-09-02)
- 1. Quest engine, end-to-end
- AAEmu.BotControl
- AAEmu.BotControlMcp — contract-action MCP sidecar
- .Run
- LocalizationManager
- PlotManager
- .Schedule
- GameNetwork
- GameDataManager
- SphereGameData
- CharacterAppellations
- QuestActCheckTimer
- QuestActEtcItemObtain
- QuestActObjCinema
- QuestActObjMateLevel
- WorldPosTests
- AddKit
- GateSoakRunner.cs
- .Execute
- .OptOutConfinedToRoamExecutor_ObserverMovementStreamStillFlows
- FakeScheduler
- .BuildState
- .TeleportWithRegionSync_CharacterReRegistered_DestinationBroadcastsResolveIt
- .NewBot
- NumericSubCommandParameterTests
- COMMUNITY-GUIDELINES.md — Historical Upstream-Awareness Reference
- ![AAEmu](https://i.imgur.com/NFDY376.png)
- ❌ What Still Needs to Be Done (to reach 50% coverage)
- Application components
- Docker Installation Guide
- New & Fixed
- Quest Runnability — M1-5 scenario harness census
- EXPLORER TEMPLATE — deep-dive / recon (feeds the scorecard)
- FEATURE TEMPLATE — Track 2 / our-lane feature (strict workflow, fork-only)
- FIX TEMPLATE — Track 1 canonical fix (strict workflow, lane gate: NO upstream PR)
- AAEmu Living World — Canonical Notes (AzerothCore Inspiration)
- fix/no-start-1533 — pass-after evidence (t_43927087)
- SubStream
- GateStageConfig
- FishSchoolManager
- DoodadSaveSubCommand
- OnReportDoodadArgs
- OnReportNpcArgs
- QuestActObjCraft
- QuestActObjExpressFire
- QuestActObjInteraction
- QuestActObjItemUse
- QuestActObjLevel
- OnMonsterGroupHuntArgs
- OnMonsterHuntArgs
- OnTalkMadeArgs
- OnTalkNpcGroupMadeArgs
- AuctionController
- WebApiSession
- JsonModelsConverter
- RandomExtensionsTests
- GameplayActorInteractWithTests
- .CreateActorOnUniqueWorld
- SCUnitStatePacketVisualOptionsTests
- .LoadManifest
- 2. Covered Components
- 2. Покрытые тестами компоненты
- Common issues
- EXPLORER TEMPLATE — deep-dive / recon (feeds the scorecard)
- Implementing Sophisticated Quests in AAEmu — Engineering Guide
- unit_reqs layer audit — the 20 missing quest contexts and the 13 quests they gate
- a5-host-telemetry.sh
- main
- .Execute
- NpcSaveSubCommand
- .Capture
- .OnReceive
- ArcherAttackBehavior
- WorldEvents.cs
- IComparable
- .Execute
- TowerDefProg
- JsonDoodadSpawns
- JsonNpcSpawns
- AAEmu.Game.Models.Tasks.Specialty
- HarpoonMechanicsDebug
- Gate Harness — staged soak runner (P2, slice #10)
- KoreanChallengeVerifier
- AAEmu.Login.IntegrationTests
- RandomElementByWeightTests
- Rig
- .TierManifests_DriveAndWriteRunnabilityReport
- AAEmu Project Test Implementation Progress
- Aspire Development Guide
- Working with Config Files and Server Listings
- .kanban-templates — AAEmu fork task templates (onboarding-grade)
- AAEmu project control
- M2b-E2E — live-server bot harness
- Follow-up 2026-08-31 (third pass) — npc_spawners DB-side name matching fixed
- QUEST_NO_COMPONENTS 1391 — fail-before rig evidence
- QUEST_NO_START cluster 1533–1548 — fail-before + pass-after evidence (M1 rig)
- Quest Reachability Audit — do the allowlisted / flagged quests exist in 1.2 world data?
- ArcheAge Slums — Fork Vision & Lane Strategy
- ExecutionBoundary
- .Spawn
- IExperienceManager
- .GetArmorGradeBuff
- TagsGameData
- .RunBridgeStartupAsync
- CommercialMail
- AAEmu.Game.Models.Game.Mate
- Tagging
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- CheckBuffsExcludingTagsTests
- JsonQuestSphereConverter
- Teleport
- ScriptReflector
- AAEmu.Login
- .Dispatch
- Program
- PacketCaptureSession
- PacketCaptureSession
- PacketCaptureSession
- PacketCaptureSession
- PacketCaptureSession
- PacketCaptureSession
- CompletedQuestTests
- BUG-006 — Kill-acceptor quests can never start
- BUG-009 — QuestActObjItemGroupGather / QuestActObjItemGroupUse stall (9 quests)
- Прогресс внедрения тестов в проект AAEmu
- Asking for Help on GitHub Discussions
- ACT_REF_MISSING_QUEST — 2145→2146 fail-before evidence rig
- M6-light sideload — Roam + Safety + Behaviors (extension note)
- C10 Fishing Domain Dossier (FISH-01 all-U exploration, 2026-08-24)
- PlayerBot Capability Matrix (Perceive / Decide / Act / Verify)
- COMPONENT_NEXT_MISSING — 776/777 fail-before evidence rig
- Stub-Act Audit — quest acts that silently auto-complete or stall
- M2b-E2E boot orchestration (E2E-1)
- AAEmu.ArchaeologyMcp — read-only archaeology MCP server
- EffectTaskManager
- DynamicBonus
- TaxationsManager
- StreamNetwork
- .Write
- GimmickGameData
- QuestActObjAggro
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- .Execute
- Fly
- AAEmu.IntegrationTests
- .Execute
- FakeClient
- FakeClient
- StringExtensionsTest
- FakeSession
- ForceDismountHeadlessTests
- .LoadManifest
- .RunManifest
- GameServiceTests
- BUG-008 — QuestActCheckGuard silently auto-completes (6 escort/protect quests)
- BUG-011 — QuestActCheckSphere can never pass + sphere entry crashes (Objectives[0xFF])
- BUG-014 — quest completed-block id wraps for quest ids >= 4,194,304
- Deploy card — 2026-08-25 (mechanics + bots mega-release)
- Root cause — QUEST_NO_START cluster 1533–1548
- ❌ Что ещё нужно сделать (до 50% покрытия)
- M2b Playerbot Pilot — Regression-Harness Contract (Solzreed, M6.0-lite)
- Trade-Pack Put-Down Mechanic — Canonical 1.2 Placement Rules + PUTDOWN Refusal Verdict (PACK-01 dossier)
- e2e-snapshot.sh
- AAEmu.BotControl — MCP stdio gateway
- AAEmu.Commons
- CraftManager
- ExpressTextManager
- .Execute
- CommonFarmGameData
- QuestActObjZoneKill
- QuestActObjZoneMonsterHunt
- ZoneConfig.cs
- ShipyardTickTask.cs
- Announce
- SpawnGrid
- BaseJsonConverter
- .StepAsync
- .Execute
- .Execute
- .Execute
- CombatBuffs
- MySqlFixture
- DoodadChainSubCommandTests
- BUG-001 — Game container crash-loops with SIGSEGV (exit 139) during AiGameData load
- BUG-007 — Quest data defects fail silently: add startup sanity verifier (M1-3)
- BUG-010 — Helpers.UnixTime(long) clamps every timestamp > 59s to DateTime.MaxValue
- BUG-012 — CharacterAbilities KeyNotFoundException 'General' on quest exp rewards (Ability1 == General)
- BUG-016 — Melee combo skills with target_area_radius + TargetSelection=Target never damage their primary target (skill 18131 confirmed)
- Bot Control Gateway (API + MCP)
- Documentation Maintenance
- Help Us Help You
- Milestone Evidence Ledger — ArcheAge Slums (fork joshhmann/AAEmu)
- CraftManager
- FARM-01 Livestock Interactions — FIX-1 (t_afbf7cb7)
- INDUN-01 Domain Dossier (2026-08-24 exploration)
- HYRAXKNOT — AAEmu Progression Board
- Zone Readiness Report — Solzreed, Solzreed (2), Solzreed (3)
- find-tick-starvation.sh
- Game-data knowledge graphs
- SkillTlIdManager
- DamageModifierGameData
- ItemGameData
- .RunManifest
- BuffKind
- MailForSpeciality
- QuestManagerTests
- ServiceCollectionExtensions
- AppConfiguration
- AuctionManagerStartupWiringTests
- StubHomeSource
- CharacterLifecycleServiceTests
- QuestActConAcceptItemGain
- CSBuyItemsPacketTests.cs
- SCCharacterListPacketTests
- BUG-002 — compact.sqlite3 schema too old for develop branch
- BUG-004 — Login server advertises game server as 127.0.0.1
- BUG-013 — NPC sit poses render "knees in" (unplayable sit anim ids sent to the 1.2 client)
- BUG-015 — CharacterQuests.Save NREs on a null completed-block entry — disconnect save aborts, quest rows lost
- Asking for Help on Discord
- For AAEmu version 1.2
- Getting Help
- AGENT HANDOFF — 2026-08-26 Mail S3 acceptance + recovery reconciliation
- AAEmu Server — Bug Log
- TRACKING / STATUS CONVENTION — how the fork stays always-current
- ZONE / INSTANCE AUDIT TEMPLATE — content coverage
- QuestActConAcceptLevelUp
- DamageModifierGameData
- Bot template rig — scenario template evidence (P1 t_5efae4f1)
- WatchGameServer.ps1
- WatchLoginServer.ps1
- npc-spawn-z-fix.py
- Helper
- .RandomElementByWeight
- AuctionIdManager
- CharacterIdManager
- ChatIdManager
- CrimeIdManager
- DoodadIdManager
- FamilyIdManager
- FriendIdManager
- GimmickIdManager
- HousingIdManager
- HousingTldManager
- MateIdManager
- MusicIdManager
- ObjectIdManager
- PrivateBookIdManager
- ShipyardIdManager
- TaskIdManager
- TeamIdManager
- MailBody
- TradeIdManager
- TrialIdManager
- UccIdManager
- VisitedSubZoneIdManager
- WorldIdManager
- SCErrorMsgPacket
- SCICSMenuListPacket
- QuestActSupplyLp
- QuestActSupplyRemoveItem
- QuestActCheckDistance
- .RunManifest
- AAEmu.Game.Models.Game.OpenPortal
- ItemGameData
- MateXpUpdateTask
- AppConfiguration
- QuestActObjZoneQuestComplete
- CSBoardingTransferPacket
- TowerDefGameData
- BUG-003 — Missing game data files (compact.sqlite3 + game_pak)
- BUG-005 — game_pak (2023) vs compact.sqlite3 (2026) version drift
- 🔧 Technical Recommendations
- 🔧 Технические рекомендации
- Quest Test Harness & Game-Data Graphs
- AAEmu.Aspire.AppHost
- RandomExtensions.cs
- StringExtensions
- TimeSpanExtensions.cs
- ExpressTextManager .cs
- SCLootDiceNotifyPacket
- EquipRig
- TaskManagerTicker
- .Constructor_DoesNotCallDeps
- .Use
- .Constructor_DoesNotCallDeps
- QuestActConAcceptItemEquip
- PartyOptions
- QuestActConAcceptBuff
- README.md
- HoldablesSchemaCheck
- ServiceCollectionExtensions.cs
- README.md
- .Constructor_DoesNotCallDeps
- .Constructor_DoesNotCallDeps
- .Constructor_DoesNotCallDeps
- .Constructor_DoesNotCallDeps
- .Constructor_DoesNotCallDeps
- .Constructor_DoesNotCallDeps
- .Census_RealCompactSqlite3_NoComponentNextMissingFindings
- SCGimmickJointsBrokenPacket
- .Constructor_DoesNotCallDeps
- .Constructor_DoesNotCallDeps
- Priority 4: Additional Systems (~5-10% coverage)
- Приоритет 3: Модели и сущности (~10-15% покрытия)
- Приоритет 4: Дополнительные системы (~5-10% покрытия)
- UpdatesForTransform
- M2b playerbot pilot metrics — Solzreed golden route (character-cycle)
- run-a5-sixhour-soak.sh
- example-ics-default-en.sql
- 2019-02-18_aaemu_game.sql
- 2021-07-11_aaemu_game_transform.sql
- 2021-07-21_aaemu_game_transform.sql
- 2021-11-12_aaemu_game_index_fix.sql
- sit-pose-census.py
- SCUserNotesLoadedPacket
- MemberSyncState
- AppellationTemplate
- CSOffsets.cs
- ExpertLimit
- .ReleaseId
- IdManagerTests.cs
- SCOffsets.cs
- SCGimmicksCreatedPacket
- PPOffsets.cs
- ExpressText.cs
- AuctionSettings.cs
- hermes-verify-appearance.sh
- NavGCostProbe.csproj
- ItemDoodadTemplate.cs
- M2b-E2E live-server bot harness metrics — Solzreed golden route (16 quests)
- aaemu-prod-intake
- bot-regression-pass.sh
- e2e-stack.sh
- quest_act_ref_missing_census.sh
- quest_next_missing_census.sh
- quest_no_start_census.sh
- unit_reqs_missing_context_census.sh
- aaemu_game.sql
- aaemu_login.sql
- 2019-02-11_aaemu_game.sql
- 2019-02-28_aaemu_game.sql
- 2019-03-16_aaemu_game.sql
- 2020-04-30_aaemu_game.sql
- 2020-12-10_aaemu_game_housing.sql
- 2021-07-15_aaemu_game_furniture.sql
- 2021-09-11_aaemu_game_ucc.sql
- 2022-05-14_aaemu_game_item_containers.sql
- 2023-10-08_aaemu_game_slaves.sql
- 2024-02-16_aaemu_game_ics.sql
- 2024-03-11_aaemu_game_item_containers.sql
- 2024-08-04_aaemu_game_online_time.sql
- AAEmu.WorldConverter
- readme.md
- bug_report.md
- archaeology-cycle.sh
- docker-install-local.sh script
- docker-update-local.sh script
- e2e-boot.sh
- e2e-reset.sh
- gate.sh
- mcp-archaeology-gate-smoke.sh
- mcp-archaeology-smoke.sh
- mcp-stdio-smoke.sh
- publish.sh
- start_game.sh
- start_login.sh
- 2026-01-23-npc_group_members.sql
- 2026-01-23-npc_groups.sql
- 2019-02-04_aaemu_game.sql
- 2019-02-12_aaemu_game.sql
- 2019-02-27_aaemu_game.sql
- 2019-03-06_aaemu_game.sql
- 2019-03-09_aaemu_game.sql
- 2019-03-13_aaemu_game.sql
- 2019-03-20_aaemu_game.sql
- 2019-03-23_aaemu_game.sql
- 2019-05-07_aaemu_game.sql
- 2019-09-07_aaemu_game.sql
- 2020-04-29_aaemu_game_auction_house.sql
- 2020-04-30_aaemu_game_items.sql
- 2020-05-09_aaemu_game_items.sql
- 2020-05-10_aaemu_game_mails.sql
- 2020-05-14_aaemu_game_items.sql
- 2020-05-16_aaemu_game_auction_hourse.sql
- 2020-05-25_aaemu_game_auction_house.sql
- 2020-12-04_aaemu_game_auction_house.sql
- 2020-12-09_aaemu_game_accounts.sql
- 2020-12-09_aaemu_game_items.sql
- 2020-12-10_aaemu_game_doodads.sql
- 2020-12-10_aaemu_game_hostile_faction_kills.sql
- 2021-04-10_aaemu_game_ucc.sql
- 2021-09-23_aaemu_game_music.sql
- 2022-02-10_aaemu_game_characters-return_district.sql
- 2022-02-18_aaemu_game_characters-create_at&update_at_fix.sql
- 2022-07-07_aaemu_game_coffers.sql
- 2022-07-08_aaemu_game_doodad_data.sql
- 2022-07-28_aaemu_game_expire_item.sql
- 2022-09-22_aaemu_game_mail_text.sql
- 2022-09-23_aaemu_game_characters_experience.sql
- 2024-05-04_aaemu_game_slaves_update.sql
- 2024-05-10_aaemu_game_account_update.sql
- 2024-06-14_aaemu_game_doodads_update.sql
- 2024-07-10_aaemu_game_jury_points.sql
- 2024-10-29_aaemu_game_auction_house_update.sql
- 2024-10-30_aaemu_game_auction_house_update.sql
- 2024-10-30_aaemu_game_item_containers_update.sql
- 2024-10-30_aaemu_game_items_update.sql
- 2025-02-05_aaemu_login_ban_basics.sql
- 2025-02-15_aaemu_game_audit_char_sus.sql
- 2026-03-14_aaemu_login_users.sql
- 2026-03-15_aaemu_game_crime.sql
- 2026-03-15_aaemu_login_user_2fa.sql
- 2026-03-21_aaemu_game_character_active_buffs.sql
- 2026-05-20_aaemu_game_died_in_pvp_flags.sql
- 2026-06-07_aaemu_game_crime2.sql
- 2026-07-03_aaemu_game_crime2_b.sql
- 2026-08-20_aaemu_game_playerbot_audit.sql
- 2026-08-20_aaemu_game_playerbot_metadata.sql
- 2026-08-26_aaemu_game_dominions.sql
- TimedRewardsTask.cs
- Asking for Help on Discord
- TlIdManager
- SCSlaveEquipmentChangedPacket
- Nudge
- SCShipyardStatePacket

## God Nodes (most connected - your core abstractions)
1. `PacketStream` - 1011 edges
2. `Character` - 896 edges
3. `AAEmu.Commons.Network` - 893 edges
4. `AAEmu.Game.Core.Managers` - 742 edges
5. `AAEmu.Game.Models.Game.Char` - 737 edges
6. `AAEmu.Game.Core.Network.Game` - 717 edges
7. `GamePacket` - 717 edges
8. `AAEmu.Game.Models.Game.Units` - 674 edges
9. `AAEmu.Game.Core.Packets.G2C` - 666 edges
10. `BaseUnit` - 498 edges

## Surprising Connections (you probably didn't know these)
- `Configurations` --inherits--> `PacketMarshaler`  [EXTRACTED]
  AAEmu.Game/Models/Game/Configurations.cs → AAEmu.Commons/Network/PacketMarshaler.cs
- `ExpressText` --inherits--> `PacketMarshaler`  [EXTRACTED]
  AAEmu.Game/Models/Game/Emotion/ExpressText.cs → AAEmu.Commons/Network/PacketMarshaler.cs
- `ArchaeologyDomainTests` --references--> `ArchaeologyService`  [EXTRACTED]
  AAEmu.UnitTests/ArchaeologyMcp/ArchaeologyDomainTests.cs → AAEmu.ArchaeologyMcp/ArchaeologyDomain.cs
- `ArchaeologyServiceTests` --references--> `ArchaeologyService`  [EXTRACTED]
  AAEmu.UnitTests/ArchaeologyMcp/ArchaeologyServiceTests.cs → AAEmu.ArchaeologyMcp/ArchaeologyDomain.cs
- `ArchaeologyDomainTests` --references--> `SourceCatalog`  [EXTRACTED]
  AAEmu.UnitTests/ArchaeologyMcp/ArchaeologyDomainTests.cs → AAEmu.ArchaeologyMcp/SourceCatalog.cs

## Import Cycles
- None detected.

## Communities (1094 total, 132 thin omitted)

### Community 0 - "AAEmu.Commons.Network"
Cohesion: 0.01
Nodes (32): KickedReason, BattlefieldEndingReason, GameScoreEventKind, InstantGameType, TeamRole, SpawnPoint, PositionSnapshot, StageRecord (+24 more)

### Community 2 - "GamePacket"
Cohesion: 0.03
Nodes (43): Vector3, x, y, z, x, y, z, CSCompletedCinemaPacket (+35 more)

### Community 3 - "AAEmu.Game.Models.Game.Char"
Cohesion: 0.01
Nodes (38): AuctionScenarioOptions, CombatTacticalAction, BotStep, SkillType, WeaponWieldKind, TrialSentenceResult, DoodadFuncConsumeChangerItem, BuffConstants (+30 more)

### Community 4 - ".Write"
Cohesion: 0.00
Nodes (203): DateTime, Guid, ICollection, SCAccountAttributeConfigPacket, SCAccountInfoPacket, SCAccountWarnedPacket, SCAchievementChangedPacket, SCAchievementCompletedPacket (+195 more)

### Community 5 - "PacketStream"
Cohesion: 0.02
Nodes (11): PacketStream, int, List, Logger, CSAuctionSearchPacket, CSBidAuctionPacket, CSCancelAuctionPacket, CSSkipFinalStatementPacket (+3 more)

### Community 6 - "DoodadFuncTemplate"
Cohesion: 0.01
Nodes (269): SkillTlIdManager, Logger, object, ushort, IDoodadManager, List, MySqlConnection, MySqlTransaction (+261 more)

### Community 7 - "EffectTemplate"
Cohesion: 0.02
Nodes (70): QuestManager, Vector3, ICharacter, GamePointKind, DoodadRemovesSubCommand, IDictionary, List, DoodadRemoveSubCommand (+62 more)

### Community 8 - "AAEmu.Game.Core.Managers"
Cohesion: 0.02
Nodes (42): VictoryState, TeleportReason, TeleportCommandRegions, TPloc, Comp, LoadedState, AAEmu.Game.Models.Game.Teleport, AAEmu.Game.Models.Tasks.Quests (+34 more)

### Community 9 - "ActorRequest"
Cohesion: 0.02
Nodes (43): ActorObservation, IReadOnlyDictionary, IReadOnlyList, Vector3, ActorRequest, DateTime, Guid, IReadOnlyList (+35 more)

### Community 10 - ".WriteBc"
Cohesion: 0.01
Nodes (115): SCAbilityExpChangedPacket, byte, SCAbilitySwappedPacket, SCActiveWeaponChangedPacket, SCAggroTargetChangedPacket, SCAiAggroPacket, SCAppellationChangedPacket, SCAreaChatBubblePacket (+107 more)

### Community 11 - "Character"
Cohesion: 0.02
Nodes (62): BotTransitionSafetyProbe, EconomySnapshot, IBotChatterSink, LocalChatChatterSink, IBotTransitionSafetyProbe, IPlayerBotLifecycleService, UnwiredPlayerBotLifecycleService, Logger (+54 more)

### Community 12 - "BaseUnit"
Cohesion: 0.12
Nodes (13): DoodadFuncLootItem, Doodad, DoodadFuncRequireItem, Doodad, DoodadFuncRequireQuest, Doodad, InteractionEffect, CastAction (+5 more)

### Community 13 - "AAEmu.Game.Models.Game.Quests.Static"
Cohesion: 0.03
Nodes (35): CriterionVerdict, GateVerdict, ScenarioStageVerdict, LinkRecord, PerceptionSnapshot, MountOutcome, QuestReplaySpec, OverlayResult (+27 more)

### Community 14 - "AAEmu.Game.Models.Game.NPChar"
Cohesion: 0.01
Nodes (84): AiCommandSets, AiEvents, NpcGroupAggroRuleKind, SpawnerNpcsInZoneCache, SpawnerPlayerCountCache, SpawnerPlayerInRadiusCache, DateTime, NpcSpawnType (+76 more)

### Community 15 - "FactionsEnum"
Cohesion: 0.04
Nodes (22): ChatManager, ConcurrentDictionary, List, Logger, IChatManager, List, Character, ChatChannel (+14 more)

### Community 16 - "SpecialEffectAction"
Cohesion: 0.01
Nodes (156): AddBreath, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType (+148 more)

### Community 17 - "AAEmu.Game.Models.Game.Items"
Cohesion: 0.04
Nodes (11): BotCmd, FeatureCmd, FishFinderCmd, GoldCmd, ItemCmd, NpcCmd, SlaveCmd, TimeCmd (+3 more)

### Community 18 - "AAEmu.Login.Core.Network.Connections"
Cohesion: 0.03
Nodes (34): State, ServiceCollectionExtensions, IServiceCollection, CLOffsets, ushort, GLOffsets, ushort, LCOffsets (+26 more)

### Community 19 - "GameplayActor"
Cohesion: 0.08
Nodes (10): CTOffsets, ushort, EmblemStreamStatus, TCOffsets, ushort, AAEmu.Game.Core.Packets.S2C, AAEmu.Game.Core.Managers.Stream, AAEmu.Game.Core.Network.Stream (+2 more)

### Community 20 - "ICharacter"
Cohesion: 0.13
Nodes (10): Color, ItemExpireSubCommand, IDictionary, ItemUnwrapSubCommand, IDictionary, Color, AStarPathFindingSubCommand, IDictionary (+2 more)

### Community 21 - "Quest"
Cohesion: 0.04
Nodes (59): ActorAuditRecord, AdventurerSpikeScenario, SpikeOptions, Action, CriterionVerdict, Func, int, IReadOnlySet (+51 more)

### Community 22 - "AAEmu.Login.Core.Network.Login"
Cohesion: 0.08
Nodes (20): MySqlDatabaseUpdater, List, Logger, MySqlConnection, DiscordBotService, CancellationToken, int, Task (+12 more)

### Community 23 - "IMessageOutput"
Cohesion: 0.01
Nodes (50): AddBadges, AddBuff, AddGold, AddLabor, AddPortals, AddXP, Appellation, Around (+42 more)

### Community 24 - "SubCommandBase"
Cohesion: 0.03
Nodes (82): BotAddSubCommand, IDictionary, BotGoSubCommand, IDictionary, BotHereSubCommand, IDictionary, BotListSubCommand, BotRemoveSubCommand (+74 more)

### Community 25 - "BotTcpLink"
Cohesion: 0.07
Nodes (21): CancellationToken, JsonElement, Task, BotDriveClientCancellationTests, Fact, Task, LaneDAuctionHouseE2eTests, Fact (+13 more)

### Community 26 - "AAEmu.Game.Models.Game.Units.Movements"
Cohesion: 0.14
Nodes (8): GLOffsets, ushort, LGOffsets, ushort, AAEmu.Game.Models.Tasks.ServerLoad, AAEmu.Game.Core.Packets.G2L, AAEmu.Game.Core.Packets.L2G, AAEmu.Game.Core.Network.Login

### Community 27 - "SkillCastTarget"
Cohesion: 0.03
Nodes (70): DoodadFuncUse, Doodad, SkillCaster, SkillCasterMount, SkillCasterType, SkillCasterUnit, SkillCasterUnk1, SkillDoodad (+62 more)

### Community 28 - "GameConnection"
Cohesion: 0.03
Nodes (28): IHousingManager, Dictionary, Quaternion, Vector3, IDisposable, IObserver, EnterWorldManager, ConcurrentDictionary (+20 more)

### Community 29 - "PopulationDirector"
Cohesion: 0.04
Nodes (29): BotFidelity, FidelityTransitionResult, IPopulationDirector, PopulationDirector, PopulationDirectorProximityBootstrap, bool, CancellationToken, ConcurrentDictionary (+21 more)

### Community 30 - "QuestActTemplate"
Cohesion: 0.10
Nodes (15): Action, IndunExitE2eTests, Action, DateTime, Dictionary, Fact, InstanceId, List (+7 more)

### Community 31 - "BotScheduleService"
Cohesion: 0.04
Nodes (40): BotDailyAnchors, BotSchedulePhase, float, JsonElement, BotSchedulePayload, Logger, Vector3, BotScheduleResolver (+32 more)

### Community 32 - "IItemManager"
Cohesion: 0.02
Nodes (24): IItemManager, List, MySqlConnection, MySqlTransaction, ArmorGradeBuff, ArmorType, EquipSlotEnchantingCost, GradeDistributions (+16 more)

### Community 33 - "GameplayActorTestRig"
Cohesion: 0.04
Nodes (24): Before, Before, GameplayActorQuestDiscoveryTests, Task, Test, GameplayActorTalkTests, Task, Test (+16 more)

### Community 34 - "SkillCaster"
Cohesion: 0.02
Nodes (27): ICommandManager, List, ICommand, AStarCmd, BuildHouse, ClearCombat, CrimeCmd, DeSpawnAll (+19 more)

### Community 35 - "PlayerBotRuntime"
Cohesion: 0.03
Nodes (39): IBotScheduleBehavior, RoamRouteScheduleBehavior, Func, Vector3, IPlayerBotManager, IReadOnlyList, PlayerBotDiagnostics, PlayerBotRuntime (+31 more)

### Community 36 - "WorldTemplate"
Cohesion: 0.03
Nodes (23): WorldManager, bool, ConcurrentDictionary, DateTime, Dictionary, float, int, Lock (+15 more)

### Community 37 - "StreamPacket"
Cohesion: 0.08
Nodes (18): CSRemoveBuffPacket, Buff, DateTime, Dictionary, int, Logger, object, Unit (+10 more)

### Community 38 - "PacketMarshaler"
Cohesion: 0.04
Nodes (37): PacketMarshaler, Logger, CSBeautyshopDataPacket, AuctionBid, AuctionDisplay, Blocked, PremiumDetail, CharacterVisualOptions (+29 more)

### Community 39 - "Slave"
Cohesion: 0.29
Nodes (4): IReadOnlyList, GateBudgetEvaluatorTests, Task, Test

### Community 40 - "WorldManagerTests"
Cohesion: 0.09
Nodes (5): List, WorldInteractionGroup, WorldManagerTests, Task, Test

### Community 41 - "EventArgs"
Cohesion: 0.04
Nodes (45): IQuestAct, QuestAct, bool, OnBuffStartedArgs, OnDispelledArgs, OnTimeoutArgs, InAlertArgs, InDeadArgs (+37 more)

### Community 42 - "GameServerId"
Cohesion: 0.04
Nodes (51): GameController, ConcurrentDictionary, List, IGameController, List, IInternalConnectionTable, InternalConnection, IPAddress (+43 more)

### Community 43 - "ICommand"
Cohesion: 0.04
Nodes (38): BotTcpLink, Body, bool, CancellationTokenSource, ConcurrentQueue, HashSet, List, NetworkStream (+30 more)

### Community 44 - "AAEmu.IntegrationTests.E2e"
Cohesion: 0.09
Nodes (8): PlayerBotController, Quest, Dictionary, PlayerbotQuestDriver, JsonElement, List, PilotQuestResult, PilotStageVerdict

### Community 45 - "ItemContainer"
Cohesion: 0.05
Nodes (24): Unit, TimeSpan, Unit, Inventory, Dictionary, List, Logger, MySqlConnection (+16 more)

### Community 46 - "NpcAi"
Cohesion: 0.04
Nodes (23): AiCommandCategory, AlmightyNpcAiCharacter, ArcherHoldPositionAiCharacter, ArcherRoamingAiCharacter, BigMonsterHoldPositionAiCharacter, BigMonsterRoamingAiCharacter, DefaultAiCharacter, DummyAiCharacter (+15 more)

### Community 47 - "BotPresenceCoordinator"
Cohesion: 0.06
Nodes (28): Vector3, IPlayerBotScheduler, CancellationToken, DateTime, Task, TimeSpan, BotPresenceCoordinatorTests, RecordingScheduler (+20 more)

### Community 48 - ".Run"
Cohesion: 0.06
Nodes (45): BotDecisionCycle, BotDecisionExecution, BotDecisionProposal, BotDecisionSelection, BotDecisionSelector, BotObservedContext, BotProposalPostcondition, BotProposalPrecondition (+37 more)

### Community 49 - ".SendDefaultHelpText"
Cohesion: 0.09
Nodes (15): WaterDebugSnapshot, IEnumerable, RectangleF, Vector3, ClientFileManager, bool, IReadOnlyList, List (+7 more)

### Community 50 - "Dungeon"
Cohesion: 0.04
Nodes (33): IIndunManager, IndunManager, DateTime, Dictionary, List, Logger, object, TimeSpan (+25 more)

### Community 51 - "ILoginClient"
Cohesion: 0.06
Nodes (42): AuthFlowResult, Denied, Pending, Success, IArsAuthFlow, CancellationToken, Task, ICertAuthFlow (+34 more)

### Community 52 - "GameplayActorTests"
Cohesion: 0.05
Nodes (33): IReadOnlyDictionary, M53CoreSurfaceExitScenario, CriterionVerdict, IEnumerable, IScenarioWorldAdapter, List, ScenarioRunResult, ScenarioStageVerdict (+25 more)

### Community 53 - ".SendNormalText"
Cohesion: 0.05
Nodes (24): GameObject, bool, DateTime, Guid, int, List, Logger, Transform (+16 more)

### Community 54 - "LevelingLoopScenarioRigTests"
Cohesion: 0.07
Nodes (27): ActorActionType, HeadlessSession, Logger, uint, FixtureWorldAdapter, SpikeFixtureWorldAdapter, bool, int (+19 more)

### Community 55 - "Doodad"
Cohesion: 0.02
Nodes (77): CrimeManager, ConcurrentDictionary, DateTime, HashSet, int, List, Logger, MySqlConnection (+69 more)

### Community 56 - "AAEmu.Game.Models.CryEngine.Objects"
Cohesion: 0.17
Nodes (9): AssetPath, ObjectDataBase, Dictionary, ObjectDataType, ObjectsFile, BinaryReader, List, Logger (+1 more)

### Community 57 - "BotDriveBridge"
Cohesion: 0.11
Nodes (16): BotDriveBridge, LiveScenarioWorldAdapter, CancellationToken, CancellationTokenSource, ConcurrentDictionary, Dictionary, IEnumerable, int (+8 more)

### Community 58 - "TeamManager"
Cohesion: 0.05
Nodes (22): ITeamManager, InvitationTemplate, TeamManager, ConcurrentDictionary, DateTime, Dictionary, int, List (+14 more)

### Community 59 - "WorldInstance"
Cohesion: 0.03
Nodes (39): Defaults, ShipStaticBarrierBaiIngestor, float, int, List, Vector3, IndunGameData, Dictionary (+31 more)

### Community 60 - "ItemTask"
Cohesion: 0.03
Nodes (53): AAPointUpdate, int, ChangeAutoUseAAPoint, byte, ChangeBankAAPoint, int, ChangeGamePoint, byte (+45 more)

### Community 61 - "A5Tier3AcceptanceProbeTests"
Cohesion: 0.06
Nodes (32): IReadOnlyCollection, IReadOnlyList, MySqlCommand, A5Tier3AcceptanceProbeTests, Action, CancellationToken, count, DateTime (+24 more)

### Community 62 - "Npc"
Cohesion: 0.04
Nodes (32): ISpikeRuntime, LiveSpikeRuntime, Npc, ConcurrentDictionary, DateTime, float, Vector3, Combat (+24 more)

### Community 63 - "Race"
Cohesion: 0.13
Nodes (9): BotBodyPartEquipmentTests, CountingItemIdManager, After, IEnumerable, IReadOnlyDictionary, Task, Test, Type (+1 more)

### Community 64 - ".Call"
Cohesion: 0.08
Nodes (30): BotDriveClient, NetworkStream, StreamReader, StreamWriter, TcpClient, E2eQuestDriver, JsonElement, JsonSerializerOptions (+22 more)

### Community 65 - "StreamConnection"
Cohesion: 0.02
Nodes (62): PacketBase, UccManager, Dictionary, Logger, object, IStreamManager, StreamManager, ConcurrentDictionary (+54 more)

### Community 66 - "ILoginSession"
Cohesion: 0.11
Nodes (23): IAuthenticationFlow, CancellationToken, Task, LoginSession, CancellationToken, CancellationTokenSource, Func, Lock (+15 more)

### Community 67 - ".CreateItemManager"
Cohesion: 0.11
Nodes (5): ItemManagerTests, Mock, Task, Test, Type

### Community 68 - "SlaveLifecycleTests"
Cohesion: 0.13
Nodes (10): SlaveLifecycleTests, After, Before, bool, List, object, Task, Test (+2 more)

### Community 69 - ".ValidatePlacement"
Cohesion: 0.07
Nodes (18): HousingGameData, Dictionary, IReadOnlyCollection, IReadOnlyList, List, Logger, SqliteConnection, DecorationLimitEvaluator (+10 more)

### Community 70 - ".Create"
Cohesion: 0.07
Nodes (30): BotChatterBootstrap, Logger, ModuleInitializer, BotChatterOptions, TimeSpan, BotChatterService, bool, CancellationToken (+22 more)

### Community 71 - ".CreateActor"
Cohesion: 0.11
Nodes (22): DoodadRow, HouseRow, PropertyRepairIssue, PropertyRepairIssueKind, PropertyRepairScanner, PropertyStateView, byte, IReadOnlyList (+14 more)

### Community 72 - ".SetPosition"
Cohesion: 0.07
Nodes (27): B5BridgeMetricsLeakageTests, B5BroadcastMovementOptOutLeakageTests, B5RigSeedHookIsolationTests, Task, Test, GameplayActorLoadPackOntoVehicleTests, After, Before (+19 more)

### Community 73 - "HeadlessSession"
Cohesion: 0.04
Nodes (51): ActorTimeoutPolicy, GameplayActor, PendingCastEffect, VectorMath, Action, Dictionary, float, Guid (+43 more)

### Community 74 - "LoginController"
Cohesion: 0.07
Nodes (25): PasswordAuthFlow, CancellationToken, Task, IPasswordService, PasswordVerificationResult, Password, PasswordKind, PasswordService (+17 more)

### Community 75 - "AAPak"
Cohesion: 0.07
Nodes (18): AAPak, AAPakFileHeader, AAPakFileInfo, PakFileType, bool, byte, DateTime, Dictionary (+10 more)

### Community 76 - "BaseMail"
Cohesion: 0.04
Nodes (52): IMailManager, Dictionary, List, Obsolete, MailManager, Dictionary, List, Logger (+44 more)

### Community 77 - "Quest"
Cohesion: 0.06
Nodes (19): PathType, ItemCreationDefinition, Quest, bool, DateTime, int, List, QuestComponentKind (+11 more)

### Community 78 - ".NewBot"
Cohesion: 0.07
Nodes (25): BotArbitration, BotArbitrationOutcome, BotGoalArbiter, IBotGoalArbiter, ConcurrentDictionary, List, Logger, long (+17 more)

### Community 79 - "PhysicsManager"
Cohesion: 0.05
Nodes (27): PhysicsManager, ConcurrentQueue, Dictionary, float, JMatrix, JVector, List, Logger (+19 more)

### Community 80 - "TrialManager"
Cohesion: 0.06
Nodes (16): ITrialManager, TrialManager, bool, ConcurrentDictionary, Dictionary, int, List, Lock (+8 more)

### Community 81 - "BotNetworkSession"
Cohesion: 0.05
Nodes (30): BotNetworkSession, CancellationToken, CancellationTokenSource, Task, DuelFactionSwapE2eTests, CancellationToken, Fact, string (+22 more)

### Community 82 - "LevelingLoopScenario"
Cohesion: 0.10
Nodes (28): BotScenarioTemplates, IReadOnlyDictionary, AbilityGateCheck, AbilityLevelCriterion, BankMoneyCriterion, BotQuestPreState, BotScenarioTemplate, ContainerItemCriterion (+20 more)

### Community 83 - ".CreateConnection"
Cohesion: 0.08
Nodes (16): SqliteConnection, IEnumerable, SqliteConnection, SqliteConnection, SqliteConnection, SqliteConnection, SqliteConnection, NpcGroupGameData (+8 more)

### Community 84 - "DoodadManagerTests"
Cohesion: 0.11
Nodes (8): DoodadManager, bool, Dictionary, List, Logger, DoodadManagerTests, Task, Test

### Community 85 - "ShipShipInteraction"
Cohesion: 0.05
Nodes (33): ShipCliffInteraction, IReadOnlyList, TimeSpan, ShipDoodadInteraction, IReadOnlyList, List, TimeSpan, ShipShipInteraction (+25 more)

### Community 86 - "Transfer"
Cohesion: 0.05
Nodes (25): TransferManager, bool, Dictionary, double, Logger, TimeSpan, TransferSpawner, int (+17 more)

### Community 87 - "NpcTemplate"
Cohesion: 0.04
Nodes (32): INpcManager, Dictionary, List, NpcManager, Dictionary, List, Logger, Random (+24 more)

### Community 88 - ".CreateCharacterManager"
Cohesion: 0.17
Nodes (4): CharacterManagerTests, Mock, Task, Test

### Community 89 - ".OkJson"
Cohesion: 0.06
Nodes (40): AuctionController, HttpRequest, HttpResponse, Logger, MatchCollection, WebApiGet, WebApiPost, BaseController (+32 more)

### Community 90 - "AuctionManager"
Cohesion: 0.05
Nodes (21): AuctionManager, bool, ConcurrentBag, ConcurrentDictionary, List, Logger, MySqlCommand, MySqlConnection (+13 more)

### Community 91 - "PasswordServiceTests"
Cohesion: 0.29
Nodes (6): MySqlCollection, MySqlFixture, ValueTask, IAsyncLifetime, ICollectionFixture, MySqlContainer

### Community 92 - ".JoinActorWorld"
Cohesion: 0.06
Nodes (34): IPartyRuntime, LivePartyRuntime, PartyFollowAssistScenario, PartyOptions, CriterionVerdict, List, ScenarioRunResult, ScenarioStageVerdict (+26 more)

### Community 93 - "HousingManager"
Cohesion: 0.06
Nodes (16): HousingManager, bool, Dictionary, double, int, List, Logger, MySqlConnection (+8 more)

### Community 94 - "ILoginConnection"
Cohesion: 0.07
Nodes (23): ExpeditionManager, Dictionary, IEnumerable, List, Regex, IExpeditionManager, IEnumerable, Expedition (+15 more)

### Community 95 - ".Run"
Cohesion: 0.07
Nodes (31): IPartySpikeRuntime, LivePartySpikeRuntime, PartySpikeOptions, PartySpikeScenario, TraceMerger, Actor, CriterionVerdict, IEnumerable (+23 more)

### Community 96 - "GameObject"
Cohesion: 0.04
Nodes (39): GameplayActorB1ActionsTests, Task, Test, GameplayActorCraftRigTests, Task, Test, GameplayActorInteractLootTests, Task (+31 more)

### Community 97 - "House"
Cohesion: 0.13
Nodes (21): House, bool, DateTime, EventArgs, int, List, object, uint (+13 more)

### Community 98 - "ArchaeologyService"
Cohesion: 0.11
Nodes (16): ArchaeologyService, Func, IEnumerable, int, JsonNode, JsonObject, List, Matches (+8 more)

### Community 99 - "NpcSpawner"
Cohesion: 0.06
Nodes (13): IReadOnlyList, NpcSpawner, ConcurrentDictionary, Dictionary, int, IReadOnlyList, List, Logger (+5 more)

### Community 100 - "AccountId"
Cohesion: 0.05
Nodes (34): ReconnectAuthFlow, CancellationToken, Task, ILoginController, Banned, BanReason, CancellationToken, IPAddress (+26 more)

### Community 101 - "PROJECT-CONTROL.md"
Cohesion: 0.13
Nodes (4): ArcheAge 1.2, Related, Server Downloads, ArcheAge Slums — Data-Wiring and Evidence Scorecard (enriched)

### Community 102 - ".Run"
Cohesion: 0.05
Nodes (32): CycleOptions, ICyclePump, LiveCyclePump, IScenarioPump, TimeSpan, Vector3, FarmState, IScenarioPump (+24 more)

### Community 103 - ".BadRequestJson"
Cohesion: 0.18
Nodes (11): BotActionController, Exception, HttpRequest, HttpResponse, JsonSerializerOptions, Logger, MatchCollection, TimeSpan (+3 more)

### Community 104 - ".OpenDb"
Cohesion: 0.07
Nodes (28): B4BotRestartPersistenceE2eTests, CharacterRow, MetadataRow, RosterSnapshot, Fact, float, string, Task (+20 more)

### Community 105 - "Mate"
Cohesion: 0.05
Nodes (22): ISusManager, MateManager, Dictionary, List, Logger, Regex, SusManager, Dictionary (+14 more)

### Community 106 - ".EnsureUp"
Cohesion: 0.07
Nodes (18): E2eStack, Action, bool, FileStream, object, Process, string, PresenceE2eTests (+10 more)

### Community 107 - "Singleton"
Cohesion: 0.05
Nodes (22): IDuelManager, Dictionary, IInstantGameManager, IInitializable, IManaRegenManager, InstantGameManager, Dictionary, List (+14 more)

### Community 108 - "ActorAuditRecord"
Cohesion: 0.19
Nodes (9): BotScenarioRigTests, bool, object, Result, ScenarioRunResult, Session, Task, Test (+1 more)

### Community 109 - "BotActionCommandQueue"
Cohesion: 0.06
Nodes (35): BoardVehicleActionParams, BotActionCommand, BotActionCommandQueue, BotActionEnqueueResult, BotActionKind, BotActionQueueOptions, BotActionSnapshot, BotActionSpec (+27 more)

### Community 110 - ".Run"
Cohesion: 0.06
Nodes (17): MySQL, Logger, MySqlConnection, string, AccountManager, ConcurrentDictionary, DateTime, Dictionary (+9 more)

### Community 111 - "BotAdminService"
Cohesion: 0.10
Nodes (16): BotAdminCommandResult, BotAdminService, BotStatusRecord, Action, byte, float, Func, IReadOnlyList (+8 more)

### Community 112 - "WaterBodies"
Cohesion: 0.11
Nodes (15): WaterBodies, Dictionary, float, int, List, object, Vector2, Vector3 (+7 more)

### Community 113 - "CharacterQuests"
Cohesion: 0.08
Nodes (13): CharacterQuests, ConcurrentDictionary, List, Logger, MySqlConnection, MySqlTransaction, object, CompletedQuest (+5 more)

### Community 114 - "TaskManagerTests"
Cohesion: 0.18
Nodes (3): TaskManagerTests, Task, Test

### Community 115 - "WorldManager"
Cohesion: 0.13
Nodes (8): PositionAndRotation, float, Pitch, Quaternion, Roll, Vector3, WorldPos, Yaw

### Community 116 - ".Validate"
Cohesion: 0.13
Nodes (6): SqlGuard, Regex, string, SqlGuardTests, Task, Test

### Community 117 - "BotRoamStepExecutor"
Cohesion: 0.06
Nodes (41): BotRoamStepExecutor, CancellationToken, ConcurrentDictionary, Func, Logger, Task, TimeProvider, TimeSpan (+33 more)

### Community 118 - ".Evidence"
Cohesion: 0.16
Nodes (7): BotEquipEntry, BotEquipmentPlan, List, AbilityItems, List, AbilitySupplyItem, EquipItemsTemplate

### Community 119 - "IIdManager"
Cohesion: 0.14
Nodes (6): IIdManager, IdManagerTests, IEnumerable, MethodDataSource, Task, Test

### Community 120 - "AAEmu.Game.Core.Network.Stream"
Cohesion: 0.01
Nodes (116): SequenceReaderExtensions, XmlHelper, Command, BotPresenceConfig, BotRoamStepExecutorHolder, Lazy, DepositMode, LedgerEntry (+108 more)

### Community 121 - "BaseCombatBehavior"
Cohesion: 0.05
Nodes (21): AttackBehavior, bool, TimeSpan, DeadBehavior, bool, TimeSpan, DespawningBehavior, TimeSpan (+13 more)

### Community 122 - "Task"
Cohesion: 0.05
Nodes (25): CharacterDeleteTask, object, TrialUpdateTask, object, DoodadDeleteTask, DuelEndTimerTask, uint, DuelFuncTask (+17 more)

### Community 123 - "A3StormProbeTests"
Cohesion: 0.09
Nodes (21): A3StormProbeTests, DateTime, Fact, int, JsonElement, List, string, Task (+13 more)

### Community 124 - "NodeCell"
Cohesion: 0.06
Nodes (30): AAEmu.WorldConverter, AAEmu.WorldConverter.Models, Single, AABB, Vector3, Hmap, NodeCell, BinaryReader (+22 more)

### Community 125 - "BotPresenceManifestTests"
Cohesion: 0.08
Nodes (21): BotPresenceBootstrap, ModuleInitializer, BotPresenceCoordinator, Exception, float, Func, int, IReadOnlyList (+13 more)

### Community 126 - "M4ExitIntegratedSessionTests"
Cohesion: 0.10
Nodes (13): M4ExitIntegratedSessionTests, SaveStubSlave, After, Before, double, int, List, object (+5 more)

### Community 127 - ".StockItem"
Cohesion: 0.10
Nodes (8): QuestManager, bool, Dictionary, Func, List, Logger, object, Queue

### Community 128 - "Gimmick"
Cohesion: 0.07
Nodes (20): Gimmick, DateTime, float, object, Quaternion, TimeSpan, Vector3, AngVelCoordinateType (+12 more)

### Community 129 - "HousingM3aConstructionTests"
Cohesion: 0.13
Nodes (12): CraftEffect, HousingM3aConstructionTests, After, Before, Dictionary, IReadOnlyCollection, Mock, object (+4 more)

### Community 130 - "WorldInstance"
Cohesion: 0.05
Nodes (14): WorldEvents, EventHandler, WorldInstance, ConcurrentDictionary, Func, HashSet, int, List (+6 more)

### Community 131 - "ICommandV2"
Cohesion: 0.19
Nodes (11): IPlotTargetParams, SkillTargetRelation, PlotTargetAreaParams, SkillTargetRelation, PlotTargetRandomAreaParams, SkillTargetRelation, PlotTargetRandomUnitParams, SkillTargetRelation (+3 more)

### Community 132 - ".Rollback"
Cohesion: 0.22
Nodes (4): SkillControllerPacketDebug, bool, Logger, SCSkillControllerStatePacket

### Community 133 - "IdManager"
Cohesion: 0.08
Nodes (18): BitSet, BitArray, IdManager, bool, IEnumerable, int, Logger, object (+10 more)

### Community 134 - "PlayerBotMetadataStore"
Cohesion: 0.10
Nodes (11): PlayerBotMetadataStore, ConcurrentDictionary, int, Logger, MySqlConnection, MySqlTransaction, object, PlayerBotMetadata (+3 more)

### Community 135 - ".BagCount"
Cohesion: 0.12
Nodes (15): DevMapperService, MapperActionRecord, MapperActionType, MapperReplayResult, MapperRouteData, MapperSession, MapperSessionSummary, bool (+7 more)

### Community 136 - "ShipTuningDebug"
Cohesion: 0.08
Nodes (8): ShipTuningDebug, ConcurrentDictionary, int, Span, Vector3, MarkerSet, MassBoxGameGeometry, Matrix4x4

### Community 137 - "HomesteadPlacementScenarioTests"
Cohesion: 0.09
Nodes (26): HousingAreas, HousingBuildStep, HousingGroup, HousingLandZoneInfo, Dictionary, HashSet, IEnumerable, IReadOnlyDictionary (+18 more)

### Community 138 - ".SendMessage"
Cohesion: 0.08
Nodes (6): QuestManagerTests, TestWorldManager, bool, Fact, List, Task

### Community 139 - "ClientFileManager"
Cohesion: 0.01
Nodes (216): CompressedGamePackets, List, NpcControlCategory, AcceptQuestEffect, CastAction, DateTime, SkillCaster, SkillCastTarget (+208 more)

### Community 140 - "BaseCombatBehavior"
Cohesion: 0.10
Nodes (17): BaseCombatBehavior, bool, DateTime, Dictionary, List, Queue, string, TimeSpan (+9 more)

### Community 141 - "HousingStorageFurnitureTests"
Cohesion: 0.10
Nodes (14): FakeObjectIdManager, HousingStorageFurnitureTests, After, Before, IEnumerable, object, Task, Test (+6 more)

### Community 142 - "PakArchiveServiceTests"
Cohesion: 0.12
Nodes (11): PakArchiveService, Func, int, JsonObject, Regex, string, PakArchiveServiceTests, DateTime (+3 more)

### Community 143 - "LoginConnection"
Cohesion: 0.07
Nodes (22): LoginCharacterInfo, LoginConnection, CancellationToken, ConcurrentDictionary, ConnectionContext, DateTime, Dictionary, Exception (+14 more)

### Community 144 - "ArchaeologyServiceTests"
Cohesion: 0.12
Nodes (4): ArchaeologyServiceTests, string, Task, Test

### Community 145 - ".Run"
Cohesion: 0.11
Nodes (23): AuctionHouseScenario, CriterionVerdict, FleetProvisioner, int, List, Logger, ScenarioRunResult, ScenarioStageVerdict (+15 more)

### Community 146 - ".Summon_Bind_HelmSteer_Despawn_Rowboat_OnLiveServer_EndToEnd"
Cohesion: 0.11
Nodes (20): RowboatE2eTests, Body, CancellationToken, Fact, float, List, Stage, string (+12 more)

### Community 147 - "ItemTemplate"
Cohesion: 0.04
Nodes (27): AuctionSearch, AuctionSearchSortKind, AuctionSearchSortOrder, ChestType, CofferContainer, Item, BackpackTemplate, Type (+19 more)

### Community 148 - "ICharacterManager"
Cohesion: 0.11
Nodes (7): Actability, float, CharacterActability, Dictionary, MySqlConnection, MySqlTransaction, ActabilityTemplate

### Community 149 - ".Plant"
Cohesion: 0.08
Nodes (14): Simulation, Dictionary, float, int, List, Logger, string, Vector3 (+6 more)

### Community 150 - "ItemTests"
Cohesion: 0.13
Nodes (3): ItemTests, Task, Test

### Community 151 - ".Setup"
Cohesion: 0.09
Nodes (23): QuestActCheckSphere, Quest, QuestAct, QuestActCheckSphereTests, Act, After, Before, Dictionary (+15 more)

### Community 152 - ".SetObjective"
Cohesion: 0.20
Nodes (9): QuestActObjItemGroupGather, Quest, QuestAct, QuestActObjItemGroupGatherTests, Act, int, Task, Test (+1 more)

### Community 153 - ".Board_RideRouteSegment_Disembark_OnLiveServer_EndToEnd"
Cohesion: 0.09
Nodes (24): MovementTrack, TransferRideE2eTests, CancellationToken, DateTime, Dictionary, Fact, float, IDictionary (+16 more)

### Community 154 - ".GetType"
Cohesion: 0.08
Nodes (14): CSMoveUnitPacket, uint, DefaultMoveType, MoveType, Quaternion, Vector3, ShipMoveType, Slave (+6 more)

### Community 155 - "BotScheduleServiceTests"
Cohesion: 0.17
Nodes (10): BotScheduleBootstrap, Logger, ModuleInitializer, BotScheduleOptions, TimeSpan, BotScheduleServiceTests, Task, Test (+2 more)

### Community 156 - "DormantBotRegistry"
Cohesion: 0.17
Nodes (5): FlightLinkDescriptor, ObstacleDataDescriptor, Vector3, AAEmu.Game.Models.CryEngine.Readers, AAEmu.Game.Models.CryEngine.Entities

### Community 157 - "IInitializable"
Cohesion: 0.08
Nodes (24): DormantBotRegistry, DormantBotSpec, IDormantBotHomeSource, IDormantBotSource, MySqlDormantBotSource, PlayerBotMetadataHomeSource, Dictionary, Func (+16 more)

### Community 158 - "ItemManager"
Cohesion: 0.07
Nodes (14): ItemManager, bool, ConcurrentDictionary, DateTime, Dictionary, int, List, Logger (+6 more)

### Community 159 - "AreasMissionReader"
Cohesion: 0.07
Nodes (21): Spans, AiLightLevel, AiShape, List, Vector3, FlightNavRegion, List, Mission (+13 more)

### Community 160 - "QuestSanityVerifierTests"
Cohesion: 0.19
Nodes (8): QuestSanityVerifierTests, Dictionary, List, SanityReport, SqliteConnection, Task, Test, State

### Community 161 - "TimedRewardsManager"
Cohesion: 0.15
Nodes (8): LaborConfig, ChangeLaborConsumptionTests, TimedRewardsManagerTests, After, Before, object, Task, Test

### Community 162 - "ScalingProbeTests"
Cohesion: 0.06
Nodes (27): Pop, Sample, StormPhase, Sample, BaselineResult, DormancyResult, Pop, Sample (+19 more)

### Community 163 - ".Indun_PartyOfTwo_EntersHadirFarm_FightsAndCompletes_OnLiveServer"
Cohesion: 0.09
Nodes (17): IndunPartyE2eTests, DateTime, Dictionary, Fact, InstanceId, List, Regex, string (+9 more)

### Community 164 - "ArchaeologyDomainTests"
Cohesion: 0.13
Nodes (4): ArchaeologyDomainTests, string, Task, Test

### Community 165 - "EndianBitConverter"
Cohesion: 0.08
Nodes (5): BigEndianBitConverter, EndianBitConverter, Endianness, LittleEndianBitConverter, AAEmu.Commons.Conversion

### Community 166 - "PopulationDirectorTests"
Cohesion: 0.12
Nodes (6): PopulationDirectorTests, CancellationToken, Func, Task, Test, TimeSpan

### Community 167 - "SphereQuestManager"
Cohesion: 0.09
Nodes (16): ISphereQuestManager, List, SphereQuestManager, Dictionary, List, Logger, object, TimeSpan (+8 more)

### Community 168 - "TickManager"
Cohesion: 0.05
Nodes (38): MaterializationLatencySnapshot, ITickManager, TickEventHandler, SampleRing, SubscriberTickMetrics, TickEventEntity, TickEventHandler, TickManager (+30 more)

### Community 169 - "MailExpiryRestartTests"
Cohesion: 0.12
Nodes (13): CrimePointsRigTests, Capture, CrimePoints, CrimeState, InfamyPoints, IReadOnlyList, Points, Task (+5 more)

### Community 170 - "BotControlApiTests"
Cohesion: 0.10
Nodes (19): BotControlSettings, IEnumerable, JsonElement, Name, string, BotControlApiTests, string, Task (+11 more)

### Community 171 - "HeadlessSessionProvisioningLiveTests"
Cohesion: 0.10
Nodes (18): HeadlessSessionProvisioningLiveTests, LiveRigOnlyAttribute, int, JsonElement, MySqlConnection, NotInParallel, Process, StreamReader (+10 more)

### Community 172 - "Zero-Wired Domains — Nitty-Gritty Report"
Cohesion: 0.05
Nodes (40): 1. fx-visuals, 2. siege (dominion war), 3. ranks (contests + rank rewards), 4. premium (patron service), 5. moulds (crafting moulds), 6. race-tracks (Mirage Island racing), 7. music (instrument sounds + note limits), 8. quest reward/labor domains (M2a wave-1 watch list, 2026-08-06) (+32 more)

### Community 173 - "CashShopManager"
Cohesion: 0.06
Nodes (24): CashShopManager, DateTime, Dictionary, List, Logger, ICashShopManager, Dictionary, List (+16 more)

### Community 174 - "ExperienceManagerTests"
Cohesion: 0.10
Nodes (14): ExperienceManager, List, Logger, IExperienceLevelTemplateLoader, IEnumerable, IExperienceManager, SqliteExperienceLevelTemplateLoader, ExperienceLevelTemplate (+6 more)

### Community 175 - "AreaTrigger"
Cohesion: 0.06
Nodes (24): AreaTriggerManager, List, Logger, object, TimeSpan, IAreaTriggerManager, TimeSpan, DoodadFuncClout (+16 more)

### Community 176 - "SpawnManager"
Cohesion: 0.03
Nodes (27): FileManager, Regex, string, Creature, Dictionary, Logger, JsonHelper, Exception (+19 more)

### Community 177 - "AAEmu.Game.Models.Game.Achievement.Enums"
Cohesion: 0.05
Nodes (22): AchievementInfo, DateTime, AchievementObjectives, Achievements, ICollection, CharRecords, AchievementAdventureCategory, AchievementCategory (+14 more)

### Community 178 - "Transform"
Cohesion: 0.10
Nodes (10): Transform, DateTime, float, GameObject, List, object, Position, uint (+2 more)

### Community 179 - "CropHarvestLoopRig"
Cohesion: 0.06
Nodes (26): DoodadFuncGroupKind, DoodadFuncGroups, CropHarvestLoopRig, CropHarvestLoopTests, After, Before, bool, Dictionary (+18 more)

### Community 180 - "IDisposable"
Cohesion: 0.12
Nodes (17): NavObstacle, NavObstacleCatalogJson, NavObstacleEntryJson, ObstacleManager, Dictionary, float, IReadOnlyList, List (+9 more)

### Community 181 - ".HandleAsync"
Cohesion: 0.20
Nodes (4): BotControlActionMcpTests, JsonNode, Task, Test

### Community 182 - ".CreateConnection"
Cohesion: 0.13
Nodes (9): BaiReader, BinaryReader, List, Logger, Stream, Vector3, VertexMissionReader, int (+1 more)

### Community 183 - ".Spawn"
Cohesion: 0.20
Nodes (8): PlayerBotManager, ConcurrentDictionary, IReadOnlyList, Logger, long, PlayerBotManagerTests, Task, Test

### Community 184 - "DuelManager"
Cohesion: 0.08
Nodes (15): DuelManager, ConcurrentDictionary, Dictionary, double, float, Logger, Duel, DuelDetType (+7 more)

### Community 185 - "Behavior"
Cohesion: 0.06
Nodes (19): SCLootDicePacket, Backpack, BodyPart, MateEquipmentContainer, Item, bool, byte, DateTime (+11 more)

### Community 186 - ".Apply"
Cohesion: 0.09
Nodes (21): ImpulseEffect, CastAction, DateTime, SkillCaster, SkillCastTarget, SkillObject, Vector3, PhysicalExplosionEffect (+13 more)

### Community 187 - "Simulation"
Cohesion: 0.18
Nodes (11): BotProvisioningControlHost, BotProvisioningControlHostBootstrap, CancellationToken, CancellationTokenSource, int, JsonElement, Logger, ModuleInitializer (+3 more)

### Community 188 - ".Cast_FishingSkillAtWater_BiteLoop_OnLiveServer_EndToEnd"
Cohesion: 0.10
Nodes (20): CastTrace, FishingVerificationE2eTests, FrameTally, CancellationToken, Fact, HashSet, int, List (+12 more)

### Community 189 - ".Indun_PartyOfTwo_ClearsHadirFarm_ExitsThroughRealPortal_OnLiveServer"
Cohesion: 0.15
Nodes (7): CommandManager, Dictionary, GeneratedRegex, List, Logger, Regex, string

### Community 190 - "CrimeManager"
Cohesion: 0.08
Nodes (17): MySqlConnection, MySqlTransaction, MySqlConnection, MySqlTransaction, MySqlConnection, MySqlTransaction, MySqlConnection, MySqlTransaction (+9 more)

### Community 191 - "INameManager"
Cohesion: 0.08
Nodes (17): Quaternion, ReadOnlySequence, LoginProtocolHandler, ConcurrentDictionary, Logger, Type, PacketStreamTests, Task (+9 more)

### Community 192 - "UnitRequirementsGameData"
Cohesion: 0.24
Nodes (6): UnitRequirementsGameData, Dictionary, IEnumerable, List, UnitReqsKindType, UnitReqs

### Community 193 - "IBuffs"
Cohesion: 0.06
Nodes (8): BuffKind, BuffRemoveOn, IBuffs, IEnumerable, List, MySqlConnection, MySqlTransaction, Type

### Community 194 - "BotActionModels.cs"
Cohesion: 0.05
Nodes (37): AcceptQuestRequest, AdvanceQuestRequest, AutoTurnInRequest, BoardVehicleRequest, BuyRequest, CastRequest, CraftRequest, DepositItemRequest (+29 more)

### Community 195 - "AuctionHouseRestartE2eTests"
Cohesion: 0.10
Nodes (19): AuctionHouseRestartE2eTests, ItemRow, LotRow, DateTime, Dictionary, Fact, Func, id (+11 more)

### Community 196 - "A5AcceptanceProbeTests"
Cohesion: 0.11
Nodes (18): A5AcceptanceProbeTests, CancellationToken, count, DateTime, Fact, IEnumerable, int, JsonElement (+10 more)

### Community 197 - "LoginConnectionFactoryTests"
Cohesion: 0.10
Nodes (17): ConnectionIdLease, ConnectionIdLeaseFactory, IConnectionIdLeaseFactory, LoginConnectionFactory, ConcurrentDictionary, ConnectionContext, IIdManager, SimpleIdManager (+9 more)

### Community 198 - ".SummonMate"
Cohesion: 0.10
Nodes (21): SanityReport, QuestSanityVerifier, Dictionary, HashSet, int, IReadOnlyCollection, IReadOnlyDictionary, IReadOnlyList (+13 more)

### Community 199 - "LoginPacket"
Cohesion: 0.00
Nodes (334): GamePacket, CSAcceptCheatQuestContextPacket, CSActiveWeaponChangedPacket, CSAddBlockedUserPacket, CSAddFriendPacket, CSAllowHousingRecoverPacket, CSApplyToInstantGamePacket, uint (+326 more)

### Community 200 - "GameplayActorHouseBuildActionsTests"
Cohesion: 0.06
Nodes (38): EquipmentItemSlotType, GameplayActorEquipTests, Task, Test, uint, GameplayActorHouseBuildActionsTests, Actor, After (+30 more)

### Community 201 - "PortalManager"
Cohesion: 0.07
Nodes (15): LoopOptions, Func, TimeSpan, PlayerBotSchedulerOptions, Func, TimeSpan, IPortalManager, List (+7 more)

### Community 202 - "Shipyard"
Cohesion: 0.08
Nodes (16): IShipyardManager, ShipyardManager, Dictionary, List, Logger, Shipyard, bool, EventArgs (+8 more)

### Community 203 - ".CreateManager"
Cohesion: 0.20
Nodes (3): QuestManagerTests, Task, Test

### Community 204 - "NpcLineOfSightTests"
Cohesion: 0.14
Nodes (11): NpcLineOfSightTests, After, Before, double, float, object, string, Task (+3 more)

### Community 205 - "AGENTS.md — AAEmu"
Cohesion: 0.05
Nodes (37): AGENTS.md — AAEmu, Archaeology MCP — development-cycle checkpoints, Authoritative sources (in order), Build and test, C# style highlights (from `.editorconfig`), Checkpoint 1 — before coding (source/catalog/version inventory), Checkpoint 2 — during coding (source/data cross-reference and relationship/acceptance query), Checkpoint 3 — before merge (MCP build + focused security tests + archaeology stdio smoke) (+29 more)

### Community 206 - "Archaeology MCP — Read-Only Acceptance Report (2026-08-31)"
Cohesion: 0.05
Nodes (37): 0. Provenance, 10. Bounds / truncation summary, 11. Honest unsupported / gap notes, 12. Verification, 1. MateLevel objectives — `find_quest_objectives(family="mate_levels")`, 2. Skill 23085 relationships, 2a. `trace_skill(id=23085)`, 2b. `trace_references(identifier="23085", domain="skill")` (+29 more)

### Community 207 - "ArchaeologyService"
Cohesion: 0.13
Nodes (11): ArchaeologyService, IEnumerable, int, JsonNode, JsonObject, JsonSerializerOptions, MetadataCache, string (+3 more)

### Community 208 - "IBotStepExecutor"
Cohesion: 0.05
Nodes (31): EconomyDayCycleLedger, EconomyDayCycleLedgerExtensions, EconomyDayCycleScenario, CriterionVerdict, int, IScenarioWorldAdapter, List, Logger (+23 more)

### Community 209 - "GameScheduleManager"
Cohesion: 0.07
Nodes (16): GameScheduleManager, bool, Dictionary, List, Logger, TimeSpan, IGameScheduleManager, Dictionary (+8 more)

### Community 210 - "SkillTemplate"
Cohesion: 0.09
Nodes (12): ISkillManager, List, BuffEventTriggerKind, BuffTriggerTemplate, CombatBuffTemplate, SkillHitType, SkillProduct, int (+4 more)

### Community 211 - "M3aExitScenarioTests"
Cohesion: 0.08
Nodes (14): PacketCaptureSession, IPAddress, List, Socket, M3aExitScenarioTests, After, Before, Dictionary (+6 more)

### Community 212 - "LootingContainer"
Cohesion: 0.10
Nodes (15): LootingContainer, DateTime, Dictionary, float, HashSet, Item, List, Logger (+7 more)

### Community 213 - "MailOwnershipGuardTests"
Cohesion: 0.19
Nodes (10): MailOwnershipGuardTests, Action, After, Before, int, List, long, Task (+2 more)

### Community 214 - "PlayerBotScheduler"
Cohesion: 0.09
Nodes (17): PlayerBotScheduler, CancellationToken, CancellationTokenSource, ConcurrentDictionary, ConcurrentQueue, DateTime, Dictionary, int (+9 more)

### Community 215 - "FormulaManager"
Cohesion: 0.07
Nodes (20): FormulaManager, bool, CalculationEngine, Dictionary, Logger, IFormulaManager, CalculationEngine, Formula (+12 more)

### Community 216 - "NameManager"
Cohesion: 0.15
Nodes (14): NameManager, Dictionary, GeneratedRegex, Logger, object, ReadOnlySpan, Regex, string (+6 more)

### Community 217 - "MateGameData"
Cohesion: 0.12
Nodes (11): MateGameData, Dictionary, List, Logger, SqliteConnection, MateEquipSlotPack, MateEquipmentContainerAcceptTests, MateGameDataEquipLegalityTests (+3 more)

### Community 218 - "Buffs"
Cohesion: 0.11
Nodes (9): Buffs, Dictionary, int, List, Logger, object, Type, uint (+1 more)

### Community 219 - "NpcGroundingPolicyTests"
Cohesion: 0.12
Nodes (15): NpcGroundingPolicy, SpawnGroundingAction, DateTime, float, Logger, long, object, TimeSpan (+7 more)

### Community 220 - "BuffTests"
Cohesion: 0.17
Nodes (7): EffectState, BuffTests, Arguments, DateTime, Task, Test, Unit

### Community 221 - "NoBuffBuffs"
Cohesion: 0.06
Nodes (8): DamageType, NoBuffBuffs, Func, IEnumerable, List, MySqlConnection, MySqlTransaction, Type

### Community 222 - "SchedulerSoakStage1Runner"
Cohesion: 0.12
Nodes (18): BudgetVerdict, SchedulerSoakStage1Runner, BotDriveClient, CancellationToken, Func, IReadOnlyList, JsonElement, Regex (+10 more)

### Community 223 - ".Evaluate"
Cohesion: 0.12
Nodes (10): SpecialtyManager, Dictionary, EventArgs, List, Logger, MailForSpeciality, bool, int (+2 more)

### Community 224 - "AiGeoDataManager"
Cohesion: 0.16
Nodes (8): AiGeoDataManager, List, Logger, Queue, Vector3, AiNavigation, Vector3, Vector3

### Community 225 - "Task"
Cohesion: 0.13
Nodes (9): ExecutionBoundary, Logger, long, Before, PlayerBotSchedulerTests, Task, Test, AsyncLocal (+1 more)

### Community 226 - "PressureSample"
Cohesion: 0.13
Nodes (17): GameplayActorExpeditionTests, Member, Owner, Task, Test, Third, MerchantRigTapExtensions, MerchantRigTests (+9 more)

### Community 227 - "IDominionManager"
Cohesion: 0.11
Nodes (11): IDominionManager, DateTime, HashSet, IReadOnlyCollection, IReadOnlyList, Dominion, DateTime, SiegePhase (+3 more)

### Community 228 - "FamilyManager"
Cohesion: 0.13
Nodes (8): FamilyManager, Dictionary, Logger, Family, FamilyMember, List, MySqlConnection, MySqlTransaction

### Community 229 - "Item"
Cohesion: 0.18
Nodes (4): DateTime, DateTime, Task, Test

### Community 230 - "SkillManagerTests"
Cohesion: 0.16
Nodes (3): SkillManagerTests, Task, Test

### Community 231 - "IdleBehavior"
Cohesion: 0.09
Nodes (13): HoldPositionBehavior, bool, DateTime, Dictionary, double, float, TimeSpan, IdleBehavior (+5 more)

### Community 232 - "M3bExitPersistenceE2eTests"
Cohesion: 0.13
Nodes (14): M3bExitPersistenceE2eTests, DateTime, Fact, int, MySqlConnection, MySqlTransaction, Pitch, Roll (+6 more)

### Community 233 - "gen-manifests.py"
Cohesion: 0.10
Nodes (33): act_type_in(), build_manifest(), emit_census_meta(), event_shape(), load_item_groups(), load_npc_groups(), load_quest_acts(), main() (+25 more)

### Community 234 - "EconomyDayCycleScenarioRigTests"
Cohesion: 0.09
Nodes (17): Rig, StubHomeSource, Dictionary, Position, Vector3, Rig, FakeTimeProvider, List (+9 more)

### Community 235 - ".BoardVehicle"
Cohesion: 0.26
Nodes (6): GameplayActorM51BoardVehicleTests, Actor, Session, Task, Test, uint

### Community 236 - ".Run"
Cohesion: 0.13
Nodes (13): Skill, SkillCaster, SkillCastTarget, SkillObject, Task, PlotTree, DateTime, Logger (+5 more)

### Community 237 - "BuffTemplate"
Cohesion: 0.26
Nodes (7): GameplayActorQuestActionsTests, Actor, int, Session, Task, Test, uint

### Community 238 - "ILoadable"
Cohesion: 0.05
Nodes (31): CraftManager, Dictionary, Logger, ExpressTextManager, Dictionary, Logger, ICraftManager, IExpressTextManager (+23 more)

### Community 239 - ".View"
Cohesion: 0.05
Nodes (31): TimeSpan, RopeTensionHistory, ShipHarpoonRopeController, ConcurrentDictionary, DateTime, float, Logger, uint (+23 more)

### Community 240 - "AreaMissionNode"
Cohesion: 0.10
Nodes (21): AreaMissionBai, AreaMissionNode, BinaryReader, List, Logger, Vector3, AreaMissionType, NetMissionBai (+13 more)

### Community 241 - "Buff"
Cohesion: 0.11
Nodes (15): ReferenceEqualityComparer, BaiPointGrid, Entry, Dictionary, float, Func, int, Vector3 (+7 more)

### Community 242 - "ItemProcBindingTests"
Cohesion: 0.10
Nodes (15): UnitProcs, Dictionary, Func, List, Unit, CountingItemIdManager, EquipRig, ItemProcBindingTests (+7 more)

### Community 243 - ".DiscoverRoutesFromType"
Cohesion: 0.08
Nodes (26): RouteMapper, Dictionary, HttpMethod, MatchCollection, matches, MethodInfo, Type, BotActionControllerRouteTests (+18 more)

### Community 244 - "RequestController"
Cohesion: 0.20
Nodes (8): ReadOnlyMemory, ValueTask, LoginClient, CancellationToken, TimeSpan, ValueTask, ACEnterOtpPacket, ACEnterPcCertPacket

### Community 245 - "ArchaeologyMcpServerTests"
Cohesion: 0.26
Nodes (7): ArchaeologyMcpServerTests, JsonNode, Task, Test, DataRoot, DbPath, RepoRoot

### Community 246 - "Rig"
Cohesion: 0.09
Nodes (18): CharacterResurrection, Action, Func, int, Logger, Portal, PlayerBotSchedulerDeathWatchTests, RecordingExecutor (+10 more)

### Community 247 - "DominionManager"
Cohesion: 0.11
Nodes (13): DominionManager, DateTime, Dictionary, HashSet, int, IReadOnlyCollection, IReadOnlyList, List (+5 more)

### Community 248 - "SaveManager"
Cohesion: 0.32
Nodes (5): MathUtilTests, Arguments, Task, Test, AAEmu.UnitTests.Game.Utils

### Community 249 - "QuestManager"
Cohesion: 0.06
Nodes (18): SphereGameData, Dictionary, List, SqliteConnection, ChatBubbleKind, QuestTrigger, AreaSphereTriggerCondition, SphereAcceptQuestQuests (+10 more)

### Community 250 - ".VerifyLoadedState"
Cohesion: 0.15
Nodes (8): PlayerBotLifecycleAdapter, Logger, CharacterLifecycleReason, CharacterLifecycleService, ICharacterLifecycleService, IEnumerable, Logger, BotContext

### Community 251 - "SlaveGameData"
Cohesion: 0.09
Nodes (15): CharacterTemplateConfig, HousingBindingDoodad, CourtRoomConfig, JailConfig, JusticeConfig, List, SlaveModelAttachPoint, Dictionary (+7 more)

### Community 252 - "BigMonsterAttackBehavior"
Cohesion: 0.07
Nodes (20): FollowPathBehavior, bool, WildBoarAttackBehavior, bool, float, AiLua, AlmightyNpcAiParams, List (+12 more)

### Community 253 - ".CreateCraftRig"
Cohesion: 0.18
Nodes (8): ShipHarpoonRopeState, DateTime, Vector3, ShipHarpoonTowPhysics, float, IEnumerable, IReadOnlyList, RigidBody

### Community 254 - "ArcheAge Slums — Roadmap & Milestones (locked-shape 2026-08-03; version number retired 2026-08-04 — v1/v4/v6/v7 label drift, the date is canonical)"
Cohesion: 0.06
Nodes (32): ArcheAge Slums — Roadmap & Milestones (locked-shape 2026-08-03; version number retired 2026-08-04 — v1/v4/v6/v7 label drift, the date is canonical), Deferred validation gates (bot-backtrack program, 2026-08-12), Definition of done per milestone, Deployment discipline (exact-SHA, auditable), Experience scorecard (alongside the technical scorecard), M0 — Foundation ✅ COMPLETE, M10 — Territory and siege (deferred, two slices), M1 — Quest and progression spine (Track 1) (+24 more)

### Community 255 - "Navigation Domain — System Archaeology Dossier"
Cohesion: 0.06
Nodes (31): 1.1 The bot movement path (VERIFIED), 1.2 Stuck detection (VERIFIED), 1.3 World spatial structures available (VERIFIED), 1.4 Geodata / client-file assets the server already loads (VERIFIED code; data presence STRONGLY_INFERRED), 1.5 How NPCs move today (VERIFIED), 1.6 How ships/slaves/transfers/mates move today (VERIFIED), 1. WHAT EXISTS TODAY, 2.1 compact.sqlite3 (VERIFIED against the local copy, 679 tables enumerated) (+23 more)

### Community 256 - "DominionScheduleTests"
Cohesion: 0.19
Nodes (6): DominionRealDataTests, DominionScheduleTests, bool, SqliteConnection, Task, Test

### Community 257 - "ShipController"
Cohesion: 0.09
Nodes (16): IEnumerable, SlaveKind, ReplicationSmoothing, ShipController, ShipMassBoxDefaults, ShipMotionDefaults, bool, float (+8 more)

### Community 258 - "PvpAggressionSeamRigTests"
Cohesion: 0.25
Nodes (7): PvpAggressionSeamRigTests, Dictionary, Task, Test, uint, Victim, Attacker

### Community 259 - "BaiNavigationRigTests"
Cohesion: 0.13
Nodes (13): BaiNavigationRigTests, Before, Dictionary, IEnumerable, int, List, string, Task (+5 more)

### Community 260 - "A5 Physics / Tick Timing Stall Investigation Dossier (2026-09-01) — read-only"
Cohesion: 0.06
Nodes (31): 12h corrected soak — `a5-report-ct133.json` (SHA `1ce4664f`, FULL), 1. The two distinct failure modes, 2. What the evidence rules out, 3. What the evidence points to, 4. Exact measurements, 5. Limitations, 6. Recommended bounded experiment + host metrics, 6h canary (first run) — `g2-a5-tier3-sixhour-report.json` (FULL window, RSS-fail) (+23 more)

### Community 261 - "BotScenarioTemplate.cs"
Cohesion: 0.14
Nodes (10): CharacterAbilities, Dictionary, IEnumerable, List, MySqlConnection, MySqlTransaction, Ability, AbilityType (+2 more)

### Community 262 - ".Harvest"
Cohesion: 0.20
Nodes (9): GameplayActorHarvestTests, Actor, After, Before, Dictionary, Session, Task, Test (+1 more)

### Community 263 - "ModelManager"
Cohesion: 0.08
Nodes (12): IModelManager, ModelManager, bool, Dictionary, ActorModel, Dictionary, GameStance, Vector3 (+4 more)

### Community 264 - "AttachPointKind"
Cohesion: 0.13
Nodes (14): M3bFurniturePersistenceE2eTests, Fact, float, int, MySqlConnection, Pitch, Roll, string (+6 more)

### Community 265 - "TradeManager"
Cohesion: 0.13
Nodes (10): ITradeManager, TradeConfirmResult, TradeItemEntry, TradeManager, TradeTemplate, Dictionary, float, IReadOnlyList (+2 more)

### Community 266 - "NodeCell"
Cohesion: 0.09
Nodes (13): AABB, Vector3, Hmap, BinaryReader, List, NodeCell, BinaryReader, float (+5 more)

### Community 267 - "SummonSlave"
Cohesion: 0.30
Nodes (7): PvpFlaggingRigTests, Exception, Killer, Task, Test, uint, Victim

### Community 268 - "FloatingSkillController"
Cohesion: 0.03
Nodes (56): ServiceCollectionExtensions, IServiceCollection, ArsService, CancellationToken, ConcurrentDictionary, Task, ArsSession, IArsPhoneProvider (+48 more)

### Community 269 - "ArsServiceTests"
Cohesion: 0.10
Nodes (8): Session, Dictionary, IBaseProtocolHandler, IPAddress, PacketStream, SocketError, IPEndPoint, TcpSession

### Community 270 - "Partial-Wiring Deep-Dive: housing, auction, specialty-trade, items, mates, models"
Cohesion: 0.07
Nodes (29): 1. Housing — 9/9 tables wired (100%; scorecard coverage row still shows 38% — stale, pending regen; measured 9/9 = 100% core, 11/11 = 100% incl. item_housings), 2. Auction — 0/3 tables wired (scorecard 0%), 3. Specialty trade — 3/4 tables wired (75%), 4. Items — 32/54 tables wired (59%; scorecard says 58%), 5. Mates — 0/4 tables wired (scorecard 0%), but runtime exists, 6. Models — 1/4 tables wired (scorecard 0%), Evidence index (file:line), Honest assessment (+21 more)

### Community 271 - "SkillManager"
Cohesion: 0.08
Nodes (18): EventArgs, SkillManager, bool, Dictionary, List, Logger, Unit, DefaultSkill (+10 more)

### Community 272 - "SkillObject"
Cohesion: 0.08
Nodes (21): PackVehicleService, float, HashSet, IReadOnlyList, Logger, AttachPointKind, MountAttachedSkills, SlaveBindings (+13 more)

### Community 273 - "WorldConfig"
Cohesion: 0.10
Nodes (25): ClientDataConfig, List, AppConfiguration, Dictionary, NetworkConfig, AccountConfig, AccountDeleteDelayTiming, Configurations (+17 more)

### Community 274 - "PositionAndRotation"
Cohesion: 0.04
Nodes (25): IPressureProbe, PlayerBotSchedulerMetrics, PressureSample, SchedulerPressureProbe, Logger, FakeScheduler, CancellationToken, DateTime (+17 more)

### Community 275 - "ForceGenerator"
Cohesion: 0.07
Nodes (20): ForceGenerator, int, World, OneShotVelocityKick, bool, JVector, RigidBody, WhirlpoolShipPull (+12 more)

### Community 276 - ".RunStageAsync"
Cohesion: 0.14
Nodes (14): GateSoakRunner, BotDriveClient, CancellationToken, Dictionary, E2eQuestManifest, IReadOnlyList, Regex, Task (+6 more)

### Community 277 - "Gemini Handoff — AAEmu"
Cohesion: 0.12
Nodes (17): Active blockers and partials, Environment terminology, Evidence and benchmarks, Exact next steps for Gemini, Foundation and gameplay contract, Gemini Handoff — AAEmu, Human-only actions, Immediate next instructions for Gemini (+9 more)

### Community 278 - "1. (a) Character foot movement — walk/run, CSMoveUnitPacket, broadcasts, stop/halt"
Cohesion: 0.07
Nodes (28): 0. Flag legend, 1.1 The client-authored movement model (overview), 1.2 Wire surface, 1.3 The server handler path (what CSMoveUnitPacket executes), 1.4 Movement broadcast (what observers see), 1.5 Walk vs run — what canonical 1.2 defines, 1.6 Stop / halt semantics, 1.7 Movement-side buff/effect interactions (Move rework must not break these) (+20 more)

### Community 279 - "Rig"
Cohesion: 0.18
Nodes (14): CombatDecision, CombatDecisionTree, CombatRole, float, IReadOnlyList, Logger, uint, Unit (+6 more)

### Community 280 - ".SetupQuest"
Cohesion: 0.37
Nodes (4): QuestTests, bool, IEnumerable, Mock

### Community 281 - "MailTaxLifecycleTests"
Cohesion: 0.12
Nodes (15): ErrorMessageType, CharacterMessageOutput, IEnumerable, List, MailTaxLifecycleTests, After, Before, bool (+7 more)

### Community 282 - "AAEmu.Game.Services.WebApi"
Cohesion: 0.16
Nodes (9): BigMonsterAttackBehavior, bool, List, TimeSpan, BigMonsterAiParams, List, BigMonsterCombatSkill, LuaTable (+1 more)

### Community 283 - ".GetByType"
Cohesion: 0.21
Nodes (9): PlayerBotAuditSink, ConcurrentQueue, int, Logger, MySqlConnection, MySqlTransaction, PlayerBotAuditSinkTests, Task (+1 more)

### Community 284 - "HeightmapTester"
Cohesion: 0.10
Nodes (16): CollisionTriangle, JVector, Heightmap, JBoundingBox, HeightmapDetection, IDynamicTreeProxy, ulong, World (+8 more)

### Community 285 - ".BotControlMcp_Sidecar_LiveEvidence"
Cohesion: 0.13
Nodes (17): ActionMcpProtocol, BotControlActionMcpE2eTests, SidecarProcess, Fact, HttpClient, int, JsonElement, JsonNode (+9 more)

### Community 286 - "BotScenarioRigTests"
Cohesion: 0.07
Nodes (25): IBotStepExecutor, CancellationToken, Task, TimeSpan, UnwiredBotStepExecutor, CancellationToken, int, Logger (+17 more)

### Community 287 - "MailCodLifecycleTests"
Cohesion: 0.14
Nodes (12): MailCodLifecycleTests, After, Before, List, long, Task, Test, ulong (+4 more)

### Community 288 - "PvpFlaggingRigTests"
Cohesion: 0.08
Nodes (7): ICharacterManager, List, MySqlConnection, ExpandExpertLimit, ExpertLimit, AppellationTemplate, Expand

### Community 289 - "NpcMoveTowardsTests"
Cohesion: 0.15
Nodes (12): NpcMoveTowardsTests, After, Arguments, Before, bool, double, float, object (+4 more)

### Community 290 - ".SeedSingletons"
Cohesion: 0.09
Nodes (16): QuestCheckTimerRigTests, string, Task, Test, QuestCrimePointSupplyRigTests, string, Task, Test (+8 more)

### Community 291 - "JOSH-QAT-PACKET-M4-M5.x"
Cohesion: 0.07
Nodes (27): 0.1 Prerequisite: t_e1cf82c9 (test-infra card, assignee Tai), 0.2 Test venue: Mirage Isle (zone 183 / arche_mall_world, group 49), 0.3 Fast-forward command sequence (exact, t_e1cf82c9), 0. HOW THIS PACKET WORKS, 1.1 TESTING REQUIREMENTS, 1.2 PREREQUISITE SETUP, 1.3 TEST STEPS + PASS/FAIL, 1.4 VERDICT FORMAT (M4) (+19 more)

### Community 292 - "Undefined World Mechanics Dossier (2026-08-31) — read-only census of data/code surfaces with no gameplay consumer"
Cohesion: 0.07
Nodes (28): Classification & player visibility, Classification & player visibility, Classification & player visibility, Classification & player visibility, Classification & player visibility, Code (VERIFIED), Code (VERIFIED), Code (VERIFIED) (+20 more)

### Community 293 - "e2e-common.sh"
Cohesion: 0.18
Nodes (27): e2e_baseline_report(), e2e_boot_db(), e2e_boot_servers(), e2e_clone_game_data(), e2e_compose(), e2e_db_running(), e2e_db_up(), e2e_db_volume_exists() (+19 more)

### Community 294 - "STATUS — ArcheAge Slums (fork joshhmann/AAEmu)"
Cohesion: 0.06
Nodes (36): 2026-08-26 recovery reconciliation, 2026-08-27 MCP expansion, 2026-08-29 — Post-M7 readiness and closure: PB-002 aggro slice (historical/pre-fix context), 2026-08-30 — Post-M7 readiness and closure: PB-002 MateLevel rig proof and canonical-data boundary, 2026-08-30 — Post-M7 readiness: discovery-channel re-census at 9b8ba6317 (PB-002 evidence refresh), 2026-08-30 — Post-M7 readiness: PB-002 complete-quest composition + classifier reclassification (landed current state), 2026-08-30 — Post-M7 readiness: PB-002 complete-quest composition + classifier reclassification (landed current state; historical snapshot wording below), 2026-08-30 — Post-M7 readiness: PB-002 current objective frontier (historical/pre-rig snapshot; stale wording retained) (+28 more)

### Community 295 - "FriendMananger"
Cohesion: 0.11
Nodes (11): FriendMananger, FriendTemplate, Dictionary, List, Logger, IFriendManager, CharacterFriends, Dictionary (+3 more)

### Community 296 - "BuffTrigger"
Cohesion: 0.07
Nodes (19): AttackBuffTrigger, EventArgs, BuffTrigger, Buff, BuffTriggerTemplate, EventArgs, Logger, DamageBuffTrigger (+11 more)

### Community 297 - "AAEmu setup — reference"
Cohesion: 0.14
Nodes (14): AAEmu setup — reference, Config.Local templates, Downloads and HitL, Expected paths after extract, Game (`AAEmu.Game/Config.Local.json`), Inventory scripts (PowerShell + Bash), Launcher settings (`settings.aelcf`), Login (`AAEmu.Login/Config.Local.json`) — Path B (+ optional port remap) (+6 more)

### Community 298 - "IItemIdManager"
Cohesion: 0.11
Nodes (10): IItemIdManager, ItemIdManager, string, uint, CountingItemIdManager, IEnumerable, uint, CountingItemIdManager (+2 more)

### Community 299 - "GradeTemplate"
Cohesion: 0.10
Nodes (11): ItemGradeEnchantingSupport, GradeTemplate, GradeEnchant, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget (+3 more)

### Community 300 - "GameService"
Cohesion: 0.06
Nodes (27): ManagerOrchestrator, Action, Func, HashSet, IReadOnlyList, List, Logger, Task (+19 more)

### Community 301 - "PhysicsTelemetryTests"
Cohesion: 0.27
Nodes (4): PhysicsTelemetrySnapshot, PhysicsTelemetryTests, Task, Test

### Community 302 - "NpcGameData"
Cohesion: 0.13
Nodes (12): BBox, Vector3, LinkDescriptor, Vector3, Navigation, List, NodeDescriptor, Vector3 (+4 more)

### Community 303 - ".SendPacketAsync"
Cohesion: 0.06
Nodes (17): Accessory, Armor, BigFish, EquipItem, ItemDetailType, MusicSheetItem, SummonMate, SummonSlave (+9 more)

### Community 304 - ".CreateRig"
Cohesion: 0.24
Nodes (5): BotActionCommandQueueTests, After, Before, Task, Test

### Community 305 - ".M3aM4EconomicReplay_OnFixtureWorld_PassesConservationAndLifecycle"
Cohesion: 0.12
Nodes (13): FactionManager, bool, Dictionary, List, Logger, IFactionManager, SCFactionListPacket, SCFactionRelationListPacket (+5 more)

### Community 306 - "SpecialtyManagerTests"
Cohesion: 0.16
Nodes (7): Dictionary, Vector3, XmlNode, TransferGameData, Dictionary, Logger, SqliteConnection

### Community 307 - "AAEmu.UnitTests.Game.GameData"
Cohesion: 0.10
Nodes (14): AchievementGameDataTests, Task, Test, BuffGameDataTests, Task, Test, ItemGameDataTests, Task (+6 more)

### Community 308 - "GameControllerTests"
Cohesion: 0.25
Nodes (6): GameControllerTests, Mock, Task, Test, connection, sessionMock

### Community 309 - "AAEmu.ArchaeologyMcp"
Cohesion: 0.07
Nodes (14): ColumnInfo, DomainQueryException, ForeignKey, SearchScanCappedException, GameException, MarshalException, SubStream, long (+6 more)

### Community 310 - "ISession"
Cohesion: 0.16
Nodes (8): NpcGameData, Dictionary, List, NpcSkill, NpcSpawnerNpc, List, Logger, SkillUseConditionKind

### Community 311 - "BotAccountProvisioningService"
Cohesion: 0.10
Nodes (12): BotAccountProvisioningService, BotAccountType, BotProvisionedAccount, IBotAccountProvisioningService, byte, Logger, object, Regex (+4 more)

### Community 312 - ".DriveVehicle"
Cohesion: 0.10
Nodes (12): FloatingSkillController, bool, DateTime, float, Logger, TimeSpan, Vector3, MoveTypeEnum (+4 more)

### Community 313 - ".HandleChannelingFinish"
Cohesion: 0.18
Nodes (10): ISubZoneManager, SubZoneManager, List, Logger, Vector3, Point, IReadOnlyList, Vector3 (+2 more)

### Community 314 - "AAEmu.Game.Models.CryEngine.Entities"
Cohesion: 0.28
Nodes (6): DevMapperServiceTests, After, Before, string, Task, Test

### Community 315 - "BaiReader"
Cohesion: 0.23
Nodes (3): FlytrapAttackBehavior, bool, TimeSpan

### Community 316 - ".SendMessage"
Cohesion: 0.10
Nodes (16): AccessoryTemplate, Type, Wearable, WearableKind, WearableSlot, ArmorTemplate, Type, Wearable (+8 more)

### Community 317 - "WorldSpawnPosition"
Cohesion: 0.18
Nodes (15): GameplayActorStepExecutor, CancellationToken, ConcurrentDictionary, Func, Task, TimeProvider, TimeSpan, GameplayActorStepExecutorTests (+7 more)

### Community 318 - "SkillModifiers"
Cohesion: 0.30
Nodes (5): SkillModifier, SkillModifiers, Dictionary, List, SkillAttribute

### Community 319 - "ActiveRegionTickSpawnerScanTests"
Cohesion: 0.16
Nodes (11): ActiveRegionTickSpawnerScanTests, After, Before, Characters, ConcurrentDictionary, Manager, MethodInfo, object (+3 more)

### Community 320 - "SubCommandBaseTests"
Cohesion: 0.11
Nodes (11): NumericSubCommandParameter, StringSubCommandParameter, List, SubCommandParameterBase, SubCommandBaseTests, Arguments, IEnumerable, List (+3 more)

### Community 321 - "Active skills"
Cohesion: 0.08
Nodes (25): Active skills, Arc Lightning, Archery, Auramancy, Battlerage, Chain Lightning, Classes Status, Defense (+17 more)

### Community 322 - "Parameters"
Cohesion: 0.08
Nodes (24): `ActabilityRate`, `AutoSaveInterval`, `DaysForTaxPayment`, `ExpRate`, `GeoDataMode`, `GodMode`, `GoldLootMultiplier`, `GrowthRate` (+16 more)

### Community 323 - "Параметры"
Cohesion: 0.08
Nodes (24): `ActabilityRate`, `AutoSaveInterval`, `DaysForTaxPayment`, `ExpRate`, `GeoDataMode`, `GodMode`, `GoldLootMultiplier`, `GrowthRate` (+16 more)

### Community 324 - "Quest Runnability — M1-5 + M2 (wave closures + band 1-55 + lvl-99 straggler census)"
Cohesion: 0.08
Nodes (24): Band census (acceptance), FAIL rollup (by act family — top blockers), FAIL rollup (by stage reason), Headline, Quest Runnability — M1-5 + M2 (wave closures + band 1-55 + lvl-99 straggler census), Recommended fix-card queue, SKIP rollup (by reason), T10 — per-quest verdicts (+16 more)

### Community 325 - "FileManager"
Cohesion: 0.20
Nodes (7): GameNetwork, Logger, Type, GameProtocolHandler, ConcurrentDictionary, Logger, Type

### Community 326 - ".GetFileContents"
Cohesion: 0.15
Nodes (12): SCSkillFiredPacket, uint, ushort, SkillObject, SkillObjectItemGradeEnchantingSupport, SkillObjectPortalInfo, SkillObjectPosition, SkillObjectSavePortalInfo (+4 more)

### Community 327 - "IReadOnlyList"
Cohesion: 0.09
Nodes (14): BotMovableDecal, IBotAppearanceColorSource, ModelPalette, SqliteBotAppearanceColorSource, StaticBotAppearanceColorSource, StaticBotStartingEquipmentSource, Dictionary, IReadOnlyList (+6 more)

### Community 328 - "CharacterMails"
Cohesion: 0.11
Nodes (10): CharacterMails, List, CountUnreadMail, MailPlayerToPlayer, List, MailResult, MailTests, After (+2 more)

### Community 329 - ".Resolve"
Cohesion: 0.25
Nodes (6): SitPoseFallback, Dictionary, uint, SitPoseFallbackTests, Task, Test

### Community 330 - "ShipStaticBarrier"
Cohesion: 0.10
Nodes (20): ShipStaticBarrier, ShipStaticBarrierEntryDto, ShipStaticBarrierZones, int, IReadOnlyList, List, x0, x1 (+12 more)

### Community 331 - ".ForceState"
Cohesion: 0.25
Nodes (6): ZoneConflictType, TestableZoneConflict, ZoneConflictTests, List, Task, Test

### Community 332 - "PacketCaptureSession"
Cohesion: 0.12
Nodes (5): IQuestComponent, QuestComponent, List, QuestStep, Dictionary

### Community 333 - "SHIPS-01 Domain Dossier (2026-08-25 exploration)"
Cohesion: 0.08
Nodes (23): 10. Sharpest UNKNOWNs, 11. `/testslave` ("`/slavetest`") bug-hunt — packet errors + naked slaves ROOT-CAUSED & FIXED (2026-08-25), 12. Slice-1 Rowboat E2E — first live evidence: summon chain REAL, sailing physics DEAD (2026-08-25), 13. PB-006 RESOLVED — sailing was never physics-dead; one bridge bug silenced replication (2026-08-26), 1.1 Slave kinds (`AAEmu/Game/Models/Game/Slaves/SlaveKind.cs:3-17`), 1.2 Ship slaves table (`slaves`, kind → name; read-only sqlite), 1.3 Ship physics models (`ship_models`, 26 rows, ids 1–26), 1.4 Naval weapons as child slaves (`slave_bindings`) (+15 more)

### Community 334 - "BaseBaiLoader"
Cohesion: 0.07
Nodes (18): TimeSpan, TimeSpan, SpawningBehavior, bool, FlytrapAlertBehavior, bool, TimeSpan, TimeSpan (+10 more)

### Community 335 - "AAEmu.Game.Core.Network.Login"
Cohesion: 0.12
Nodes (12): ActorEffectLedger, ActorIdempotency, Outcome, Dictionary, Guid, HashSet, int, Queue (+4 more)

### Community 336 - "BotAppearanceFactory"
Cohesion: 0.08
Nodes (23): BotAppearance, BotAppearanceSpec, BotSupplyEntry, IReadOnlyList, IBotStartingEquipmentSource, BotAppearanceDefaults, IReadOnlyDictionary, Logger (+15 more)

### Community 337 - "BotPath"
Cohesion: 0.22
Nodes (11): BotPath, bool, float, IReadOnlyList, List, Vector3, PlayerbotM6LightTests, Task (+3 more)

### Community 338 - "AAEmu.Game.Models.Spheres"
Cohesion: 0.24
Nodes (7): QuestNoStartClusterTests, SqliteConnection, Task, Test, Type, uint, LoadedState

### Community 339 - "XmlWorldZone"
Cohesion: 0.12
Nodes (14): XmlWorld, ConcurrentDictionary, WorldTemplate, XmlNode, XmlWorldCell, WorldTemplate, XmlNode, XmlWorldSector (+6 more)

### Community 340 - "ScriptCompiler"
Cohesion: 0.09
Nodes (16): Scripts, ScriptCompiler, Assembly, Dictionary, IEnumerable, List, Logger, ScriptObject (+8 more)

### Community 341 - "BotAppearanceFactoryTests"
Cohesion: 0.21
Nodes (7): IReadOnlyList, BotAppearanceFactoryTests, byte, IReadOnlyList, Task, Test, uint

### Community 342 - ".Rig"
Cohesion: 0.15
Nodes (10): PlotAoeCondition, PlotEventCondition, PlotEventEffect, PlotEventTemplate, bool, LinkedList, PlotStep, LinkedList (+2 more)

### Community 343 - "QuestNoStartClusterTests"
Cohesion: 0.22
Nodes (7): PlayerbotPilotTests, Bot, Session, Task, Test, uint, PilotRun

### Community 344 - "Session"
Cohesion: 0.12
Nodes (10): LoginPacket, GLGameServerLoadPacket, GLPlayerEnterPacket, GLPlayerReconnectPacket, GLRegisterGameServerPacket, GLRequestInfoPacket, LGPlayerEnterPacket, LGPlayerReconnectPacket (+2 more)

### Community 345 - "GameplayActorB1ContractLayerTests"
Cohesion: 0.26
Nodes (9): BotControlApiE2eTests, Fact, Guid, HttpClient, JsonElement, string, Task, TimeSpan (+1 more)

### Community 346 - "PhysicsTelemetry"
Cohesion: 0.20
Nodes (8): PhysicsTelemetry, int, Lock, Logger, long, SampleRing, string, TimeProvider

### Community 347 - ".CreateRig"
Cohesion: 0.18
Nodes (7): CharacterCraft, float, Logger, Craft, List, CraftMaterial, CraftProduct

### Community 348 - "CharacterSkills"
Cohesion: 0.19
Nodes (7): CharacterSkills, Dictionary, List, MySqlConnection, MySqlTransaction, PassiveBuff, Unit

### Community 349 - "Task"
Cohesion: 0.11
Nodes (11): AuctionHouseTask, FishDetails, FishSchool, Task, DateTime, TimeSpan, UnitPointsRegenTask, TestTask (+3 more)

### Community 350 - "QuestActObjItemGroupUseTests"
Cohesion: 0.25
Nodes (9): QuestActObjItemGroupUse, Quest, QuestAct, QuestActObjItemGroupUseTests, Act, int, Task, Test (+1 more)

### Community 351 - "LeapSkillController"
Cohesion: 0.18
Nodes (10): LeapSkillController, float, Logger, TimeSpan, Vector3, LeapSkillControllerTests, Task, Test (+2 more)

### Community 352 - "LivestockInteractionTests"
Cohesion: 0.26
Nodes (7): LivestockInteractionTests, After, Before, int, Task, Test, uint

### Community 353 - "M3bFurniturePersistenceTests"
Cohesion: 0.16
Nodes (9): M3bFurniturePersistenceTests, After, Before, object, Task, Test, Type, uint (+1 more)

### Community 354 - "Unit Test Implementation Plan (xUnit) in `AAEmu.UnitTests`"
Cohesion: 0.09
Nodes (22): 1. Test Project Folder Structure, 2. Priority Classes for Test Coverage, 3. Dependency Isolation Recommendations (Moq), 4.1 `GameService`, 4.2 `GameNetwork`, 4.3 `CSBuyItemsPacket`, 4.4 `ItemGameData`, 4.5 `NpcGameData` (+14 more)

### Community 355 - "FAQ"
Cohesion: 0.09
Nodes (22): Can I still use manual setup or Docker, Client and launcher, Client crashes or cannot enter world, Config precedence after the recent PR wave, Configuration and networking, `DataAnnotation validation failed ... GameServers` on login startup, Do I still insert game servers into MySQL `aaemu_login.game_servers`, FAQ (+14 more)

### Community 356 - "QuestActObjAbilityLevel — Research Dossier (2026-08-30)"
Cohesion: 0.09
Nodes (21): 1. Scope, 2.1 Raw rows — `quest_act_obj_ability_levels` (15 rows), 2.2 Linked Progress acts — 11 carrier quests, 2.3 Orphaned / deleted quest contexts — 4 dangling act rows, 2.4 Start/accept components and unit_reqs gates, 2.5 Accept-channel status — zero accept surfaces for 10 of 11, 2.6 Quest supply / reward data, 2. Canonical data (compact.sqlite3, read-only) (+13 more)

### Community 357 - "M3 Canonical Circle-Back Audit — HOUSING-01 / FARM-01 / PROPERTY-01 vs live 1.2"
Cohesion: 0.09
Nodes (21): 0. TL;DR, 1.1 Dossier coverage — VERIFIED FULLY COVERED, 1.2 What M3a actually merged (vs dossier's engine-gap table), 1.3 Deco limits — partial-domains "dead weight" claim: CONFIRMED RESOLVED by M3a, 1. HOUSING-01 — placement-zone validation (dossier verify), 2.1 Crop growth timers — DATA-VERIFIED, 2.2 Watering — DATA-VERIFIED chain, engine path present, not test-covered, 2.3 Rot / wilt — DATA-VERIFIED, engine machinery exists, not test-covered (+13 more)

### Community 358 - "WI-11a — Band 0/null triage: classification + drop-decision evidence"
Cohesion: 0.09
Nodes (21): 1. Scope and method, 2. Headline, 3. Class A — no-components (92), 4. Class B — ltd-no-report (40), 5. Class C — no-Start (0 live), 6. Class D — other (83) — NOT modeled dead → WI-11b, 7. Decision ask — per-class GO/NO-GO (Josh), 8. WI-11b handoff — sweep population (56 contexts) (+13 more)

### Community 359 - "RecordingExecutor"
Cohesion: 0.13
Nodes (15): A, RecordingExecutor, Rig, BotId, CancellationToken, ConcurrentDictionary, ConcurrentQueue, DateTime (+7 more)

### Community 360 - "NetMissionReader"
Cohesion: 0.14
Nodes (6): SCBuffCreatedPacket, SCUnitDamagedPacket, int, SCUnitStatePacket, Unit, BaseUnitType

### Community 361 - "StubExpeditionIdManager"
Cohesion: 0.10
Nodes (10): ExpeditionIdManager, string, uint, IExpeditionIdManager, StubExpeditionIdManager, IEnumerable, uint, StubExpeditionIdManager (+2 more)

### Community 362 - "TimeManager"
Cohesion: 0.11
Nodes (8): ITimeManager, IDisposable, IObserver, TimeManager, bool, float, List, IObservable

### Community 363 - "BotParitySeedingTests"
Cohesion: 0.13
Nodes (11): CharacterManager, BotAppearance, Dictionary, Logger, MySqlConnection, BotParitySeedingTests, byte, List (+3 more)

### Community 364 - "Task"
Cohesion: 0.17
Nodes (9): SpecialtyManagerTests, After, Before, double, int, List, object, Type (+1 more)

### Community 365 - "FlytrapAttackBehavior"
Cohesion: 0.27
Nodes (8): PlotCondition, Logger, Skill, SkillCaster, SkillCastTarget, SkillObject, PlotConditionType, PlotVariableType

### Community 366 - "AbilityType"
Cohesion: 0.12
Nodes (15): DerivedStats, FinalMetrics, LogTail, MetricsSnapshot, SchedulerSoakStage1Result, SchedulerSoakStage1Tests, SoakSample, ValidityOutcome (+7 more)

### Community 367 - ".Apply"
Cohesion: 0.24
Nodes (15): QuestAcceptorShape, QuestComponentShape, QuestExpectShape, QuestGroupsShape, QuestGuardShape, QuestRewardItemShape, QuestScenarioManifest, QuestSkipShape (+7 more)

### Community 368 - "UnitCooldownsTests"
Cohesion: 0.21
Nodes (8): UnitCooldowns, ConcurrentDictionary, DateTime, Logger, UnitCooldownsTests, Arguments, Task, Test

### Community 369 - ".EconomyCycle_LedgerReconciles_AcrossGameProcessRestart"
Cohesion: 0.14
Nodes (14): EconomyDayCycleE2eTests, PersistedLedger, Count, Dictionary, Fact, JsonElement, List, SlotType (+6 more)

### Community 370 - ".M51_AttachedPackOnSlave_LoadedViaRealContractAction_SurvivesKill9_ByteEqual"
Cohesion: 0.15
Nodes (10): PilotProbeTests, PlayerbotPilotTestsAccess, Bot, Session, Task, Test, PlayerbotPilotRig, bool (+2 more)

### Community 371 - "M3bFurniturePersistenceE2eTests"
Cohesion: 0.15
Nodes (13): AttachmentSnapshot, BindingSnapshot, ItemSnapshot, M51AttachedPackRestartE2eTests, SlaveSnapshot, DateTime, Fact, int (+5 more)

### Community 372 - "WebApiSessionTests.cs"
Cohesion: 0.20
Nodes (11): MyRegexController, WebApiSessionFake, WebApiSessionTests, Arguments, HttpRequest, HttpResponse, MatchCollection, Task (+3 more)

### Community 373 - "ArcheAge 1.2 Data-Wiring Scorecard"
Cohesion: 0.07
Nodes (27): Archaeology MCP (2026-08-31) — greenfield read-only data server, ArcheAge 1.2 Data-Wiring Scorecard, Canonical resources — how 1.2 mechanics actually worked, Domain scorecard, Fork fixes (our lane, no upstream PR), Global mechanic ledger, Legend, M2 loop reconciliation (2026-08-28) (+19 more)

### Community 374 - "QuestActObjMateLevel — Research Dossier (2026-08-30)"
Cohesion: 0.10
Nodes (20): 1. Scope, 2.1 Raw rows — `quest_act_obj_mate_levels` (10 rows), 2.2 Linked Progress acts — 6 live carrier quests + 4 orphaned detail rows, 2.3 Quest topology — all 6 live quests share one shape, 2.4 Summon-item grant sources (canonical), 2.5 Gather-item grant sources (all real), 2. Canonical data (compact.sqlite3, read-only), 3. Objective semantics — `QuestActObjMateLevel.cs` (read fully) (+12 more)

### Community 375 - "Client"
Cohesion: 0.06
Nodes (13): BaseProtocolHandler, Client, BaseProtocolHandler, Dictionary, IPAddress, uint, ISession, Socket (+5 more)

### Community 376 - "Server"
Cohesion: 0.10
Nodes (11): Server, ConcurrentDictionary, Func, HashSet, IBaseProtocolHandler, IEnumerable, Logger, SocketError (+3 more)

### Community 377 - "AnimationManager"
Cohesion: 0.06
Nodes (18): AnimationManager, Dictionary, List, Logger, IAnimationManager, List, IWorldManager, List (+10 more)

### Community 378 - "PlayerBotAuditSink"
Cohesion: 0.08
Nodes (9): Spawn, uint, SpawnGrid, TestHeight, float, AStarViewSubCommand, IDictionary, IMessageOutput (+1 more)

### Community 379 - "PublicFarmManager"
Cohesion: 0.11
Nodes (11): IPublicFarmManager, Vector3, List, Vector3, PublicFarmManager, Dictionary, List, Logger (+3 more)

### Community 380 - "EquipItemTemplate"
Cohesion: 0.16
Nodes (8): TaskManager, ConcurrentDictionary, Func, HashSet, object, TimeSpan, uint, ParseOptions

### Community 381 - "WebApiServer"
Cohesion: 0.43
Nodes (4): StringExtensionsTest, Arguments, Task, Test

### Community 382 - "SubCommandParameterBase"
Cohesion: 0.15
Nodes (7): TimeOfDayObserver, Exception, StormShipLogic, Dictionary, float, uint, IObserver

### Community 383 - ".Execute"
Cohesion: 0.20
Nodes (9): M4_2TradePackRestartE2eTests, DateTime, Fact, float, MySqlConnection, string, Trait, uint (+1 more)

### Community 384 - "UnitTests"
Cohesion: 0.27
Nodes (4): UnitTests, Arguments, Task, Test

### Community 385 - "Program"
Cohesion: 0.14
Nodes (13): UpdatesForTransform, float, int, List, Quaternion, Vector3, Program, float (+5 more)

### Community 386 - "Dropped Content Register — quest_contexts & dangling rows"
Cohesion: 0.10
Nodes (19): 1. Dummy shells — 1391, 2. QUEST_NO_START cluster — 23 legacy tutorial shells, 3. Orphaned quest_contexts — 8 (of 28 audited), 4. Dangling accept-acts (chain B prune, not a context drop), 5. Related fix — NOT dropped (for contrast), 6069 drop record, 6. M2a engine-stuck cluster — 26 templates (old Sunny Wilderness), 7. M2a zero-component shells — 91 (reserve + Hadir cutscenes) (+11 more)

### Community 387 - ".HandleAsync"
Cohesion: 0.36
Nodes (4): BotControlMcpTests, JsonNode, Task, Test

### Community 388 - "Helpers"
Cohesion: 0.12
Nodes (9): Helpers, Assembly, bool, IEnumerable, List, long, Obsolete, string (+1 more)

### Community 389 - "SaveManagerTests"
Cohesion: 0.22
Nodes (6): Source, SourceCatalog, Dictionary, IReadOnlyList, List, string

### Community 390 - "SpecialtyManager"
Cohesion: 0.13
Nodes (3): TimeSpan, IAccountManager, DateTime

### Community 391 - "ItemConversionGameData"
Cohesion: 0.13
Nodes (12): ItemConversionGameData, Dictionary, List, SqliteConnection, ItemConversionProduct, int, uint, ItemConversionReagent (+4 more)

### Community 392 - "CharacterCraft"
Cohesion: 0.24
Nodes (9): GameplayActorDriveVehicleTests, Actor, After, Capture, object, Task, Test, Vector3 (+1 more)

### Community 393 - "4. Конкретные сценарии тестирования"
Cohesion: 0.11
Nodes (19): 1. Структура папок тестового проекта, 2. Приоритетные классы для покрытия тестами, 3. Рекомендации по изоляции зависимостей (Moq), 4.1 `GameService`, 4.2 `GameNetwork`, 4.3 `CSBuyItemsPacket`, 4.4 `ItemGameData`, 4.5 `NpcGameData` (+11 more)

### Community 394 - "📁 Test Files Overview"
Cohesion: 0.11
Nodes (19): Commons, Game/Core/Managers, Game/Core/Managers/Id, Game/Core/Managers/Name, Game/Core/Managers/UnitManagers, Game/Core/Managers/World, Game/Core/Network, Game/Core/Packets (+11 more)

### Community 395 - "📁 Обзор тестовых файлов"
Cohesion: 0.11
Nodes (19): Commons, Game/Core/Managers, Game/Core/Managers/Id, Game/Core/Managers/Name, Game/Core/Managers/UnitManagers, Game/Core/Managers/World, Game/Core/Network, Game/Core/Packets (+11 more)

### Community 396 - "NPC Visual Behavior — float / sit-pose / cloth / targeting (Recon B)"
Cohesion: 0.11
Nodes (18): 1.1 What the server does with spawn Z, 1.2 Census results (spawn Z vs heightmap terrain, |diff| buckets), 1.3 Hypotheses (evidence→confirm), 1. FLOATING, 2.1 What the server sends, 2.2 The data (sit anim ids in use in Solzreed/Bluemist), 2.3 Hypotheses, 2. SIT POSES ("knees in") (+10 more)

### Community 397 - "AAEmu.Game.csproj"
Cohesion: 0.11
Nodes (17): Microsoft.Data.Sqlite, NLog, OSVersionExt.NetStd, Microsoft.NET.Sdk, Discord.Net, Jace, Jitter2, Microsoft.CodeAnalysis.CSharp.Scripting (+9 more)

### Community 398 - "AccessLevelManager"
Cohesion: 0.24
Nodes (8): AccessLevelManager, List, Logger, IAccessLevelManager, AccessLevelManagerTests, Before, Task, Test

### Community 399 - "CommandManager"
Cohesion: 0.17
Nodes (9): FeaturesManager, Logger, IFeaturesManager, Feature, FeatureSet, byte, int, bitIndex (+1 more)

### Community 400 - "GameScheduleManager.cs"
Cohesion: 0.15
Nodes (11): PlotState, bool, Dictionary, List, Skill, SkillCaster, SkillCastTarget, SkillObject (+3 more)

### Community 401 - "BuffGameData"
Cohesion: 0.14
Nodes (9): BuffGameData, Dictionary, List, SqliteConnection, BuffTolerance, List, BuffToleranceCounter, DateTime (+1 more)

### Community 402 - "IGameDataLoader"
Cohesion: 0.16
Nodes (7): Road, List, RoadNode, Vector3, RoadMissionReader, int, List

### Community 403 - "LootPack"
Cohesion: 0.26
Nodes (11): ActabilityType, LootActabilityGroups, LootPack, count, Dictionary, itemId, List, Logger (+3 more)

### Community 404 - "EquipmentContainerLevelGateTests"
Cohesion: 0.21
Nodes (9): EquipmentContainer, EquipmentItemSlot, EquipmentItemSlotType, Item, List, EquipmentContainerLevelGateTests, Task, Test (+1 more)

### Community 405 - ".Apply"
Cohesion: 0.11
Nodes (15): SpecialEffect, CastAction, DateTime, SkillCaster, SkillCastTarget, SkillObject, SpecialEffectAction, CastAction (+7 more)

### Community 406 - ".GetList"
Cohesion: 0.25
Nodes (4): BotAppearanceDefaultsTests, Task, Test, Type

### Community 407 - "DiscordBotService"
Cohesion: 0.19
Nodes (6): AiGameData, Dictionary, List, Logger, AiEvent, NpcChatBubble

### Community 408 - "HousingBuildRaceProtectionTests"
Cohesion: 0.15
Nodes (7): SlaveGameData, Dictionary, List, Logger, SqliteConnection, SlaveInitialItemPacks, SlaveInitialItems

### Community 409 - ".SetupQuest"
Cohesion: 0.34
Nodes (4): QuestTests, Mock, Task, Test

### Community 410 - "ModelsJsonConverterTests"
Cohesion: 0.27
Nodes (5): ModelsJsonConverterTests, Arguments, Task, Test, Type

### Community 411 - ".Load"
Cohesion: 0.22
Nodes (8): QuestReportJournalLtdRigTests, string, Task, Test, QuestScenarioTests, string, Task, Test

### Community 412 - "AAEmu Unit Tests"
Cohesion: 0.11
Nodes (17): AAEmu Unit Tests, All Tests, CI Integration, Coverage Report, Guidelines, Priority 1 (Critical Systems), Priority 2 (Core Features), Priority 3 (Additional Features) (+9 more)

### Community 413 - "Housing Placement Mechanic — Canonical 1.2 Behavior + Data (HOUSING-01 dossier #1)"
Cohesion: 0.11
Nodes (17): 1. TL;DR, 2.1 The three data layers, 2.2 `housing_area.xml` — placement polygons (pak census), 2.3 `housing_areas` + `housing_groups` — the zoning rules (canonical 1.2), 2.4 `housing_group_categories` — the buildable-type matrix, 2.5 `housings` template fields that encode the canonical placement geometry, 2.6 How the original 1.2 server decided (reconstruction), 2.7 Related placement data (farms — same zone machinery) (+9 more)

### Community 414 - "PVP-01 Domain Dossier (2026-08-25 exploration)"
Cohesion: 0.11
Nodes (17): 1. Faction data + code, 2. Flagging + aggression packet inventory (CSOffsets.cs @ D4E6, client_12_r208022), 3. Honor / kill rewards (VERIFIED — engine path + headless rig), 4. Zone war interaction (ZONE-01 boundary, what's present vs missing), 5. Pirates + faction switch (the faction-choice moment), 6. Behavioral contract + sized slice 1, Addendum 2026-08-25 — OWNER RULING: contested honor values aligned to KR/RU official ("keep it korean"), Addendum 2026-08-25 — packet-gap sweep answers (+9 more)

### Community 415 - "4. Proposed update list for the M0 milestone state"
Cohesion: 0.11
Nodes (17): 1. How the wiki publishes (constrains every proposed update), 2. Per-page currency table, 3. Concrete findings, 4.1 NEW `Docs/wiki/Project-Status.md` — fork milestone status (the core M0 ask), 4.2 NEW `Docs/wiki/Golden-Route-Solzreed.md` — RECOVER (F3), 4.3 NEW `Docs/wiki/Quest-Test-Harness.md` — contributor-facing tooling, 4.4 UPDATE `Docs/wiki/Home.md`, 4.5 UPDATE `Docs/wiki/Developer-Notes.md` (+9 more)

### Community 416 - "AAEmu.UnitTests"
Cohesion: 0.15
Nodes (16): AAEmu.ArchaeologyMcp, Microsoft.Data.Sqlite, Microsoft.NET.Sdk, AAEmu.BotControl, Microsoft.NET.Sdk, AAEmu.BotControlMcp, Microsoft.NET.Sdk, AAEmu.UnitTests (+8 more)

### Community 417 - ".Write"
Cohesion: 0.04
Nodes (27): PacketLogLevel, CSJoinTrialAudiencePacket, CSLeaveTrialAudiencePacket, CSRequestJuryWaitingNumberPacket, CTCancelCellPacket, CTRequestCellPacket, SCBuffRemovedPacket, SCCombatClearedPacket (+19 more)

### Community 418 - "AiPathsManager"
Cohesion: 0.15
Nodes (11): AiPathsManager, Dictionary, List, Logger, object, string, IAiPathsManager, List (+3 more)

### Community 419 - "MailIdManager"
Cohesion: 0.14
Nodes (8): IMailIdManager, MailIdManager, string, uint, CountingItemIdManager, CountingMailIdManager, IEnumerable, uint

### Community 420 - "PropertyRepairService"
Cohesion: 0.27
Nodes (8): build_path(), export_files(), GroundHeightSampler, interpolate_segment(), main(), Estimates ground Z height using inverse-distance weighting from nearby NPC spawn, Interpolates points between p1 and p2 at regular spacing., Generates continuous 3D waypoints from raw 2D input line.

### Community 421 - "SubZoneManager"
Cohesion: 0.17
Nodes (9): TalkBehavior, bool, Dictionary, double, float, TimeSpan, uint, EventName (+1 more)

### Community 422 - "ZoneManager"
Cohesion: 0.20
Nodes (10): 1. Audit result and checkpoint, 2. Safe start: never use the dirty main checkout as a worktree, 3. Current MCP contract and evidence loop, 4. Combined workflow for every new actor family, 5. Asset-complete local stack, 6. Ordered next work, 7. Archaeology, blockers, and scorecard discipline, 8. Stop and escalate (+2 more)

### Community 423 - "SilentCatchLoggingTests"
Cohesion: 0.10
Nodes (16): CharacterManagerEquipmentSource, Logger, BotE2EBridgeBootstrap, Action, Func, Logger, ModuleInitializer, Task (+8 more)

### Community 424 - "Character"
Cohesion: 0.15
Nodes (6): Character, DurabilityLossTargets, ConcurrentDictionary, DateTime, HashSet, int

### Community 425 - "CharacterPortals"
Cohesion: 0.14
Nodes (8): GimmickMovementElevator, TimeSpan, Vector3, GimmickMovementFloatToSurface, TimeSpan, GimmickMovementHandler, TimeSpan, Vector3

### Community 426 - "OnEnterSphereArgs"
Cohesion: 0.19
Nodes (6): LinkRecord, WaypointSurfaceNavigation, List, WaypointSurfaceNavigationReader, int, List

### Community 427 - "PlotEventTemplate"
Cohesion: 0.16
Nodes (5): IMusicManager, MusicManager, Dictionary, Logger, SongData

### Community 428 - ".BotControlApi_ActionSurface_LiveEvidence"
Cohesion: 0.14
Nodes (3): IQuestManager, List, QuestSupplies

### Community 429 - "SchedulerSoakStage1Tests.cs"
Cohesion: 0.20
Nodes (7): PlotNextEvent, IEnumerable, PlotNode, List, Logger, PlotEventTemplate, PlotNextEvent

### Community 430 - "QuestScenarioManifest"
Cohesion: 0.25
Nodes (5): QuestScenarioTierTests, List, string, Task, Test

### Community 431 - "Per-commit verdicts (oldest first)"
Cohesion: 0.12
Nodes (16): 1. e9ace7f22 — PB-002 interaction objectives — **OK**, 2. dae7fb05e — TickManager test stabilization — **OK**, 3. 49f0aee07 — Sphere/Craft/Cinema legs + PlayCinema — **OK** (nits), 4. 970d6a557 — self-quest discovery + CurrentlyPlayingCinemaId — **OK**, 5. dae7fb05e / 69861b73c / fa56915e6 — Mail COD + TickManager — **ISSUES (transient) / OK**, 6. 0492b7199 — PVP WAR-HONOR rig tests — **ISSUES** (fixed by ac8953813), 7. 13b8bedb8 — WorldManager registration isolation — **OK**, 8. Docs commits (63436d0a9, 14388b702) — **ISSUES: STALE CLAIMS in HANDOFF-GEMINI.md** (+8 more)

### Community 432 - "NPC Pathing Recon — "enemies walking INTO hills" (server-side)"
Cohesion: 0.12
Nodes (16): 1. TL;DR, 2.1 Where movement is driven, 2.2 The move primitive — `Npc.MoveTowards` (Npc.cs:1157), 2.3 The Z query — `GetReferenceHeight` (WorldManager.cs:828) and `GetHeight` (757), 2.4 The pathfinder — `PathNode.FindPath` (A\* over navmesh), 2.5 Heightmap load paths, 2. Movement/pathing code — how it actually works, 3. Terrain data inventory (live 1.2 pak, aaemu box) (+8 more)

### Community 433 - "FIXED (evidence retained)"
Cohesion: 0.10
Nodes (19): Current source/evidence checkpoint (2026-08-28), FIXED (evidence retained), OPEN, PB-001 · Straight-line movement blocks interior/travel gameplay — IMPLEMENTATION LANDED / BROAD COVERAGE OPEN 2026-09-03, PB-002 · Progression ceiling: no viable quest content past curated Solzreed slice for bots — SCOPED SLICES LANDED / BROAD CLAIM OPEN 2026-09-03, PB-003 · Zone 46 Hadir Farm exit path (was: "no exit portal data"), PB-004 · Proximity-materialized dormant bots never step (scheduler not re-armed), PB-005 · NPC spawn Z is effectively unclamped — systemic ungrounded NPCs (floating / buried) (+11 more)

### Community 434 - "SourceCatalog"
Cohesion: 0.19
Nodes (7): ManaRegenManager, Dictionary, TimeSpan, ManaRegenTemplate, Logger, ManaRegenManagerTests, Test

### Community 435 - "McpServer"
Cohesion: 0.24
Nodes (6): McpServer, JsonNode, JsonObject, JsonSerializerOptions, string, Task

### Community 436 - ".NextPrime"
Cohesion: 0.28
Nodes (7): PrimeFinder, bool, int, PrimeFinderTests, Arguments, Task, Test

### Community 437 - ".ShouldLoadPersistentDoodad"
Cohesion: 0.37
Nodes (3): PropertyRestartRestorePolicyTests, Task, Test

### Community 438 - "MusicManager"
Cohesion: 0.20
Nodes (8): SiegeZoneTemplate, DateTime, TimeSpan, DeclareStart, PayoffMoment, SiegeEnd, SiegeStart, WarmupStart

### Community 439 - "ZoneConflict"
Cohesion: 0.05
Nodes (21): IZoneManager, List, Vector2, Vector3, ZoneManager, Dictionary, List, Logger (+13 more)

### Community 440 - "AiGameData"
Cohesion: 0.36
Nodes (4): TimeSpanExtensionsTests, Arguments, Task, Test

### Community 441 - "NpcGroupGameData"
Cohesion: 0.58
Nodes (3): ProtocolHandlerSpinGuardTests, Task, Test

### Community 442 - "BuffModifiers"
Cohesion: 0.28
Nodes (5): BuffModifier, BuffModifiers, Dictionary, List, BuffAttribute

### Community 443 - "CastAction"
Cohesion: 0.23
Nodes (9): CastAction, CastBuff, CastPlot, CastSkill, CastType, CastUnk2, CastUnk3, uint (+1 more)

### Community 444 - "JsonPosition"
Cohesion: 0.14
Nodes (10): JsonNpcPath, List, JsonPosition, Vector3, JsonSlaveSpawns, JsonPositionConverter, JsonReader, JsonSerializer (+2 more)

### Community 445 - "DominionRestartPersistenceE2eTests"
Cohesion: 0.27
Nodes (4): Loot, LootGroups, LootPackConvertFish, IComparable

### Community 446 - "Login Server Networking"
Cohesion: 0.12
Nodes (15): Architecture Overview, Binary Packet Format, Connection Cleanup, Connection Lifecycle, Error Handling and Shutdown, Expected vs Unexpected Disconnects, File Reference, Graceful Shutdown (+7 more)

### Community 447 - "AAEmu.UnitTests.Commons.Utils"
Cohesion: 0.20
Nodes (7): ForbiddenAreasType, AreasMissionReader, ConcurrentBag, int, List, Logger, Vector3

### Community 448 - ".Build"
Cohesion: 0.14
Nodes (7): AlertBehavior, bool, TimeSpan, Vector3, AlmightyAttackBehavior, bool, TimeSpan

### Community 449 - "SkillTests"
Cohesion: 0.33
Nodes (3): SkillTests, Task, Test

### Community 450 - ".CreateManager"
Cohesion: 0.30
Nodes (6): SimpleIdManagerTests, TestEntity, Task, Test, AAEmu.UnitTests.Login.Utils, TestEntity

### Community 451 - "Game Objects"
Cohesion: 0.12
Nodes (16): Ability, ActAbility, Appellations, BmPoints, Code Terminology, Dominion, Doodad, Expedition (+8 more)

### Community 452 - "ECONOMY Domain Dossier — MERCHANT-01 / LABOR-01 / ECON-01 / MAIL-01 (2026-08-25 exploration)"
Cohesion: 0.12
Nodes (15): 1. MERCHANT — how NPC shops actually work, 2. LABOR — the reconstructed model, 3. ECON CONSERVATION — invariant set (the ECON-01 C-dimension definition), 4. MAIL GAP — CSReturnMailPacket verdict: placeholder CONFIRMED; real 1.2 opcode UNRECOVERABLE from available evidence, 5. SLICE PLAN (smallest safe slices, PASS criteria), Caps (hardcoded, VERIFIED), Consumption (data-driven, with three hardcoded exceptions), Data layer (compact.sqlite3, read-only per AGENTS.md rule 3) (+7 more)

### Community 453 - "ActionMcpServer"
Cohesion: 0.24
Nodes (6): ActionMcpServer, JsonNode, JsonObject, JsonSerializerOptions, string, Task

### Community 454 - "AIManager"
Cohesion: 0.14
Nodes (8): AIManager, bool, List, Logger, object, TimeSpan, IAIManager, TimeSpan

### Community 455 - "BotAccountProvisioningServiceTests"
Cohesion: 0.23
Nodes (4): LoginConnection, IPAddress, LoginNetwork, Type

### Community 456 - "ActorRequest.cs"
Cohesion: 0.13
Nodes (14): BoardVehicleParams, CraftParams, CraftProductGrant, CraftResult, HouseBuildParams, InteractWithResult, LoadPackOntoVehicleParams, PlantParams (+6 more)

### Community 457 - ".SetupThreeActorRig"
Cohesion: 0.15
Nodes (8): IPlotManager, PlotManager, bool, Dictionary, Logger, Plot, PlotBuilder, Dictionary

### Community 458 - "FeatureSet"
Cohesion: 0.18
Nodes (4): ClientSource, List, Stream, ClientSourceType

### Community 459 - "IZoneManager"
Cohesion: 0.22
Nodes (3): ExtraDataFlags, SCSkillStartedPacket, FailSkill

### Community 460 - "FakeZoneManager"
Cohesion: 0.20
Nodes (7): BlockedTemplate, CharacterBlocked, Dictionary, List, MySqlConnection, MySqlTransaction, Blocked

### Community 461 - "RoamingBehavior"
Cohesion: 0.12
Nodes (9): AiParamType, AiUtils, Vector3, RoamingBehavior, bool, DateTime, TimeSpan, Vector3 (+1 more)

### Community 462 - "HoldPositionBehavior"
Cohesion: 0.16
Nodes (8): CharacterPortals, Dictionary, List, Logger, MySqlConnection, MySqlTransaction, Portal, VisitedDistrict

### Community 463 - "AAEmu.Game.Models.Game.Duels"
Cohesion: 0.36
Nodes (5): PlotTargetInfo, IEnumerable, List, PlotEventTemplate, Unit

### Community 464 - "GimmickMovementHandler"
Cohesion: 0.23
Nodes (7): WanderingSkillController, DateTime, float, Logger, Random, TimeSpan, Vector3

### Community 465 - ".SetupActAndQuest"
Cohesion: 0.25
Nodes (9): QuestActCheckGuard, Quest, QuestAct, QuestActCheckGuardTests, Act, Task, Test, uint (+1 more)

### Community 466 - "PlotNode"
Cohesion: 0.23
Nodes (4): TimedRewardsManager, bool, DateTime, TimeSpan

### Community 467 - "StormShipLogic"
Cohesion: 0.35
Nodes (4): VoxelMeshProcessor, Color, List, Vector3

### Community 468 - "Program"
Cohesion: 0.17
Nodes (9): Program, DateTime, Logger, string, Task, Thread, AutoResetEvent, IConfigurationRoot (+1 more)

### Community 469 - ".CalculateAngleFrom"
Cohesion: 0.18
Nodes (6): AddKit, GMItemKitConfig, GMItemKitItem, List, Logger, GMItemKitConfig

### Community 470 - "CharacterAbilitiesTests"
Cohesion: 0.29
Nodes (6): CharacterAbilitiesTests, After, Before, object, Task, Test

### Community 471 - "QuestScenarioVerdict"
Cohesion: 0.24
Nodes (3): ITaskManager, Task, TimeSpan

### Community 472 - "JOSH-QAT-WAVE4"
Cohesion: 0.13
Nodes (14): 0.1 Build prerequisite (read once), 0.2 Fast-forward commands (unchanged from the M4/M5.x packet), 0. HOW THIS PACKET WORKS, JOSH-QAT-WAVE4, MASTER VERDICT SHEET (fill in as you run), SOURCES (canonical, read from the current tree @ bfbea4093), W4-1 — MAIL RETURN (the 0x0a2 hypothesis), W4-2 — MAIL OWNERSHIP GUARDS [TWO-CLIENT] (+6 more)

### Community 473 - "JUSTICE DOMAIN Dossier — CRIME-01 / TRIAL-01 / PRISON-01 (2026-08-25 exploration)"
Cohesion: 0.13
Nodes (14): Addendum A1 (2026-08-25, later) — Client UI scripts mined (game_pak x2ui bytecode), Addendum A2 (2026-08-26) — Slice-1 CRIME leg verified end-to-end on a live stack, Attribution / findings, Behavioral contract (as reconstructed), C2G — 12 justice opcodes in `Core/Packets/C2G/CSOffsets.cs:106-117`, ALL present, registered, with handler classes, G2C — 25 justice opcodes in `SCOffsets.cs:356-379,383`; 21 sent by live code, 4 orphaned, Gaps (why W=1 was fair despite the code volume), JUSTICE DOMAIN Dossier — CRIME-01 / TRIAL-01 / PRISON-01 (2026-08-25 exploration) (+6 more)

### Community 474 - "AAEmu Fork — Fix/Feature Workflow (Tai's playbook, v4)"
Cohesion: 0.13
Nodes (14): AAEmu Fork — Fix/Feature Workflow (Tai's playbook, v4), CI gates (.github/workflows/dotnetcore.yml) — ALL must pass:, Deploy to prod (exact-SHA — see §Repository topology for full procedure), Environment, Fix/feature loop (per repo AGENTS.md + graph + CI), Fork merge quality bar, FORK-REVIEW CHECKLIST (pre-merge), One-way upstream sync (+6 more)

### Community 475 - "ArchaeologyMcpServer"
Cohesion: 0.25
Nodes (6): ArchaeologyMcpServer, JsonNode, JsonObject, JsonSerializerOptions, string, Task

### Community 476 - "MySqlConnectionFactory"
Cohesion: 0.14
Nodes (9): MySqlConnectionSettings, DBConnections, DBConnectionsConfig, string, IMySqlConnectionFactory, MySqlConnectionFactory, MySqlConnection, string (+1 more)

### Community 477 - ".Snapshot"
Cohesion: 0.30
Nodes (6): SaveDurationMetrics, SaveDurationMetricsSnapshot, TimeSpan, SaveDurationMetricsTests, Task, Test

### Community 478 - "AreaShape"
Cohesion: 0.27
Nodes (8): ActiveRegionTickTests, Characters, ConcurrentDictionary, int, Manager, MethodInfo, Task, Test

### Community 479 - "SCMateEquipmentChangedPacket"
Cohesion: 0.33
Nodes (5): SCMateEquipmentChangedPacket, bool, byte, uint, ushort

### Community 480 - "RoadMissionReader"
Cohesion: 0.21
Nodes (5): FixtureCyclePump, Guid, TimeSpan, uint, Vector3

### Community 481 - "AbilityItems"
Cohesion: 0.29
Nodes (4): StreamNetwork, Logger, Type, Type

### Community 482 - "CharacterBlocked"
Cohesion: 0.57
Nodes (4): PathNode, List, Queue, Vector3

### Community 483 - "QuestActConAcceptItem"
Cohesion: 0.19
Nodes (7): QuestActConAcceptItem, Quest, QuestAct, QuestActSupplyItem, Quest, QuestAct, IQuestActGenericItem

### Community 484 - "NumericExtensions"
Cohesion: 0.24
Nodes (3): NumericExtensions, JVector, Vector3

### Community 485 - "SqliteTestBase"
Cohesion: 0.06
Nodes (20): Unsubscriber, IObserver, List, TaskManagerTicker, CancellationTokenSource, Thread, CompositeSwap, SingletonSwap (+12 more)

### Community 486 - "test-aaemu-assets.sh"
Cohesion: 0.16
Nodes (7): add_result(), open_url(), R_DETAIL, R_NAME, R_PATH, R_STATUS, test-aaemu-assets.sh script

### Community 487 - "M1 Data-Defect Backlog — classification of verifier census findings (fix vs drop)"
Cohesion: 0.14
Nodes (13): 0. Task body vs actual census (corrections), 1. Verdict legend, 2. Summary table, 3. COMPONENT_NEXT_MISSING — 330, 776, 777 (5 ERR total = 3 here + 2 in §4), 4. ACT_REF_MISSING_QUEST — 1960 → 1961, 2145 → 2146, 5. QUEST_NO_START — 23 quests (all legacy tutorial shells), 6. QUEST_NO_COMPONENTS — 96 quests, 7. Orphaned quest_contexts — 28 ids (116 orphan `quest_components` rows) (+5 more)

### Community 488 - "Golden Route — Solzreed (Nuian)"
Cohesion: 0.14
Nodes (14): 1. The curated opening chain (recommended order), 1a. Arrival — notice board and first kills (level 1-3), 1b. Main village chain (level 3-6) — the story spine, 1c. Shepherd / pickaxe arc → the MOUNT chain (level 6, the M1 exit goal), 1d. Bloody Hand investigation (levels 4-10, parallel arc), 1e. Bounty board & side errands (optional, good exp, all PASS), 2. Chain map (kind-31 prerequisites at a glance), 3. What is gated on what (acceptance gates) (+6 more)

### Community 489 - "Track B: Manual setup workflow"
Cohesion: 0.14
Nodes (14): Build and run (manual), Database setup (manual), Docker workflow, Game server configuration (manual), Installation & Setup, Launch with Aspire, Launcher setup, Login server configuration (manual) (+6 more)

### Community 490 - "WI-6 — Band 41-50 ltd triage: quests 3419 / 4967 / 6069"
Cohesion: 0.14
Nodes (13): 1. Shape summary (from compact.sqlite3), 2. Completion-path analysis (can the engine EVER leave Progress?), 3419 — reachable ltd quest (recommendation: keep), 3419 — 의논할 수 없는 고민 ("An Undiscussable Worry"), 3. Accept-surface & dependency scan (all three), 4967 — reachable ltd quest (recommendation: keep), 4967 — 황금비늘의 후손 해방 ("Freeing the Golden Scale Descendant"), 4. Register-format records (draft — PENDING Josh) (+5 more)

### Community 491 - "Archaeology Data-Source Inventory — Dossier (2026-08-30)"
Cohesion: 0.14
Nodes (14): 10. Security recommendations (for allowlisted MCP root), 11. Top 5 sources required for the first useful queries, 1.1 Key table counts in `compact.sqlite3` (verified read-only), 1.2 Target-query data verified present, 1. Canonical reference data (primary), 2. AAEmu source (packet/protocol + engine), 3. SQL base / update / patch files, 4. Client files / game_pak / extracted client (local-machine paths) (+6 more)

### Community 492 - "Follow-up 2026-08-31 (second pass) — rebuilt server, fixes verified"
Cohesion: 0.14
Nodes (14): F0. Provenance (second pass), F1. Fix 1 — `trace_references` handles tables without an `id` column, F1a. `trace_references(identifier="3889", domain="quest")` — was ERROR, now OK, F1b. `trace_references(identifier="24165", domain="item")` — was ERROR, now OK, F1c. `trace_references(identifier="14878", domain="item")` — was ERROR, now OK, F2. Fix 2 — `trace_world_spawn` scans aggregate + per-world JSON with exact/whole-word matching, F2a. `trace_world_spawn(name="3554")` — JSON side fixed, F2b. `trace_world_spawn(name="arche_mall")` — aggregate exact match (+6 more)

### Community 493 - "DOMINION-01 Domain Dossier (2026-08-25 exploration)"
Cohesion: 0.14
Nodes (13): 1. DATA (compact.sqlite3 — reference; MySQL — mutable state), 2. CODE — wired vs orphaned, 3. PACKETS (Game direction), 4. BEHAVIORAL CONTRACT — the 1.2 dominion cycle, graded, 5. SIZED SLICE PLAN, Addendum A1 (2026-08-25, later) — Client game_pak mining: declare trigger RESOLVED, C2G — exactly 1, stub, compact.sqlite3 (`AAEmu.Game/Data/compact.sqlite3`) — 8 siege/dominion tables, 0 named `dominion*` (+5 more)

### Community 494 - "MAIL-01 Domain Dossier (2026-08-25 exploration)"
Cohesion: 0.14
Nodes (13): 1. Packet inventory (excluding CSReturnMailPacket — sibling lane), 2. MailManager wiring quality & attachment model, 3. Persistence schema audit (MySQL aaemu_game), 4. Behavioral contract per leg, 5. Mass mail / guild mail, 6. Cross-references to other lanes, Addendum A1 (2026-08-25, later) — Client mail UI mined: return button + fee constants, C2G (offsets: `AAEmu.Game/Core/Packets/C2G/CSOffsets.cs`, registration: `Core/Network/Game/GameNetwork.cs:166-174`) (+5 more)

### Community 495 - "Spawn-Z Data Defects — Classification + Correction (fix/npc-spawn-z)"
Cohesion: 0.14
Nodes (13): 1. Classification of the 99 rows (35 distinct NPCs), 2. The correction (15 rows, old → new Z), 3. The `// солдат платформа` comments — why FIX anyway, 4. Verification — before / after, 5. Deliverable-format note — why not `SQL/updates/`, 6. Files changed (branch fix/npc-spawn-z), 7. Rei gate (data semantics) + in-game confirm (Josh), FIX — true data-defect floaters (15 rows, 3 NPCs) (+5 more)

### Community 496 - "IBotControlClient"
Cohesion: 0.35
Nodes (7): BotControlClient, IBotControlClient, Body, HttpClient, HttpMethod, Status, Task

### Community 497 - ".UnixTime"
Cohesion: 0.42
Nodes (4): DateTime, HelpersTests, Task, Test

### Community 498 - "GameplayActorCastEffectTests"
Cohesion: 0.25
Nodes (7): ArrestBot, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 499 - "ShutdownTask"
Cohesion: 0.21
Nodes (7): ISaveManager, Task, ShutdownTask, bool, DateTime, int, List

### Community 500 - "WaypointSurfaceNavigationReader"
Cohesion: 0.18
Nodes (11): AAEmu setup (players and contributors), Agent behavior, Non-negotiables, Step 0 — Detect audience and path, Step 1 — Inventory assets (never blind-download), Step 2 — Machine prerequisites, Step 3 — Local config (gitignored), Step 4 — Start servers (+3 more)

### Community 501 - "WildBoarAttackBehavior"
Cohesion: 0.29
Nodes (7): GameplayActorCastAtTests, Actor, Session, Task, Test, uint, Vector3

### Community 502 - "CharacterMates"
Cohesion: 0.23
Nodes (7): CharacterMates, MateDb, DateTime, Dictionary, List, MySqlConnection, MySqlTransaction

### Community 503 - "Aggro"
Cohesion: 0.23
Nodes (7): Aggro, int, object, Unit, AggroExtensions, ConcurrentDictionary, AggroKind

### Community 504 - ".SetupActAndQuest"
Cohesion: 0.33
Nodes (7): QuestActConAcceptNpcKill, Quest, QuestAct, QuestActConAcceptNpcKillTests, Act, Task, Test

### Community 505 - "PlotState"
Cohesion: 0.17
Nodes (11): GateMetricsProbe, LogTail, RegionTickProbe, SaveProbe, SchedulerProbe, TickProbe, TickSample, bool (+3 more)

### Community 506 - "PlotTargetInfo"
Cohesion: 0.26
Nodes (7): SkillTargetSelection, SkillAreaTargetPrimaryTests, Task, Test, recorder, RecordingEffect, skill

### Community 507 - "WanderingSkillController"
Cohesion: 0.22
Nodes (8): KnockBack, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, Vector3

### Community 508 - ".BuildAreaSkill"
Cohesion: 0.30
Nodes (6): BotMountManager, float, Logger, BotMountManagerTests, Task, Test

### Community 509 - ".Execute"
Cohesion: 0.29
Nodes (8): CAPcCertNumberPacketHandler, CancellationToken, Task, CAPcCertNumberPacket, CAPcCertNumberPacketHandlerTests, Mock, Task, Test

### Community 510 - ".Execute"
Cohesion: 0.02
Nodes (94): ILoginSession, CancellationToken, Func, Task, ValueTask, LoginState, ILoginPacket, ILoginPacketDescriptor (+86 more)

### Community 511 - "TimeSpanExtensionsTests"
Cohesion: 0.25
Nodes (7): AuctionPostAuthority, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 512 - ".BuildState"
Cohesion: 0.24
Nodes (9): QuestNextComponentRigTests, Components, Dictionary, Quests, SanityReport, Task, Test, uint (+1 more)

### Community 513 - ".CapturedMails"
Cohesion: 0.27
Nodes (8): QuestDataOverlay, Dictionary, IReadOnlyDictionary, QuestDataOverlayTests, Dictionary, Task, Test, OverlayResult

### Community 514 - ".RegisterManifestItems"
Cohesion: 0.10
Nodes (17): QuestActReportJournalRigTests, string, Task, Test, QuestMateLevelRigTests, string, Task, Test (+9 more)

### Community 515 - "Dependencies and Downloads"
Cohesion: 0.15
Nodes (13): AAEmu Launcher (required for normal client login flow), AAEmu source code, ArcheAge 1.2 client (required for login/play tests), Aspire workflow, `compact.sqlite3` (required), Core runtime dependencies, Dependencies and Downloads, Game data and client dependencies (+5 more)

### Community 516 - "Documentation Map"
Cohesion: 0.15
Nodes (13): ![AAEmu](https://i.imgur.com/NFDY376.png), Configuration, Contributing Docs, Documentation Map, Getting Started, Help and Support, Legacy Community Guides, Operations and Troubleshooting (+5 more)

### Community 517 - "FEATURE TEMPLATE — Track 2 / our-lane feature (strict workflow, fork-only)"
Cohesion: 0.15
Nodes (12): Canonical 1.2 grounding (NEVER invent mechanics), Deliverables, Division routing (who owns which phase), EXAMPLE — feature.md filled in (SHAPE EXAMPLE: premium → labor regen wiring), Feature, FEATURE TEMPLATE — Track 2 / our-lane feature (strict workflow, fork-only), Get up to speed (first 10 minutes, in order), Plan (order matters) (+4 more)

### Community 518 - "FIX TEMPLATE — Track 1 canonical fix (strict workflow, lane gate: NO upstream PR)"
Cohesion: 0.15
Nodes (12): Bug, Canonical 1.2 grounding (NEVER invent mechanics), Deliverables, Division routing (who owns which phase), EXAMPLE — fix.md filled in (real task: t_71e48494, BUG-006 kill-acceptor), FIX TEMPLATE — Track 1 canonical fix (strict workflow, lane gate: NO upstream PR), Get up to speed (first 10 minutes, in order), Plan (order matters) (+4 more)

### Community 519 - "M1 Data-Defect Backlog — classification of verifier census findings (fix vs drop)"
Cohesion: 0.15
Nodes (12): 0. Task body vs actual census (corrections), 1. Verdict legend, 2. Summary table, 3. COMPONENT_NEXT_MISSING — 330, 776, 777 (5 ERR total = 3 here + 2 in §4), 4. ACT_REF_MISSING_QUEST — 1960 → 1961, 2145 → 2146, 5. QUEST_NO_START — 23 quests (all legacy tutorial shells), 6. QUEST_NO_COMPONENTS — 96 quests, 7. Orphaned quest_contexts — 28 ids (116 orphan `quest_components` rows) (+4 more)

### Community 520 - "A5 Physics / Memory Investigation — Durable Handoff (2026-09-02)"
Cohesion: 0.14
Nodes (13): 10. Safe deployment / stop conditions, 11. Boundaries (preserved), 12. Ephemeral testing-lane paths / PIDs (valid at handoff time), 1. Current HEAD / provenance, 2. Production CT133 post-memory state — exact Mai evidence (user/Mai operational), 3. Historical soak boundary (unchanged, preserved), 4. Current calibration lane status (independently verified — NEW), 5. What is completed (+5 more)

### Community 521 - "1. Quest engine, end-to-end"
Cohesion: 0.15
Nodes (12): 1. Quest engine, end-to-end, 2. `quest_act_*` table coverage (65 tables), 3. Upstream-broken quests (issue # → real quest id), 4. What fixing the most common failure classes takes, Accept, Complete, Findings summary, Load path (all in `QuestManager`, no separate `QuestGameData`) (+4 more)

### Community 522 - "AAEmu.BotControl"
Cohesion: 0.21
Nodes (6): AddArgs, RelocateArgs, RemoveArgs, AAEmu.BotControlMcp, AAEmu.UnitTests.BotControl, AAEmu.BotControl

### Community 523 - "AAEmu.BotControlMcp — contract-action MCP sidecar"
Cohesion: 0.17
Nodes (10): Gameplay actor to MCP coverage matrix, AAEmu.BotControlMcp — contract-action MCP sidecar, Bounded live smoke (requires an isolated Game WebApi), Client-neutral workflow, Deferred actor actions, Manual smoke (raw JSON-RPC), Registering with an MCP client, Running (+2 more)

### Community 524 - ".Run"
Cohesion: 0.25
Nodes (7): DominionTaxInKind, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 525 - "LocalizationManager"
Cohesion: 0.29
Nodes (5): SharpwindMinesNavigationTests, After, Before, Task, Test

### Community 526 - "PlotManager"
Cohesion: 0.33
Nodes (6): BotDriveBridgeTeleportRegionTests, float, Func, Session, Task, Test

### Community 527 - ".Schedule"
Cohesion: 0.25
Nodes (7): FinishChanneling, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 528 - "GameNetwork"
Cohesion: 0.24
Nodes (7): GateBudgetEvaluator, GateBudgets, GateMetricsSnapshot, GateStageConfig, GateStageResult, GateStages, AAEmu.Commons.Utils.Gate

### Community 529 - "GameDataManager"
Cohesion: 0.13
Nodes (11): ITaxationsManager, Dictionary, TaxationsManager, Dictionary, Logger, GameDataManager, bool, List (+3 more)

### Community 530 - "SphereGameData"
Cohesion: 0.25
Nodes (7): GainItemWithPosImprint, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 531 - "CharacterAppellations"
Cohesion: 0.08
Nodes (11): INameManager, CharacterCreateError, HeadlessSessionProvisioningTests, AccountId, Dictionary, Name, Task, Test (+3 more)

### Community 532 - "QuestActCheckTimer"
Cohesion: 0.19
Nodes (5): QuestActCheckTimer, Quest, QuestAct, OnQuestStepChangedArgs, OnTimerExpiredArgs

### Community 533 - "QuestActEtcItemObtain"
Cohesion: 0.27
Nodes (4): QuestActEtcItemObtain, Quest, QuestAct, OnItemGatherArgs

### Community 534 - "QuestActObjCinema"
Cohesion: 0.19
Nodes (5): QuestActObjCinema, Quest, QuestAct, OnCinemaEndedArgs, OnCinemaStartedArgs

### Community 535 - "QuestActObjMateLevel"
Cohesion: 0.30
Nodes (4): QuestActObjMateLevel, Quest, QuestAct, OnMateLevelUpArgs

### Community 536 - "WorldPosTests"
Cohesion: 0.30
Nodes (5): WorldPos, WorldPosTests, Arguments, Task, Test

### Community 537 - "AddKit"
Cohesion: 0.33
Nodes (6): GameplayActorTransferRideTests, Actor, Session, Task, Test, uint

### Community 538 - "GateSoakRunner.cs"
Cohesion: 0.02
Nodes (50): PackLoadData, PackLoadResult, AuctionBuyParams, AuctionPostParams, BuyParams, SellParams, SwapAction, FormulaKind (+42 more)

### Community 539 - ".Execute"
Cohesion: 0.25
Nodes (4): Teleport, List, string, TPloc

### Community 540 - ".OptOutConfinedToRoamExecutor_ObserverMovementStreamStillFlows"
Cohesion: 0.24
Nodes (4): MaterialsListFile, List, AAEmu.Game.Models.CryEngine.Objects, CgfConverter.Structs

### Community 541 - "FakeScheduler"
Cohesion: 0.27
Nodes (4): BehaviorKind, Dictionary, Transition, TransitionEvent

### Community 542 - ".BuildState"
Cohesion: 0.26
Nodes (8): QuestActRefMissingQuestRigTests, Components, Dictionary, Quests, SanityReport, Task, Test, uint

### Community 543 - ".TeleportWithRegionSync_CharacterReRegistered_DestinationBroadcastsResolveIt"
Cohesion: 0.11
Nodes (11): TimeSpan, DoodadFuncFakeUse, Doodad, DoodadFuncSkillHit, Doodad, ItemProc, DateTime, Unit (+3 more)

### Community 544 - ".NewBot"
Cohesion: 0.25
Nodes (7): AddExpeditionContributionPoint, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 545 - "NumericSubCommandParameterTests"
Cohesion: 0.53
Nodes (5): NumericSubCommandParameterTests, Arguments, Task, Test, Type

### Community 546 - "COMMUNITY-GUIDELINES.md — Historical Upstream-Awareness Reference"
Cohesion: 0.17
Nodes (11): 1. Hard requirements from CONTRIBUTING.md, 2. AGENTS.md — the 7-step workflow (mandatory order), 3. Code style (from `.editorconfig` + AGENTS.md), 4. CI gates on upstream PRs (what must pass), 5. Greptile review — what it checks (from #1494), 6. Conventional Commits — adopt on our fork (recommended), 7. Historical PR checklist (reference only; do not publish upstream), 8. Fork-internal vs upstream differences (+3 more)

### Community 547 - "![AAEmu](https://i.imgur.com/NFDY376.png)"
Cohesion: 0.17
Nodes (10): Commit messages, Contributing, How to make a clean pull request, ![AAEmu](https://i.imgur.com/NFDY376.png), Can I contribute?, Contributing, Discussion, Licensing information (+2 more)

### Community 548 - "❌ What Still Needs to Be Done (to reach 50% coverage)"
Cohesion: 0.17
Nodes (12): 1.1 Item System, 1.2 Skill System, 1.3 Quest System, 2.1 C2G (Client-to-Game) Packet Handlers, 2.2 G2C (Game-to-Client) Packet Handlers, 3.1 Characters, 3.2 NPCs and Mobs, 3.3 World and Zones (+4 more)

### Community 549 - "Application components"
Cohesion: 0.17
Nodes (12): Application components, ArcheAge client, ArcheAge reference database (SQLite, read-only), ArcheAge state database (MySQL, read/write), Aspire AppHost (optional orchestration), Data components, Game launcher, Game server (+4 more)

### Community 550 - "Docker Installation Guide"
Cohesion: 0.17
Nodes (12): Docker Installation Guide, Important configuration notes, Initial install, Launch, Login container runtime, Prerequisites, Production redeploy (CT 133) — read before updating, Related (+4 more)

### Community 551 - "New & Fixed"
Cohesion: 0.17
Nodes (11): Data hygiene (nothing you'll miss), For the operators, Known & intentional, New & Fixed, Patch Notes — M1: The Quest-and-Progression Spine, Quest chains repaired (the silent dead-ends), Quest engine reliability, Rollback (+3 more)

### Community 552 - "Quest Runnability — M1-5 scenario harness census"
Cohesion: 0.17
Nodes (11): FAIL rollup (by act family — top blockers), FAIL rollup (by stage reason), Harness-gap queue (SKIP-driven — extend the harness, not the engine), Headline, Quest Runnability Census — harness tiers T1/T2/T3, Quest Runnability — M1-5 scenario harness census, Recommended fix-card queue, SKIP rollup (by reason) (+3 more)

### Community 553 - "EXPLORER TEMPLATE — deep-dive / recon (feeds the scorecard)"
Cohesion: 0.17
Nodes (11): Budget awareness (CRITICAL — the quests explorer trap), Canonical 1.2 grounding (NEVER invent mechanics), Deliverables, Division routing (who owns which phase), Evidence requirements (every claim must be checkable), EXAMPLE — explorer.md filled in (real deep-dive: quests domain report), EXPLORER TEMPLATE — deep-dive / recon (feeds the scorecard), Get up to speed (first 10 minutes, in order) (+3 more)

### Community 554 - "FEATURE TEMPLATE — Track 2 / our-lane feature (strict workflow, fork-only)"
Cohesion: 0.17
Nodes (11): Canonical 1.2 grounding (NEVER invent mechanics), Deliverables, Division routing (who owns which phase), Feature, FEATURE TEMPLATE — Track 2 / our-lane feature (strict workflow, fork-only), Get up to speed (first 10 minutes, in order), Plan (order matters), Rei verification gate (evidence required — this task is NOT done without it) (+3 more)

### Community 555 - "FIX TEMPLATE — Track 1 canonical fix (strict workflow, lane gate: NO upstream PR)"
Cohesion: 0.17
Nodes (11): Bug, Canonical 1.2 grounding (NEVER invent mechanics), Deliverables, Division routing (who owns which phase), FIX TEMPLATE — Track 1 canonical fix (strict workflow, lane gate: NO upstream PR), Get up to speed (first 10 minutes, in order), Plan (order matters), Rei verification gate (evidence required — this task is NOT done without it) (+3 more)

### Community 556 - "AAEmu Living World — Canonical Notes (AzerothCore Inspiration)"
Cohesion: 0.17
Nodes (11): AAEmu Living World — Canonical Notes (AzerothCore Inspiration), Core Philosophy, Guiding Principle, Headless Sessions, Inspiration Modules, Lessons from AzerothCore, Living World Principle, Long-Term Vision (+3 more)

### Community 557 - "fix/no-start-1533 — pass-after evidence (t_43927087)"
Cohesion: 0.17
Nodes (11): 1. Verifier census — fail-before → pass-after (`Scripts/quest_no_start_census.sh`), 2. Drop-patch drift (patch applied to a pristine copy), 3. Regression coverage (flipped rig + verifier tests), 4. Full fast gate — `./scripts/gate.sh`, 5. Reference DB untouched, Cluster quest ids (23), Evidence commit, fix/no-start-1533 — pass-after evidence (t_43927087) (+3 more)

### Community 558 - "SubStream"
Cohesion: 0.20
Nodes (10): Follow-up 2026-08-31 (third pass) — npc_spawners DB-side name matching fixed, G0. Provenance (third pass), G1. Fix 3 — `npc_spawners` DB-side name matching (bounded candidates + exact/whole-word C# filter), G1a. `trace_world_spawn(name="3554")` — overmatch eliminated, G1b. `trace_world_spawn(name="arche_mall")` — unchanged, exact, G1c. `trace_world_spawn(name="instance_library")` — unchanged, whole-word, G1d. `trace_world_spawn(zone_id=260)` — unchanged, G2. `trace_references` re-verified (unchanged, still fixed) (+2 more)

### Community 559 - "GateStageConfig"
Cohesion: 0.36
Nodes (6): PlayerBotControllerAdapterTests, Session, Task, Test, Adapter, Controller

### Community 560 - "FishSchoolManager"
Cohesion: 0.20
Nodes (9): 1. In-Game Manual Walk Mode (`/mapper`), 2. Redline Map Tool (`redline_to_path.py`), 3. Zone NPC & Road Heatmap Generator (`generate_zone_heatmap.py`), 4. Doodad Obstacle Extractor (`extract_doodad_obstacles.py`), 5. Beyond Solzreed Inter-Zone Highways (Levels 15–30), 6. Runtime Obstacle Avoidance (`ObstacleManager`), 7. Generated Vector Heatmaps & Catalogs, Commands (+1 more)

### Community 561 - "DoodadSaveSubCommand"
Cohesion: 0.25
Nodes (7): HudBattlefieldAuthority, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 562 - "OnReportDoodadArgs"
Cohesion: 0.29
Nodes (4): QuestActConReportDoodad, Quest, QuestAct, OnReportDoodadArgs

### Community 564 - "OnReportNpcArgs"
Cohesion: 0.39
Nodes (3): LocalizationManager, Dictionary, Logger

### Community 565 - "QuestActObjCraft"
Cohesion: 0.29
Nodes (4): QuestActObjCraft, Quest, QuestAct, OnCraftArgs

### Community 566 - "QuestActObjExpressFire"
Cohesion: 0.29
Nodes (4): QuestActObjExpressFire, Quest, QuestAct, OnExpressFireArgs

### Community 567 - "QuestActObjInteraction"
Cohesion: 0.29
Nodes (4): QuestActObjInteraction, Quest, QuestAct, OnInteractionArgs

### Community 568 - "QuestActObjItemUse"
Cohesion: 0.29
Nodes (4): QuestActObjItemUse, Quest, QuestAct, OnItemUseArgs

### Community 569 - "QuestActObjLevel"
Cohesion: 0.10
Nodes (15): QuestActObjCompleteQuest, Quest, QuestAct, QuestActObjDistance, Quest, QuestAct, QuestActObjItemGather, Quest (+7 more)

### Community 570 - "OnMonsterGroupHuntArgs"
Cohesion: 0.29
Nodes (4): QuestActObjMonsterGroupHunt, Quest, QuestAct, OnMonsterGroupHuntArgs

### Community 571 - "OnMonsterHuntArgs"
Cohesion: 0.29
Nodes (4): QuestActObjMonsterHunt, Quest, QuestAct, OnMonsterHuntArgs

### Community 572 - "OnTalkMadeArgs"
Cohesion: 0.29
Nodes (4): QuestActObjTalk, Quest, QuestAct, OnTalkMadeArgs

### Community 573 - "OnTalkNpcGroupMadeArgs"
Cohesion: 0.25
Nodes (7): ItemEvolvingReRoll, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 574 - "AuctionController"
Cohesion: 0.20
Nodes (9): 1. Executive Summary, 2. Complete Archaeology Census (191 Quests), 3. Deep Breakdown of the 70 System-Driven Quests, 4. Architectural Contract & Policy Ruling, A. Ayanad Library Room & Floor Bounties (68 Quests), B. Tutorial / Prologue Cinematic Sequence Chains (10 Quests), C. World Events, Rifts & Honor Battlefields (8 Quests), Component-Only Quests: Archaeology Analysis & System Deferral (+1 more)

### Community 575 - "WebApiSession"
Cohesion: 0.05
Nodes (28): GameDataAttribute, UnitAttributeAttribute, List, IController, RouteDefinition, HttpMethod, WebApiGetAttribute, WebApiPostAttribute (+20 more)

### Community 576 - "JsonModelsConverter"
Cohesion: 0.22
Nodes (7): JsonModelsConverter, Dictionary, JsonReader, JsonSerializer, JsonWriter, Type, JsonConverter

### Community 577 - "RandomExtensionsTests"
Cohesion: 0.25
Nodes (7): LearnSpecialAbility, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 578 - "GameplayActorInteractWithTests"
Cohesion: 0.22
Nodes (4): List, NpcGroup, NpcGroupMember, AAEmu.Game.Models.Game.NpcGroup

### Community 579 - ".CreateActorOnUniqueWorld"
Cohesion: 0.25
Nodes (7): CancelOngoingBuff, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 580 - "SCUnitStatePacketVisualOptionsTests"
Cohesion: 0.38
Nodes (4): SCUnitStatePacketVisualOptionsTests, Task, Test, Type

### Community 581 - ".LoadManifest"
Cohesion: 0.47
Nodes (4): QuestDailyResetRigTests, string, Task, Test

### Community 582 - "2. Covered Components"
Cohesion: 0.18
Nodes (11): 1. Testing Infrastructure, 2. Covered Components, Added 06.03.2026:, ✅ Completed Tasks, Core Managers, GameData Classes, Models, Network Layer (+3 more)

### Community 583 - "2. Покрытые тестами компоненты"
Cohesion: 0.18
Nodes (11): 1. Инфраструктура тестирования, 2. Покрытые тестами компоненты, Core Managers (Ядро), GameData Classes, Models (Модели), Network Layer (Сетевой слой), Packets (Пакеты), Services (Сервисы) (+3 more)

### Community 584 - "Common issues"
Cohesion: 0.18
Nodes (11): Aspire does not start services, Common issues, Crash after selecting server, `DataAnnotation validation failed ... GameServers`, Game cannot load world assets, Important change, Linux file descriptor errors, Mini Troubleshoot Guide (+3 more)

### Community 585 - "EXPLORER TEMPLATE — deep-dive / recon (feeds the scorecard)"
Cohesion: 0.18
Nodes (10): Budget awareness (CRITICAL — the quests explorer trap), Canonical 1.2 grounding (NEVER invent mechanics), Deliverables, Division routing (who owns which phase), Evidence requirements (every claim must be checkable), EXPLORER TEMPLATE — deep-dive / recon (feeds the scorecard), Get up to speed (first 10 minutes, in order), Goal shape (pick ONE — a scattershot exploration is a wasted budget) (+2 more)

### Community 586 - "Implementing Sophisticated Quests in AAEmu — Engineering Guide"
Cohesion: 0.18
Nodes (10): 1. Data archaeology — read the canonical DB first, 2. The interaction-credit pipeline (the part that must not be faked), 3. Scenario support (LevelingLoopScenario pattern), 4. Headless rig conventions (the seams that took 5 hours to find), 5. Test recipe (positive + fail-closed controls), 6. Evidence classification, Doodad phase machines, Implementing Sophisticated Quests in AAEmu — Engineering Guide (+2 more)

### Community 587 - "unit_reqs layer audit — the 20 missing quest contexts and the 13 quests they gate"
Cohesion: 0.18
Nodes (10): 0. One-question answer (TL;DR), 1. The 20 missing contexts — full table, 2. Classification evidence — the collision class (7), 3. Classification evidence — the orphan class (13), 4. The 13 gated real quests — zone / kind / route status, 5. Cross-surface audit (same surfaces as the reachability audit), 6. Cross-layer check — Skill / Sphere / AiEvent rows (67 / 31 / 29), 7. Bottom line + fix-card shape (+2 more)

### Community 588 - "a5-host-telemetry.sh"
Cohesion: 0.29
Nodes (7): read_cgroup(), read_proc_stat(), read_steal(), read_thread_cpu(), sample(), a5-host-telemetry.sh script, usage()

### Community 589 - "main"
Cohesion: 0.38
Nodes (6): bridge_char_pos(), main(), Sidecar, text_result(), tool(), wait_terminal()

### Community 590 - ".Execute"
Cohesion: 0.20
Nodes (8): GainItemWithEmblemImprint, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 591 - "NpcSaveSubCommand"
Cohesion: 0.25
Nodes (7): ChangeTarget, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 592 - ".Capture"
Cohesion: 0.23
Nodes (5): CharacterAppellations, List, Logger, MySqlConnection, MySqlTransaction

### Community 593 - ".OnReceive"
Cohesion: 0.31
Nodes (5): NpcSaveSubCommand, bool, IDictionary, List, object

### Community 594 - "ArcherAttackBehavior"
Cohesion: 0.13
Nodes (10): ArcherAttackBehavior, bool, List, TimeSpan, ArcherAiParams, List, ArcherCombatSkill, List (+2 more)

### Community 595 - "WorldEvents.cs"
Cohesion: 0.16
Nodes (10): SkillController, Logger, Unit, SkillControllerTemplate, CastAction, DateTime, SkillCaster, SkillCastTarget (+2 more)

### Community 596 - "IComparable"
Cohesion: 0.22
Nodes (4): PacketCaptureSession, IPAddress, List, Socket

### Community 597 - ".Execute"
Cohesion: 0.25
Nodes (7): NpcDespawn, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 598 - "TowerDefProg"
Cohesion: 0.20
Nodes (6): TowerDef, List, TowerDefProg, List, TowerDefProgKillTarget, TowerDefProgSpawnTarget

### Community 599 - "JsonDoodadSpawns"
Cohesion: 0.24
Nodes (7): JsonDoodadSpawns, List, JsonDoodadSpawnsConverter, JsonReader, JsonSerializer, JsonWriter, Type

### Community 600 - "JsonNpcSpawns"
Cohesion: 0.24
Nodes (7): JsonNpcSpawns, List, JsonNpcSpawnsConverter, JsonReader, JsonSerializer, JsonWriter, Type

### Community 601 - "AAEmu.Game.Models.Tasks.Specialty"
Cohesion: 0.25
Nodes (7): ClearProjectile, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 602 - "HarpoonMechanicsDebug"
Cohesion: 0.22
Nodes (6): GimmickManager, DateTime, Dictionary, double, Logger, TimeSpan

### Community 603 - "Gate Harness — staged soak runner (P2, slice #10)"
Cohesion: 0.20
Nodes (9): Autosave budget recalibration (ah-conservation load shape, t_0d576fdb), Budgets (defaults), DB-write budget normalization (presence-aware, t_b4eb35e9), Evidence contract, Gate Harness — staged soak runner (P2, slice #10), How to add a stage (100/250/500/1000), How to run, Scheduler-driven soak — stage 1 (`SchedulerSoakStage1Tests`) (+1 more)

### Community 604 - "KoreanChallengeVerifier"
Cohesion: 0.40
Nodes (4): KoreanChallengeVerifier, Obsolete, ReadOnlySpan, Span

### Community 605 - "AAEmu.Login.IntegrationTests"
Cohesion: 0.20
Nodes (10): AAEmu.Login.IntegrationTests, Microsoft.Testing.Extensions.CodeCoverage, Microsoft.Testing.Extensions.Telemetry, Microsoft.Testing.Extensions.TrxReport.Abstractions, Microsoft.Testing.Platform.MSBuild, Moq, xunit.v3.mtp-v2, Microsoft.NET.Sdk (+2 more)

### Community 606 - "RandomElementByWeightTests"
Cohesion: 0.25
Nodes (7): TeleportToSiegeHq, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 607 - "Rig"
Cohesion: 0.25
Nodes (8): AAEmu.ArchaeologyMcp — read-only archaeology MCP server, Limits, Manual smoke (raw JSON-RPC), MCP client example, Security, Setup, Tests, Tools

### Community 608 - ".TierManifests_DriveAndWriteRunnabilityReport"
Cohesion: 0.25
Nodes (7): DestroyAndSpawnSlave, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 609 - "AAEmu Project Test Implementation Progress"
Cohesion: 0.20
Nodes (10): 📊 80% Coverage Achievement Plan, AAEmu Project Test Implementation Progress, Added Tests (06.03.2026), Current Statistics, Issues, 📅 Next Review, 📝 Notes, 📈 Quality Metrics (+2 more)

### Community 610 - "Aspire Development Guide"
Cohesion: 0.20
Nodes (10): Aspire Development Guide, Common issues, Debugging with Aspire, First run (preferred local workflow), Health and readiness, Prerequisites, Recommended way to set `game_pak`, Related (+2 more)

### Community 611 - "Working with Config Files and Server Listings"
Cohesion: 0.20
Nodes (10): Bot behavior configuration (all OFF by default), Environment variable mapping (login), `game_pak` configuration, Game server configuration and precedence, `GameServers` schema, Login server `Config.json` and `Config.Local.json`, Migration note from old setup docs, Overview (+2 more)

### Community 612 - ".kanban-templates — AAEmu fork task templates (onboarding-grade)"
Cohesion: 0.20
Nodes (9): Base docs (read in order of need), Examples (real filled shapes), First 10 minutes (every task, every sister, in order), .kanban-templates — AAEmu fork task templates (onboarding-grade), Maintenance, Pick your template, Status convention (one line), The division (who owns which phase) (+1 more)

### Community 613 - "AAEmu project control"
Cohesion: 0.20
Nodes (10): AAEmu project control, Authoritative records, Bot Decision Architecture, Dossiers and reports, Loop-Closure Definition of Done, Milestone and objective state, Objective QAT/UAT matrix, Scope map (+2 more)

### Community 614 - "M2b-E2E — live-server bot harness"
Cohesion: 0.20
Nodes (9): Architecture, How to add quests/zones to the route, Known limits (watch items), M2b-E2E — live-server bot harness, Metrics (observed 2026-08-07, E2E-3 verification), Quick start, Safety & composition rules (locked), What each test proves (+1 more)

### Community 615 - "Follow-up 2026-08-31 (third pass) — npc_spawners DB-side name matching fixed"
Cohesion: 0.29
Nodes (8): TransformAllocationTests, Attribution_ComputeWorldPosition_MatchesWorldClonePosition(), Action, int, long, Session, Task, Test

### Community 616 - "QUEST_NO_COMPONENTS 1391 — fail-before rig evidence"
Cohesion: 0.20
Nodes (9): 1. Data-level ground truth (compact.sqlite3, read-only), 2. Engine-level fail-before (scenario harness, pre-fix run), 3. Verifier cross-check, 4. Player-visible impact, 5. Fix contract (for the downstream fix card), 6. Gate evidence, 7. Pass-after evidence (fix card t_5a61cee3, branch fix/no-components-1391), QUEST_NO_COMPONENTS 1391 — fail-before rig evidence (+1 more)

### Community 617 - "QUEST_NO_START cluster 1533–1548 — fail-before + pass-after evidence (M1 rig)"
Cohesion: 0.20
Nodes (9): Accept-surface census — all zero, Appendix — reproducible queries (canonical DB, md5 78b3bdbf038db3b927056106efdf91af), Cluster inventory (23 quests; headline range 1533–1548 in bold), Engine-level proof, Fix branch — pass-after evidence (t_5140fb35, DROP 2026-08-05), QUEST_NO_START cluster 1533–1548 — fail-before + pass-after evidence (M1 rig), The rig, Verdict (+1 more)

### Community 618 - "Quest Reachability Audit — do the allowlisted / flagged quests exist in 1.2 world data?"
Cohesion: 0.20
Nodes (9): 1. The 132 allowlisted quest ids — existence + references, 2. The 28 orphan contexts (quest_components rows referencing a missing quest_context), 3. The 3 next_component quests (330 / 776 / 777), 4. NEW LAYER — unit_reqs prerequisite references to missing contexts (never checked by the verifier), 5. Surfaces with ZERO hits across all 163 audited ids (132+28+3), 6. Bottom line, Appendix — repeatable queries, Quest Reachability Audit — do the allowlisted / flagged quests exist in 1.2 world data? (+1 more)

### Community 619 - "ArcheAge Slums — Fork Vision & Lane Strategy"
Cohesion: 0.20
Nodes (9): ArcheAge Slums — Fork Vision & Lane Strategy, Branch / workflow rules, Division routing (the whole Hyrax division runs this), Lane 1 — upstream intake and fork correctness, Lane 2 — our fork (product), Reference, The two lanes, The vision (+1 more)

### Community 620 - "ExecutionBoundary"
Cohesion: 0.25
Nodes (7): HealPet, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 621 - ".Spawn"
Cohesion: 0.07
Nodes (23): MateState, SpawnEffect, CastAction, DateTime, SkillCaster, SkillCastTarget, SkillObject, SpawnDoodad (+15 more)

### Community 622 - "IExperienceManager"
Cohesion: 0.29
Nodes (4): QuestActConReportNpc, Quest, QuestAct, OnReportNpcArgs

### Community 623 - ".GetArmorGradeBuff"
Cohesion: 0.14
Nodes (6): SlaveManager, float, Logger, MySqlConnection, MySqlTransaction, object

### Community 624 - "TagsGameData"
Cohesion: 0.18
Nodes (7): QuestActObjZoneKill, Quest, QuestAct, QuestActObjZoneMonsterHunt, Quest, QuestAct, OnZoneKillArgs

### Community 625 - ".RunBridgeStartupAsync"
Cohesion: 0.31
Nodes (5): TagsGameData, Dictionary, IReadOnlySet, SqliteConnection, TagType

### Community 626 - "CommercialMail"
Cohesion: 0.22
Nodes (7): CommercialMail, bool, List, string, uint, CashShopBuyTask, Logger

### Community 627 - "AAEmu.Game.Models.Game.Mate"
Cohesion: 0.20
Nodes (4): SpecialtyRatioConsumeTask, SpecialtyRatioRegenTask, TradePackExpiryTask, AAEmu.Game.Models.Tasks.Specialty

### Community 628 - "Tagging"
Cohesion: 0.25
Nodes (6): Tagging, Dictionary, HashSet, object, uint, Unit

### Community 629 - ".Execute"
Cohesion: 0.22
Nodes (8): AddExp, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 630 - ".Execute"
Cohesion: 0.22
Nodes (8): ApplyReagents, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 631 - ".Execute"
Cohesion: 0.22
Nodes (8): AttachTo, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 632 - ".Execute"
Cohesion: 0.22
Nodes (8): Blink, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 633 - ".Execute"
Cohesion: 0.22
Nodes (8): CancelStealth, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 634 - ".Execute"
Cohesion: 0.22
Nodes (8): CapturePet, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 635 - ".Execute"
Cohesion: 0.22
Nodes (8): Charge, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 636 - ".Execute"
Cohesion: 0.22
Nodes (8): CleanupLookConvert, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 637 - ".Execute"
Cohesion: 0.22
Nodes (8): ConsumeLaborPower, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 638 - ".Execute"
Cohesion: 0.22
Nodes (8): DeclareDominion, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 639 - ".Execute"
Cohesion: 0.22
Nodes (8): DisturbCasting, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 640 - ".Execute"
Cohesion: 0.22
Nodes (8): EnterBeautyshop, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 641 - ".Execute"
Cohesion: 0.22
Nodes (8): Escape, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 642 - ".Execute"
Cohesion: 0.22
Nodes (8): ExitArchemall, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 643 - ".Execute"
Cohesion: 0.22
Nodes (8): FishingLoot, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 644 - ".Execute"
Cohesion: 0.22
Nodes (8): GiveAppellation, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 645 - ".Execute"
Cohesion: 0.22
Nodes (8): GiveBmMileage, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 646 - ".Execute"
Cohesion: 0.22
Nodes (8): GiveCashPoint, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 647 - ".Execute"
Cohesion: 0.22
Nodes (8): GiveHonorPoint, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 648 - ".Execute"
Cohesion: 0.22
Nodes (8): GlobalCooldown, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 649 - ".Execute"
Cohesion: 0.22
Nodes (8): ItemCapScale, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 650 - ".Execute"
Cohesion: 0.22
Nodes (8): ItemCapScaleReset, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 651 - ".Execute"
Cohesion: 0.22
Nodes (8): ItemConversion, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 652 - ".Execute"
Cohesion: 0.22
Nodes (8): ItemSocketing, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 653 - ".Execute"
Cohesion: 0.22
Nodes (8): ManaCost, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 654 - ".Execute"
Cohesion: 0.22
Nodes (8): PlayUserMusic, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 655 - ".Execute"
Cohesion: 0.22
Nodes (8): ReceiveLuluLeaflet, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialEffect

### Community 656 - ".Execute"
Cohesion: 0.22
Nodes (8): ReportBot, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 657 - ".Execute"
Cohesion: 0.22
Nodes (8): ReportBotArrested, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 658 - ".Execute"
Cohesion: 0.22
Nodes (8): ReportBotExpired, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 659 - ".Execute"
Cohesion: 0.22
Nodes (8): ResetCooldown, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 660 - ".Execute"
Cohesion: 0.22
Nodes (8): Resurrection, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 661 - ".Execute"
Cohesion: 0.22
Nodes (8): SetVariable, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 662 - ".Execute"
Cohesion: 0.22
Nodes (8): SkillUse, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 663 - ".Execute"
Cohesion: 0.22
Nodes (8): Skinize, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 664 - ".Execute"
Cohesion: 0.25
Nodes (7): LoseTargetingTheTarget, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 665 - ".Execute"
Cohesion: 0.22
Nodes (8): SpawnPet, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 666 - ".Execute"
Cohesion: 0.22
Nodes (8): SpawnSlave, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 667 - ".Execute"
Cohesion: 0.22
Nodes (8): StopManaRegen, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 668 - ".Execute"
Cohesion: 0.25
Nodes (7): ExpandDecoLimit, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 669 - "CheckBuffsExcludingTagsTests"
Cohesion: 0.39
Nodes (4): CheckBuffsExcludingTagsTests, Before, Task, Test

### Community 670 - "JsonQuestSphereConverter"
Cohesion: 0.28
Nodes (6): JsonQuestSphere, JsonQuestSphereConverter, JsonReader, JsonSerializer, JsonWriter, Type

### Community 671 - "Teleport"
Cohesion: 0.31
Nodes (5): DoodadSaveSubCommand, bool, IDictionary, List, object

### Community 672 - "ScriptReflector"
Cohesion: 0.25
Nodes (5): AiPathHandler, List, Queue, TimeSpan, Vector3

### Community 673 - "AAEmu.Login"
Cohesion: 0.22
Nodes (9): AAEmu.Login, NLog, OSVersionExt.NetStd, NLog.Extensions.Logging, OpenTelemetry.Exporter.OpenTelemetryProtocol, OpenTelemetry.Extensions.Hosting, OpenTelemetry.Instrumentation.AspNetCore, Otp.NET (+1 more)

### Community 674 - ".Dispatch"
Cohesion: 0.22
Nodes (8): Cooldown, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject, SpecialType

### Community 675 - "Program"
Cohesion: 0.31
Nodes (5): Program, DateTime, Logger, Task, Thread

### Community 676 - "PacketCaptureSession"
Cohesion: 0.22
Nodes (4): PacketCaptureSession, IPAddress, List, Socket

### Community 677 - "PacketCaptureSession"
Cohesion: 0.47
Nodes (3): RandomElementByWeightTests, Task, Test

### Community 678 - "PacketCaptureSession"
Cohesion: 0.36
Nodes (4): RandomExtensionsTests, Arguments, Task, Test

### Community 679 - "PacketCaptureSession"
Cohesion: 0.22
Nodes (4): PacketCaptureSession, IPAddress, List, Socket

### Community 680 - "PacketCaptureSession"
Cohesion: 0.22
Nodes (4): PacketCaptureSession, IPAddress, List, Socket

### Community 681 - "PacketCaptureSession"
Cohesion: 0.29
Nodes (4): QuestActObjTalkNpcGroup, Quest, QuestAct, OnTalkNpcGroupMadeArgs

### Community 682 - "CompletedQuestTests"
Cohesion: 0.44
Nodes (4): CompletedQuestTests, Arguments, Task, Test

### Community 683 - "BUG-006 — Kill-acceptor quests can never start"
Cohesion: 0.22
Nodes (8): BUG-006 — Kill-acceptor quests can never start, Files changed, Fix, Root cause, Symptom, Tests, Upstream note, Verification on prod (once merged to develop + deployed)

### Community 684 - "BUG-009 — QuestActObjItemGroupGather / QuestActObjItemGroupUse stall (9 quests)"
Cohesion: 0.22
Nodes (8): BUG-009 — QuestActObjItemGroupGather / QuestActObjItemGroupUse stall (9 quests), Files changed, Fix, Root cause, Symptom, Tests, Upstream note, Verification on prod (once merged to develop + deployed)

### Community 685 - "Прогресс внедрения тестов в проект AAEmu"
Cohesion: 0.22
Nodes (9): Related, Добавленные тесты (06.03.2026), 📝 Заметки, 📈 Метрики качества, 📊 План достижения 80% покрытия, Проблемы, Прогресс внедрения тестов в проект AAEmu, Рекомендации по написанию тестов (+1 more)

### Community 686 - "Asking for Help on GitHub Discussions"
Cohesion: 0.22
Nodes (9): Asking for Help on GitHub Discussions, Before posting, Body, Follow-up, How to structure your discussion, Related, Suggested body template, Title (+1 more)

### Community 687 - "ACT_REF_MISSING_QUEST — 2145→2146 fail-before evidence rig"
Cohesion: 0.22
Nodes (8): 1. What this is, 2. Ground truth (reference data), 3. Rig layer 1 — xUnit (real verifier), 4. Rig layer 2 — SQL census (real data), 5. Why this matters (fail-before framing), 6. Provenance, 7. Fix branch — pass-after evidence (t_60a559ab), ACT_REF_MISSING_QUEST — 2145→2146 fail-before evidence rig

### Community 688 - "M6-light sideload — Roam + Safety + Behaviors (extension note)"
Cohesion: 0.22
Nodes (8): 1. Roam — `BotPath` (waypoint/pathing), 2. Safety — `BotSafetyMonitor` (M6.2 safety-FIRST slice), 3. Behaviors — `BotBehaviorStack` + `PlayerBotBehaviorController`, M6-light sideload — Roam + Safety + Behaviors (extension note), Out of scope (future M6 tracks, deliberately not here), Rig evidence, The three primitives, What this layer is

### Community 689 - "C10 Fishing Domain Dossier (FISH-01 all-U exploration, 2026-08-24)"
Cohesion: 0.22
Nodes (8): 1. Server code today, 2. Canonical data, 3. The gameplay loop — encoded in plot 809, 4. Packets, 5. Sizing & bot feasibility, C10 Fishing Domain Dossier (FISH-01 all-U exploration, 2026-08-24), Implemented and wired, Stubbed / orphaned

### Community 690 - "PlayerBot Capability Matrix (Perceive / Decide / Act / Verify)"
Cohesion: 0.22
Nodes (8): Highest-leverage gaps (one primitive unlocks many loops), M2 loop reconciliation (2026-08-28), M3 loop reconciliation (2026-08-28), M4 loop reconciliation (2026-08-28), M5 actor decision/action loop reconciliation (2026-08-28), M6/M7 loop reconciliation (2026-08-28), MCP expansion (2026-08-27), PlayerBot Capability Matrix (Perceive / Decide / Act / Verify)

### Community 691 - "COMPONENT_NEXT_MISSING — 776/777 fail-before evidence rig"
Cohesion: 0.22
Nodes (8): 1. What this is, 2. Ground truth (reference data), 3. Rig layer 1 — xUnit (real verifier), 4. Rig layer 2 — SQL census (real data), 5. Why this matters (fail-before framing), 6. Provenance, 7. Fix branch — pass-after evidence (t_cdbf231b), COMPONENT_NEXT_MISSING — 776/777 fail-before evidence rig

### Community 692 - "Stub-Act Audit — quest acts that silently auto-complete or stall"
Cohesion: 0.22
Nodes (8): 1. Real stubs (need a fix or a deliberate decision), 2. Unverified (returns true, plausible by design — needs one spot-check), 3. By design / functional (NOT stubs — do not "fix" these), 4. Partial (functional but with known semantic gaps — already separate M1 tasks), 5. Data hygiene (informational for the sanity verifier), 6. Reproducible queries (prod box), 7. Recommended order (roadmap priority: engine defects → golden route → corruption → peripheral), Stub-Act Audit — quest acts that silently auto-complete or stall

### Community 693 - "M2b-E2E boot orchestration (E2E-1)"
Cohesion: 0.22
Nodes (8): Cycle isolation contract (what reset proves), Files, M2b-E2E boot orchestration (E2E-1), No secrets, Pitfalls learned (2026-08), Port table, Required build steps / prerequisites, Usage

### Community 694 - "AAEmu.ArchaeologyMcp — read-only archaeology MCP server"
Cohesion: 0.25
Nodes (7): Return, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 695 - "EffectTaskManager"
Cohesion: 0.36
Nodes (4): EffectTaskManager, IEffectTaskManager, EffectTaskManagerTests, Test

### Community 696 - "DynamicBonus"
Cohesion: 0.22
Nodes (7): DependentSingleton, LeafSingleton, SingletonTests, Task, Test, DependentSingleton, LeafSingleton

### Community 697 - "TaxationsManager"
Cohesion: 0.25
Nodes (7): FxGroupAnim, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 698 - "StreamNetwork"
Cohesion: 0.29
Nodes (4): QuestActConReportJournal, Quest, QuestAct, OnReportJournalArgs

### Community 699 - ".Write"
Cohesion: 0.39
Nodes (4): SCUnitImpulsePacket, SCUnitImpulsePacketTests, Task, Test

### Community 700 - "GimmickGameData"
Cohesion: 0.25
Nodes (7): Interaction, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 701 - "QuestActObjAggro"
Cohesion: 0.31
Nodes (5): DashSkillController, float, TimeSpan, Vector3, DashDirection

### Community 703 - ".Execute"
Cohesion: 0.29
Nodes (4): Matrix3x4, float, ObjectDataType1Brush, Vector3

### Community 704 - ".Execute"
Cohesion: 0.25
Nodes (4): Vector3, ObjectDataType13Road, List, Vector3

### Community 705 - ".Execute"
Cohesion: 0.22
Nodes (4): PacketCaptureSession, IPAddress, List, Socket

### Community 706 - ".Execute"
Cohesion: 0.32
Nodes (4): ObjectDataType6Voxel, List, Stream, Vector3

### Community 707 - ".Execute"
Cohesion: 0.29
Nodes (7): VoxelChunkEntry, VoxelMeshReader, Color, Dictionary, int, List, Vector3

### Community 708 - ".Execute"
Cohesion: 0.25
Nodes (7): AddLaborPower, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 709 - ".Execute"
Cohesion: 0.25
Nodes (7): AddExpeditionExp, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 710 - ".Execute"
Cohesion: 0.25
Nodes (7): AutoAttack, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 711 - ".Execute"
Cohesion: 0.08
Nodes (14): Bonus, BuffStackRule, DynamicBonus, BonusTemplate, BuffTemplate, Buff, BuffKind, List (+6 more)

### Community 712 - ".Execute"
Cohesion: 0.04
Nodes (31): Singleton, AchievementGameData, Dictionary, SqliteConnection, BattlefieldGameData, Dictionary, CommonFarmGameData, Dictionary (+23 more)

### Community 713 - ".Execute"
Cohesion: 0.25
Nodes (7): SavePortal, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 714 - ".Execute"
Cohesion: 0.28
Nodes (3): TestNavMesh, List, Vector3

### Community 715 - ".Execute"
Cohesion: 0.25
Nodes (7): Dyeing, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 716 - ".Execute"
Cohesion: 0.25
Nodes (7): RepairAuthorityInBag, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 717 - ".Execute"
Cohesion: 0.22
Nodes (10): Rig, Dictionary, FakeTimeProvider, Rig, Dictionary, float, FakeBotManager, FakeTickManager (+2 more)

### Community 718 - ".Execute"
Cohesion: 0.25
Nodes (7): EscapeMySlave, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 719 - ".Execute"
Cohesion: 0.25
Nodes (7): FxGroup, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 720 - ".Execute"
Cohesion: 0.25
Nodes (7): GainItem, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 721 - ".Execute"
Cohesion: 0.25
Nodes (7): ItemEvolving, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 722 - ".Execute"
Cohesion: 0.25
Nodes (7): MateMakeGetUp, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 723 - ".Execute"
Cohesion: 0.25
Nodes (7): OpenPortal, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 724 - ".Execute"
Cohesion: 0.25
Nodes (7): Detach, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 725 - ".Execute"
Cohesion: 0.25
Nodes (7): AddFamilyExp, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 726 - ".Execute"
Cohesion: 0.25
Nodes (7): RechargeItemBuff, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 727 - ".Execute"
Cohesion: 0.43
Nodes (4): QuestActObjAggro, int, Quest, QuestAct

### Community 728 - ".Execute"
Cohesion: 0.25
Nodes (7): RechargeItemRndAttrUnitModifier, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 729 - ".Execute"
Cohesion: 0.25
Nodes (7): RemoveAllDoodad, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 730 - ".Execute"
Cohesion: 0.25
Nodes (7): AddCharacterSlot, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 731 - ".Execute"
Cohesion: 0.25
Nodes (7): StartDominionNonPvpDuration, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 732 - ".Execute"
Cohesion: 0.25
Nodes (7): AggroCopy, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 733 - ".Execute"
Cohesion: 0.25
Nodes (7): AddFxToProjectile, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 734 - ".Execute"
Cohesion: 0.04
Nodes (45): Task, Task, IRequestController, IEnumerable, requestIds, result, Task, RequestController (+37 more)

### Community 735 - ".Execute"
Cohesion: 0.25
Nodes (7): RemoveDoodadGroup, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 736 - ".Execute"
Cohesion: 0.22
Nodes (4): PacketCaptureSession, IPAddress, List, Socket

### Community 737 - ".Execute"
Cohesion: 0.25
Nodes (7): RetrieveProjectile, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 738 - ".Execute"
Cohesion: 0.25
Nodes (7): RevertItemLook, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 739 - ".Execute"
Cohesion: 0.25
Nodes (7): AggroReset, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 740 - ".Execute"
Cohesion: 0.12
Nodes (15): BagAuditSnapshot, BotBagManager, HashSet, IReadOnlyList, Logger, EquipmentItemSlot, BotBagManagerTests, Task (+7 more)

### Community 741 - ".Execute"
Cohesion: 0.25
Nodes (7): WeaponDisplay, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 742 - ".Execute"
Cohesion: 0.25
Nodes (5): InternalNetworkConfig, string, NetworkConfig, PublicNetworkConfig, string

### Community 743 - ".Execute"
Cohesion: 0.25
Nodes (7): Combo, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 744 - ".Execute"
Cohesion: 0.25
Nodes (7): HudAuctionAuthority, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 745 - ".Execute"
Cohesion: 0.25
Nodes (7): IncreaseFavoritePortalLimit, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 746 - ".Execute"
Cohesion: 0.25
Nodes (7): ExpeditionLevelChange, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 747 - ".Execute"
Cohesion: 0.25
Nodes (7): Anim, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 748 - ".Execute"
Cohesion: 0.50
Nodes (4): QuestEtcItemObtainRigTests, string, Task, Test

### Community 749 - ".Execute"
Cohesion: 0.53
Nodes (3): SingletonSwap, object, Type

### Community 750 - ".Execute"
Cohesion: 0.25
Nodes (7): ItemRefurbishment, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 751 - ".Execute"
Cohesion: 0.25
Nodes (7): CombatDice, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 752 - ".Execute"
Cohesion: 0.25
Nodes (7): GainGachaLootPackItem, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 753 - ".Execute"
Cohesion: 0.25
Nodes (7): ItemSmelting, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 754 - ".Execute"
Cohesion: 0.25
Nodes (7): MoveToGround, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 755 - ".Execute"
Cohesion: 0.25
Nodes (7): NotifyQuest, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 756 - ".Execute"
Cohesion: 0.25
Nodes (7): ActivateSavedAbilitySet, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 757 - ".Execute"
Cohesion: 0.25
Nodes (7): LoseTarget, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 758 - ".Execute"
Cohesion: 0.25
Nodes (7): BuffSteal, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 759 - ".Execute"
Cohesion: 0.25
Nodes (7): PhysicalEnchantWeapon, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 760 - ".Execute"
Cohesion: 0.29
Nodes (5): ObjectDataType11Water, int, List, Vector3, WaterObjectVolumeType

### Community 761 - ".Execute"
Cohesion: 0.40
Nodes (4): SCErrorMsgPacket, bool, short, uint

### Community 762 - ".Execute"
Cohesion: 0.25
Nodes (7): PlayAttachmentAnim, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 763 - ".Execute"
Cohesion: 0.25
Nodes (7): Projectile, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 765 - ".Execute"
Cohesion: 0.25
Nodes (7): ProtectionForExpedition, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 766 - ".Execute"
Cohesion: 0.25
Nodes (7): ResidentServicePoint, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 767 - ".Execute"
Cohesion: 0.25
Nodes (7): Track, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 768 - ".Execute"
Cohesion: 0.57
Nodes (4): MailController, HttpRequest, HttpResponse, WebApiPost

### Community 769 - ".Execute"
Cohesion: 0.25
Nodes (7): RemoveDoodad, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 770 - ".Execute"
Cohesion: 0.29
Nodes (5): FishFinderSetSubCommand, IDictionary, IMessageOutput, ParameterValue, AAEmu.Game.Utils.Scripts.SubCommands.FishFinder

### Community 771 - ".Execute"
Cohesion: 0.25
Nodes (7): HealSlave, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 772 - ".Execute"
Cohesion: 0.43
Nodes (3): DoodadChainSubCommandTests, Arguments, Test

### Community 773 - ".Execute"
Cohesion: 0.29
Nodes (7): G0 — Discipline fixes (precondition for milestone credit), G1 — Quest coverage to 100% ✅ GATE PASSED 2026-08-10 (4,579 live contexts; 4,573 PASS / 0 FAIL / 14 documented SKIP = 100.0% PASS-or-doc-SKIP, zero unexplained), G2 — Scale ladder (order of failure: threading → broadcast GC →, G3 — Behavior foundation, G4 — Living Village content (M8), Gap audit 2026-08-09 (Kimi deep-dive — detailed work breakdowns), Roadmap self-fixes

### Community 774 - ".Execute"
Cohesion: 0.25
Nodes (7): SextantPos, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 775 - ".Execute"
Cohesion: 0.48
Nodes (4): QuestAbilityLevelRigTests, string, Task, Test

### Community 776 - ".Execute"
Cohesion: 0.33
Nodes (5): SCChatMessagePacket, byte, int, string, ChatType

### Community 778 - ".Execute"
Cohesion: 0.33
Nodes (3): ACJoinResponsePacket, AfsValue, JoinResponseReason

### Community 779 - ".Execute"
Cohesion: 0.52
Nodes (3): SingletonSwap, object, Type

### Community 780 - ".Execute"
Cohesion: 0.50
Nodes (4): Architecture notes: manager DI and parallel loading, August 2026 — M0/M1-era notes (fork), Developer Notes, Related

### Community 782 - "AAEmu.IntegrationTests"
Cohesion: 0.25
Nodes (8): AAEmu.IntegrationTests, Microsoft.Testing.Extensions.CodeCoverage, Microsoft.Testing.Extensions.Telemetry, Microsoft.Testing.Extensions.TrxReport.Abstractions, Microsoft.Testing.Platform.MSBuild, Moq, xunit.v3.mtp-v2, Microsoft.NET.Sdk

### Community 784 - "FakeClient"
Cohesion: 0.39
Nodes (6): FakeClient, Body, List, Method, Path, Status

### Community 785 - "FakeClient"
Cohesion: 0.39
Nodes (6): FakeClient, Body, List, Method, Path, Status

### Community 786 - "StringExtensionsTest"
Cohesion: 0.29
Nodes (4): ShipyardCompleteTask, ShipyardTickTask, Shipyard, AAEmu.Game.Models.Tasks.Shipyard

### Community 787 - "FakeSession"
Cohesion: 0.02
Nodes (71): QuestActCheckCompleteComponent, Quest, QuestAct, QuestActConAcceptComponent, Quest, QuestAct, QuestActConAcceptItemGain, Quest (+63 more)

### Community 788 - "ForceDismountHeadlessTests"
Cohesion: 0.50
Nodes (4): ForceDismountHeadlessTests, Task, Test, uint

### Community 789 - ".LoadManifest"
Cohesion: 0.50
Nodes (4): QuestCheckGuardRigTests, string, Task, Test

### Community 790 - ".RunManifest"
Cohesion: 0.50
Nodes (3): QuestActConAcceptBuff, Quest, QuestAct

### Community 791 - "GameServiceTests"
Cohesion: 0.50
Nodes (3): QuestActConAcceptItemEquip, Quest, QuestAct

### Community 792 - "BUG-008 — QuestActCheckGuard silently auto-completes (6 escort/protect quests)"
Cohesion: 0.25
Nodes (7): BUG-008 — QuestActCheckGuard silently auto-completes (6 escort/protect quests), Files changed, Fix (smallest change, matches sibling patterns), Root cause, Symptom, Tests, Verification

### Community 793 - "BUG-011 — QuestActCheckSphere can never pass + sphere entry crashes (Objectives[0xFF])"
Cohesion: 0.25
Nodes (7): BUG-011 — QuestActCheckSphere can never pass + sphere entry crashes (Objectives[0xFF]), Files changed, Fix (smallest change, mirrors QuestActCheckGuard), Root cause, Symptom, Tests, Verification

### Community 794 - "BUG-014 — quest completed-block id wraps for quest ids >= 4,194,304"
Cohesion: 0.25
Nodes (7): BUG-014 — quest completed-block id wraps for quest ids >= 4,194,304, Evidence (census-driven, harness-independent), Fix contract (for the fix card), Found by, Impact, Root cause — ushort block-id arithmetic (file:line), Symptom

### Community 795 - "Deploy card — 2026-08-25 (mechanics + bots mega-release)"
Cohesion: 0.25
Nodes (7): Deploy card — 2026-08-25 (mechanics + bots mega-release), Post-boot checks, Pre-deploy verification already done, Rollback, Steps (full runbook: Docs/wiki/Docker-Installation-Guide.md § Production redeploy), Target, What's in this deploy (vs prod @ ~81676c0d6 / Aug 17)

### Community 796 - "Root cause — QUEST_NO_START cluster 1533–1548"
Cohesion: 0.25
Nodes (7): Component / act map (read-only census, canonical DB), Fail-before baseline (confirmed 2026-08-05), References, Root cause — QUEST_NO_START cluster 1533–1548, The defect, Verdict and fix location (as decided, Josh 2026-08-05), Why they can never be accepted (engine proof)

### Community 797 - "❌ Что ещё нужно сделать (до 50% покрытия)"
Cohesion: 0.25
Nodes (8): 1.1 Система предметов (Items) — РАСШИРЕННОЕ ПОКРЫТИЕ, 1.2 Система навыков (Skills) — РАСШИРЕННОЕ ПОКРЫТИЕ, 1.3 Система квестов (Quests), 2.1 Обработчики пакетов C2G (Client-to-Game), 2.2 Обработчики пакетов G2C (Game-to-Client), Приоритет 1: Критическая бизнес-логика (~15-20% покрытия), Приоритет 2: Пакеты и сеть (~10-15% покрытия), ❌ Что ещё нужно сделать (до 50% покрытия)

### Community 798 - "M2b Playerbot Pilot — Regression-Harness Contract (Solzreed, M6.0-lite)"
Cohesion: 0.25
Nodes (7): Calibration (why the stage loop is what it is), Drift detection, M2b Playerbot Pilot — Regression-Harness Contract (Solzreed, M6.0-lite), Metrics (M2b table — see m2b-pilot-metrics.md), Quest-cycle mode (empirical re-accept gate), Signal contract (who reports what), What the pilot is

### Community 799 - "Trade-Pack Put-Down Mechanic — Canonical 1.2 Placement Rules + PUTDOWN Refusal Verdict (PACK-01 dossier)"
Cohesion: 0.25
Nodes (7): 1. TL;DR, 2. Finding recap (from t_eaee04ee), 3. Root-cause chain (all data-verified unless labeled), 4. Canonical 1.2 put-down placement rules (engine = data-verified; retail = research-derived), 5. Verdict and test-contract correction, 6. Sources, Trade-Pack Put-Down Mechanic — Canonical 1.2 Placement Rules + PUTDOWN Refusal Verdict (PACK-01 dossier)

### Community 800 - "e2e-snapshot.sh"
Cohesion: 0.46
Nodes (5): dump_exec(), mysql_exec(), require_db(), e2e-snapshot.sh script, snap_compose()

### Community 801 - "AAEmu.BotControl — MCP stdio gateway"
Cohesion: 0.29
Nodes (6): AAEmu.BotControl — MCP stdio gateway, Manual smoke (raw JSON-RPC), Registering in Hermes (native MCP client), Running, Security, Tools

### Community 802 - "AAEmu.Commons"
Cohesion: 0.29
Nodes (7): AAEmu.Commons, Newtonsoft.Json, NLog, Microsoft.NET.Sdk, Microsoft.Extensions.DependencyInjection.Abstractions, MySql.Data, NetCoreServer

### Community 803 - "CraftManager"
Cohesion: 0.25
Nodes (7): ItemGradeEnchanting, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 804 - "ExpressTextManager"
Cohesion: 0.48
Nodes (4): QuestCompleteQuestRigTests, string, Task, Test

### Community 805 - ".Execute"
Cohesion: 0.50
Nodes (4): ContainerIdManager, string, uint, IContainerIdManager

### Community 806 - "CommonFarmGameData"
Cohesion: 0.33
Nodes (6): Archaeology MCP — greenfield read-only data server (2026-08-31), Current M6/M7 loop reconciliation (2026-08-28), Historical MCP checkpoint (2026-08-27), M5 actor decision/action loop reconciliation (2026-08-28; local, M5 — Gameplay Actor Contract, MCP actor-route expansion and layered validation (2026-08-27)

### Community 807 - "QuestActObjZoneKill"
Cohesion: 0.33
Nodes (6): DoD — evidence classes REQUIRED to claim closure (7-state ledger, EVIDENCE-LEDGER.md, t_547ef82d), Exit tests, Milestone Requirements & DoD — THE STANDARD (retrofit 2026-08-14, Codex audit finding), Non-goals, Requirements (REQ-<M>-<n>), Retrofit summary (2026-08-14, t_730b04bd)

### Community 808 - "QuestActObjZoneMonsterHunt"
Cohesion: 0.50
Nodes (4): Planned topics, Playtest walkthrough — a new Nuian character in Solzreed, Related, Tutorials

### Community 809 - "ZoneConfig.cs"
Cohesion: 0.33
Nodes (6): CellConfig, SectorConfig, ZoneConfig, List, CellConfig, SectorConfig

### Community 810 - "ShipyardTickTask.cs"
Cohesion: 0.40
Nodes (3): AccountManagerTests, Task, Test

### Community 811 - "Announce"
Cohesion: 0.50
Nodes (4): IQuestIdManager, QuestIdManager, string, uint

### Community 812 - "SpawnGrid"
Cohesion: 0.33
Nodes (6): M0 — Foundation (done, 2026-08-03), M1 — Quest and progression spine (in flight), Milestones, Project Status — "ArcheAge Slums" fork milestones, Related, The golden route concept

### Community 813 - "BaseJsonConverter"
Cohesion: 0.29
Nodes (4): BaseJsonConverter, JsonSerializer, JsonWriter, Type

### Community 815 - ".Execute"
Cohesion: 0.03
Nodes (50): AdventurerSpikeE2eTests, Fact, string, Task, Trait, DominionRestartPersistenceE2eTests, DateTime, Dictionary (+42 more)

### Community 816 - ".Execute"
Cohesion: 0.40
Nodes (3): ExampleTests, Task, Test

### Community 817 - ".Execute"
Cohesion: 0.40
Nodes (4): SCICSMenuListPacket, bool, byte, Dictionary

### Community 818 - "CombatBuffs"
Cohesion: 0.40
Nodes (4): SCNoticeMessagePacket, byte, int, string

### Community 819 - "MySqlFixture"
Cohesion: 0.25
Nodes (7): OpacityControl, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 820 - "DoodadChainSubCommandTests"
Cohesion: 0.40
Nodes (3): MaterialsFile, List, Logger

### Community 822 - "BUG-001 — Game container crash-loops with SIGSEGV (exit 139) during AiGameData load"
Cohesion: 0.29
Nodes (6): BUG-001 — Game container crash-loops with SIGSEGV (exit 139) during AiGameData load, Evidence, Fix, Root cause, Symptom, Upstream

### Community 823 - "BUG-007 — Quest data defects fail silently: add startup sanity verifier (M1-3)"
Cohesion: 0.29
Nodes (6): BUG-007 — Quest data defects fail silently: add startup sanity verifier (M1-3), Evidence, Files, Fix (smallest change, matches sibling loader behavior), Root cause, Verification (prod)

### Community 824 - "BUG-010 — Helpers.UnixTime(long) clamps every timestamp > 59s to DateTime.MaxValue"
Cohesion: 0.29
Nodes (6): BUG-010 — Helpers.UnixTime(long) clamps every timestamp > 59s to DateTime.MaxValue, Fix, Impact, Root cause, Symptom, Verification

### Community 825 - "BUG-012 — CharacterAbilities KeyNotFoundException 'General' on quest exp rewards (Ability1 == General)"
Cohesion: 0.29
Nodes (6): BUG-012 — CharacterAbilities KeyNotFoundException 'General' on quest exp rewards (Ability1 == General), Fix, Impact, Root cause, Symptom, Verification

### Community 826 - "BUG-016 — Melee combo skills with target_area_radius + TargetSelection=Target never damage their primary target (skill 18131 confirmed)"
Cohesion: 0.29
Nodes (6): BUG-016 — Melee combo skills with target_area_radius + TargetSelection=Target never damage their primary target (skill 18131 confirmed), Evidence, Fix, Repro (pre-fix), Root cause (file:line), Symptom

### Community 827 - "Bot Control Gateway (API + MCP)"
Cohesion: 0.29
Nodes (6): Bot Control Gateway (API + MCP), Enablement, Endpoints, Files, MCP server, Security notes

### Community 828 - "Documentation Maintenance"
Cohesion: 0.29
Nodes (7): Cross-linking model, Documentation Maintenance, Goal, How wiki pages publish, Related, Update checklist after merged PRs, Writing conventions

### Community 829 - "Help Us Help You"
Cohesion: 0.29
Nodes (7): Fast self-check before posting, Help Us Help You, Logs and artifacts, Minimum context checklist, Related, Reproduction quality, Where to ask

### Community 830 - "Milestone Evidence Ledger — ArcheAge Slums (fork joshhmann/AAEmu)"
Cohesion: 0.29
Nodes (6): Change log (append-only), Evidence register (citations, append-only), Ledger, Milestone Evidence Ledger — ArcheAge Slums (fork joshhmann/AAEmu), Rules (never-erase discipline), The 7 evidence states

### Community 831 - "CraftManager"
Cohesion: 0.25
Nodes (7): PhysicalEnchantArmor, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 832 - "FARM-01 Livestock Interactions — FIX-1 (t_afbf7cb7)"
Cohesion: 0.29
Nodes (6): Evidence, FARM-01 Livestock Interactions — FIX-1 (t_afbf7cb7), Files, Implemented behavior (per the 1.2 chains), Tests, What was broken

### Community 833 - "INDUN-01 Domain Dossier (2026-08-24 exploration)"
Cohesion: 0.29
Nodes (6): Addendum 2026-08-25 — PB-003 canonical verification: exit-portal DATA GAP REFUTED, Bot runnability, Gaps (why W=1 was fair), INDUN-01 Domain Dossier (2026-08-24 exploration), Recommended proof target, Verdict: far beyond a stub — structured implementation exists

### Community 834 - "HYRAXKNOT — AAEmu Progression Board"
Cohesion: 0.29
Nodes (6): HYRAXKNOT — AAEmu Progression Board, Milestone Requirements & DoD — standard block (retrofit 2026-08-14, t_730b04bd), Milestones, Open Decisions (Josh), The Game vs What We've Proven, This Week's Catch (the fleet as QA)

### Community 835 - "Zone Readiness Report — Solzreed, Solzreed (2), Solzreed (3)"
Cohesion: 0.29
Nodes (6): Missing-data checklist, Quest chains (kind-31 completion prerequisites), Quest-referenced items with NO template row, Quest-referenced NPCs with NO spawner row, Requirement gates (all kinds), Zone Readiness Report — Solzreed, Solzreed (2), Solzreed (3)

### Community 836 - "find-tick-starvation.sh"
Cohesion: 0.48
Nodes (5): analyze(), print_scan(), read_log_input(), find-tick-starvation.sh script, usage()

### Community 837 - "Game-data knowledge graphs"
Cohesion: 0.29
Nodes (6): Build, Game-data knowledge graphs, Known scope boundaries, Node/edge model, Per-zone readiness report, Queries

### Community 839 - "DamageModifierGameData"
Cohesion: 0.33
Nodes (5): AppConfiguration, GameServerConfig, List, TimeSpan, GameServerConfig

### Community 841 - ".RunManifest"
Cohesion: 0.25
Nodes (7): ProjectileAnim, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 842 - "BuffKind"
Cohesion: 0.40
Nodes (4): CharacterOnlineTrackingTask, DateTime, object, TimeSpan

### Community 843 - "MailForSpeciality"
Cohesion: 0.25
Nodes (7): RechargeItemSkill, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 844 - "QuestManagerTests"
Cohesion: 0.50
Nodes (3): SCLootDiceNotifyPacket, sbyte, string

### Community 846 - "AppConfiguration"
Cohesion: 0.50
Nodes (3): QuestActConAcceptDoodad, Quest, QuestAct

### Community 847 - "AuctionManagerStartupWiringTests"
Cohesion: 0.60
Nodes (3): AuctionManagerStartupWiringTests, Task, Test

### Community 848 - "StubHomeSource"
Cohesion: 0.25
Nodes (7): SpawnBomb, CastAction, DateTime, Skill, SkillCaster, SkillCastTarget, SkillObject

### Community 849 - "CharacterLifecycleServiceTests"
Cohesion: 0.47
Nodes (3): CharacterLifecycleServiceTests, Task, Test

### Community 850 - "QuestActConAcceptItemGain"
Cohesion: 0.50
Nodes (3): QuestActConAcceptNpcEmotion, Quest, QuestAct

### Community 851 - "CSBuyItemsPacketTests.cs"
Cohesion: 0.33
Nodes (4): CSBuyItemsPacketTests, Task, Test, AAEmu.UnitTests.Game.Core.Packets.C2G

### Community 852 - "SCCharacterListPacketTests"
Cohesion: 0.60
Nodes (3): SCCharacterListPacketTests, Task, Test

### Community 853 - "BUG-002 — compact.sqlite3 schema too old for develop branch"
Cohesion: 0.33
Nodes (5): BUG-002 — compact.sqlite3 schema too old for develop branch, Fix, Note, Root cause, Symptom

### Community 854 - "BUG-004 — Login server advertises game server as 127.0.0.1"
Cohesion: 0.33
Nodes (5): BUG-004 — Login server advertises game server as 127.0.0.1, Fix, Note, Root cause, Symptom

### Community 855 - "BUG-013 — NPC sit poses render "knees in" (unplayable sit anim ids sent to the 1.2 client)"
Cohesion: 0.33
Nodes (5): BUG-013 — NPC sit poses render "knees in" (unplayable sit anim ids sent to the 1.2 client), Evidence, Fix, Investigation (what the client actually expects), Symptom

### Community 856 - "BUG-015 — CharacterQuests.Save NREs on a null completed-block entry — disconnect save aborts, quest rows lost"
Cohesion: 0.33
Nodes (5): BUG-015 — CharacterQuests.Save NREs on a null completed-block entry — disconnect save aborts, quest rows lost, Evidence (deterministic hermetic rig — t_90c0d0d1), Fix (per-character locks + defensive snapshot; no quest semantics change), Root cause — Dictionary race artifact (file:line), Symptom

### Community 857 - "Asking for Help on Discord"
Cohesion: 0.25
Nodes (3): FakeSession, IPAddress, Socket

### Community 858 - "For AAEmu version 1.2"
Cohesion: 0.33
Nodes (6): Client Downloads, Client v1.2 (`r208022`), Extra client archives, For AAEmu version 1.2, Launcher, Related

### Community 859 - "Getting Help"
Cohesion: 0.33
Nodes (6): Discord, Getting Help, GitHub Discussions, Related, Where to ask for help, Which channel should I choose

### Community 860 - "AGENT HANDOFF — 2026-08-26 Mail S3 acceptance + recovery reconciliation"
Cohesion: 0.33
Nodes (5): AGENT HANDOFF — 2026-08-26 Mail S3 acceptance + recovery reconciliation, Current state, Hard rules, Next resume order, Surviving worktrees — do not delete

### Community 861 - "AAEmu Server — Bug Log"
Cohesion: 0.33
Nodes (5): AAEmu Server — Bug Log, Audit findings (Kimi deep-dive 2026-08-09, t_0fda3cd3), Environment notes, Index, Production state (2026-08-02)

### Community 862 - "TRACKING / STATUS CONVENTION — how the fork stays always-current"
Cohesion: 0.33
Nodes (5): Division context, Low-overhead rules of thumb, STATUS.md format (lives at repo root, fork-local), The five rules, TRACKING / STATUS CONVENTION — how the fork stays always-current

### Community 863 - "ZONE / INSTANCE AUDIT TEMPLATE — content coverage"
Cohesion: 0.33
Nodes (5): Deliverables, Evidence inventory, Identity and scope, Required passes, ZONE / INSTANCE AUDIT TEMPLATE — content coverage

### Community 864 - "QuestActConAcceptLevelUp"
Cohesion: 0.50
Nodes (3): QuestActSupplyAppellation, Quest, QuestAct

### Community 865 - "DamageModifierGameData"
Cohesion: 0.50
Nodes (3): QuestActObjAlias, Quest, QuestAct

### Community 866 - "Bot template rig — scenario template evidence (P1 t_5efae4f1)"
Cohesion: 0.33
Nodes (5): ability-gate, Bot template rig — scenario template evidence (P1 t_5efae4f1), cat34-daily, level22-gate, level22-gate

### Community 867 - "WatchGameServer.ps1"
Cohesion: 0.60
Nodes (5): Cleanup(), CreateSymbolicLinks(), Find-GameProcess(), Send-CtrlC(), Start-DotnetWatch()

### Community 868 - "WatchLoginServer.ps1"
Cohesion: 0.60
Nodes (5): Cleanup(), CreateSymbolicLinks(), Find-LoginProcess(), Send-CtrlC(), Start-DotnetWatch()

### Community 869 - "npc-spawn-z-fix.py"
Cohesion: 0.50
Nodes (3): QuestActSupplyHonorPoint, Quest, QuestAct

### Community 871 - ".RandomElementByWeight"
Cohesion: 0.40
Nodes (3): IEnumerableExtensions, Func, IEnumerable

### Community 872 - "AuctionIdManager"
Cohesion: 0.50
Nodes (4): AuctionIdManager, string, uint, IAuctionIdManager

### Community 873 - "CharacterIdManager"
Cohesion: 0.50
Nodes (4): CharacterIdManager, string, uint, ICharacterIdManager

### Community 874 - "ChatIdManager"
Cohesion: 0.50
Nodes (4): ChatIdManager, string, uint, IChatIdManager

### Community 875 - "CrimeIdManager"
Cohesion: 0.50
Nodes (4): CrimeIdManager, string, uint, ICrimeIdManager

### Community 876 - "DoodadIdManager"
Cohesion: 0.50
Nodes (4): DoodadIdManager, string, uint, IDoodadIdManager

### Community 877 - "FamilyIdManager"
Cohesion: 0.50
Nodes (4): FamilyIdManager, string, uint, IFamilyIdManager

### Community 878 - "FriendIdManager"
Cohesion: 0.50
Nodes (4): FriendIdManager, string, uint, IFriendIdManager

### Community 879 - "GimmickIdManager"
Cohesion: 0.50
Nodes (4): GimmickIdManager, string, uint, IGimmickIdManager

### Community 880 - "HousingIdManager"
Cohesion: 0.50
Nodes (4): HousingIdManager, string, uint, IHousingIdManager

### Community 881 - "HousingTldManager"
Cohesion: 0.50
Nodes (4): HousingTldManager, string, uint, IHousingTldManager

### Community 882 - "MateIdManager"
Cohesion: 0.50
Nodes (4): IMateIdManager, MateIdManager, string, uint

### Community 883 - "MusicIdManager"
Cohesion: 0.50
Nodes (4): IMusicIdManager, MusicIdManager, string, uint

### Community 884 - "ObjectIdManager"
Cohesion: 0.50
Nodes (4): IObjectIdManager, ObjectIdManager, string, uint

### Community 885 - "PrivateBookIdManager"
Cohesion: 0.50
Nodes (4): IPrivateBookIdManager, PrivateBookIdManager, string, uint

### Community 886 - "ShipyardIdManager"
Cohesion: 0.50
Nodes (4): IShipyardIdManager, ShipyardIdManager, string, uint

### Community 887 - "TaskIdManager"
Cohesion: 0.50
Nodes (4): ITaskIdManager, TaskIdManager, string, uint

### Community 888 - "TeamIdManager"
Cohesion: 0.50
Nodes (4): ITeamIdManager, TeamIdManager, string, uint

### Community 889 - "MailBody"
Cohesion: 0.50
Nodes (3): QuestActSupplyJuryPoint, Quest, QuestAct

### Community 890 - "TradeIdManager"
Cohesion: 0.50
Nodes (4): ITradeIdManager, TradeIdManager, string, uint

### Community 891 - "TrialIdManager"
Cohesion: 0.50
Nodes (4): ITrialIdManager, TrialIdManager, string, uint

### Community 892 - "UccIdManager"
Cohesion: 0.50
Nodes (4): IUccIdManager, UccIdManager, string, uint

### Community 893 - "VisitedSubZoneIdManager"
Cohesion: 0.50
Nodes (4): IVisitedSubZoneIdManager, VisitedSubZoneIdManager, string, uint

### Community 894 - "WorldIdManager"
Cohesion: 0.50
Nodes (4): IWorldIdManager, WorldIdManager, string, uint

### Community 895 - "SCErrorMsgPacket"
Cohesion: 0.50
Nodes (3): QuestActObjDoodadPhaseCheck, Quest, QuestAct

### Community 897 - "QuestActSupplyLp"
Cohesion: 0.50
Nodes (3): QuestActObjZoneNpcTalk, Quest, QuestAct

### Community 901 - "AAEmu.Game.Models.Game.OpenPortal"
Cohesion: 0.40
Nodes (3): OpenPortalEffects, OpenPortalReagents, AAEmu.Game.Models.Game.OpenPortal

### Community 902 - "ItemGameData"
Cohesion: 0.40
Nodes (3): DoodadFuncAttachment, Doodad, BondKind

### Community 903 - "MateXpUpdateTask"
Cohesion: 0.50
Nodes (4): Development Conventions, The rules (locked), Verification history, Where these live

### Community 908 - "BUG-003 — Missing game data files (compact.sqlite3 + game_pak)"
Cohesion: 0.40
Nodes (4): BUG-003 — Missing game data files (compact.sqlite3 + game_pak), Fix, Root cause, Symptom

### Community 909 - "BUG-005 — game_pak (2023) vs compact.sqlite3 (2026) version drift"
Cohesion: 0.40
Nodes (4): BUG-005 — game_pak (2023) vs compact.sqlite3 (2026) version drift, Detail, Options, Verification

### Community 910 - "🔧 Technical Recommendations"
Cohesion: 0.40
Nodes (5): 1. Infrastructure, 2. Mocks and Fixtures, 3. Integration Tests, 4. Performance, 🔧 Technical Recommendations

### Community 911 - "🔧 Технические рекомендации"
Cohesion: 0.40
Nodes (5): 1. Инфраструктура, 2. Моки и фикстуры, 3. Интеграционные тесты, 4. Производительность, 🔧 Технические рекомендации

### Community 912 - "Quest Test Harness & Game-Data Graphs"
Cohesion: 0.40
Nodes (5): Game-data knowledge graphs, Quality gate, Quest Test Harness & Game-Data Graphs, Related, Scenario harness (M1-5b)

### Community 913 - "AAEmu.Aspire.AppHost"
Cohesion: 0.50
Nodes (4): AAEmu.Aspire.AppHost, Aspire.Hosting.MySql, MessagePack, Aspire.AppHost.Sdk/13.1.0

### Community 917 - "ExpressTextManager .cs"
Cohesion: 0.50
Nodes (3): AuctionManagerTests, Task, Test

### Community 918 - "SCLootDiceNotifyPacket"
Cohesion: 0.50
Nodes (3): ExpeditionManagerTests, Task, Test

### Community 921 - ".Constructor_DoesNotCallDeps"
Cohesion: 0.50
Nodes (3): PortalManagerTests, Task, Test

### Community 922 - ".Use"
Cohesion: 0.67
Nodes (3): M3 — Homestead integrity (two gates, M3a then M3b), M3a — Homestead shell (visible, interactive loop), M3b — Property persistence and recovery (engineering-heavy)

### Community 923 - ".Constructor_DoesNotCallDeps"
Cohesion: 0.50
Nodes (3): TeamManagerTests, Task, Test

### Community 925 - "QuestActConAcceptItemEquip"
Cohesion: 0.50
Nodes (3): FactionManagerTests, Task, Test

### Community 926 - "PartyOptions"
Cohesion: 0.50
Nodes (3): QuestActConAcceptSphere, Quest, QuestAct

### Community 932 - "QuestActConAcceptBuff"
Cohesion: 0.47
Nodes (5): apply_fix(), load_jsonc(), locate_fix_lines(), Find the Z line of each fix row. Exact-once matching.      expect_new=False: row, Tolerant parse: strip // comments outside strings (spawns files are JSONC).

### Community 933 - "README.md"
Cohesion: 0.50
Nodes (3): Combining with User Secrets (preferred), Configuration, Create Configuration File

### Community 934 - "HoldablesSchemaCheck"
Cohesion: 0.50
Nodes (3): HoldablesSchemaCheck, Logger, string

### Community 936 - "README.md"
Cohesion: 0.50
Nodes (3): Combining with User Secrets (preferred), Configuration, Create Configuration File

### Community 938 - ".Constructor_DoesNotCallDeps"
Cohesion: 0.50
Nodes (3): CharacterManagerTests, Task, Test

### Community 939 - ".Constructor_DoesNotCallDeps"
Cohesion: 0.50
Nodes (3): EnterWorldManagerTests, Task, Test

### Community 941 - ".Constructor_DoesNotCallDeps"
Cohesion: 0.50
Nodes (3): FamilyManagerTests, Task, Test

### Community 942 - ".Constructor_DoesNotCallDeps"
Cohesion: 0.50
Nodes (3): HousingManagerTests, Task, Test

### Community 943 - ".Constructor_DoesNotCallDeps"
Cohesion: 0.50
Nodes (3): MailManagerTests, Task, Test

### Community 944 - ".Constructor_DoesNotCallDeps"
Cohesion: 0.50
Nodes (3): MusicManagerTests, Task, Test

### Community 946 - ".Census_RealCompactSqlite3_NoComponentNextMissingFindings"
Cohesion: 0.50
Nodes (3): QuestDataCensusTests, Task, Test

### Community 947 - "SCGimmickJointsBrokenPacket"
Cohesion: 0.50
Nodes (3): QuestActSupplyExp, Quest, QuestAct

### Community 948 - ".Constructor_DoesNotCallDeps"
Cohesion: 0.50
Nodes (3): TradeManagerTests, Task, Test

### Community 949 - ".Constructor_DoesNotCallDeps"
Cohesion: 0.50
Nodes (3): NpcManagerTests, Task, Test

### Community 951 - "Priority 4: Additional Systems (~5-10% coverage)"
Cohesion: 0.50
Nodes (4): 4.1 Economy, 4.2 Guilds and Groups, 4.3 Mail and Friends, Priority 4: Additional Systems (~5-10% coverage)

### Community 952 - "Приоритет 3: Модели и сущности (~10-15% покрытия)"
Cohesion: 0.50
Nodes (4): 3.1 Персонажи, 3.2 NPC и моб, 3.3 Мир и зоны, Приоритет 3: Модели и сущности (~10-15% покрытия)

### Community 953 - "Приоритет 4: Дополнительные системы (~5-10% покрытия)"
Cohesion: 0.50
Nodes (4): 4.1 Экономика, 4.2 Гильдии и группы, 4.3 Почта и друзья, Приоритет 4: Дополнительные системы (~5-10% покрытия)

### Community 955 - "UpdatesForTransform"
Cohesion: 0.50
Nodes (4): netcoreapp3.1, Newtonsoft.Json (13.0.1), Microsoft.NET.Sdk, UpdatesForTransform

### Community 956 - "M2b playerbot pilot metrics — Solzreed golden route (character-cycle)"
Cohesion: 0.50
Nodes (3): M2b playerbot pilot metrics — Solzreed golden route (character-cycle), Per-cycle detail, Quest-cycle availability (post daily-reset fix)

### Community 958 - "example-ics-default-en.sql"
Cohesion: 0.50
Nodes (3): `ics_menu`, `ics_shop_items`, `ics_skus`

### Community 959 - "2019-02-18_aaemu_game.sql"
Cohesion: 0.50
Nodes (3): `friends`, `portal_book_coords`, `portal_visited_district`

### Community 960 - "2021-07-11_aaemu_game_transform.sql"
Cohesion: 0.50
Nodes (3): `characters`, `doodads`, `housings`

### Community 961 - "2021-07-21_aaemu_game_transform.sql"
Cohesion: 0.50
Nodes (3): `characters`, `doodads`, `housings`

### Community 962 - "2021-11-12_aaemu_game_index_fix.sql"
Cohesion: 0.50
Nodes (3): `characters`, `expeditions`, `housings`

### Community 965 - "sit-pose-census.py"
Cohesion: 0.83
Nodes (3): family_of(), main(), read_pak_index()

### Community 972 - "ExpertLimit"
Cohesion: 0.50
Nodes (3): MateXpUpdateTask, int, Logger

### Community 1006 - "AAEmu.WorldConverter"
Cohesion: 0.67
Nodes (3): Newtonsoft.Json, Microsoft.NET.Sdk, AAEmu.WorldConverter

### Community 1109 - "Asking for Help on Discord"
Cohesion: 0.33
Nodes (6): Asking for Help on Discord, Before posting, Discord etiquette that speeds up help, How to ask a good Discord question, Related, Suggested message template

### Community 1110 - "TlIdManager"
Cohesion: 0.50
Nodes (4): ITlIdManager, TlIdManager, string, uint

### Community 1112 - "SCSlaveEquipmentChangedPacket"
Cohesion: 0.40
Nodes (4): SCSlaveEquipmentChangedPacket, bool, uint, ushort

## Knowledge Gaps
- **2122 isolated node(s):** `R_NAME`, `R_STATUS`, `R_DETAIL`, `R_PATH`, `Microsoft.Data.Sqlite` (+2117 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **132 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `Character` connect `Character` to `GamePacket`, `PacketStream`, `DoodadFuncTemplate`, `EffectTemplate`, `ActorRequest`, `.WriteBc`, `PlotManager`, `FactionsEnum`, `AAEmu.Game.Models.Game.Items`, `Quest`, `IMessageOutput`, `.Execute`, `GameConnection`, `PopulationDirector`, `BotScheduleService`, `IItemManager`, `SkillCaster`, `PlayerBotRuntime`, `WorldTemplate`, `PacketMarshaler`, `WorldManagerTests`, `AAEmu.IntegrationTests.E2e`, `ItemContainer`, `BotPresenceCoordinator`, `.Run`, `Dungeon`, `GameplayActorTests`, `.SendNormalText`, `LevelingLoopScenarioRigTests`, `Doodad`, `BotDriveBridge`, `TeamManager`, `WorldInstance`, `Npc`, `Race`, `SlaveLifecycleTests`, `SCUnitStatePacketVisualOptionsTests`, `.Create`, `.CreateActor`, `.SetPosition`, `HeadlessSession`, `BaseMail`, `.Execute`, `TrialManager`, `.Capture`, `DoodadManagerTests`, `Transfer`, `.CreateCharacterManager`, `AuctionManager`, `.JoinActorWorld`, `HousingManager`, `ILoginConnection`, `.Run`, `Nudge`, `House`, `NpcSpawner`, `.Run`, `Follow-up 2026-08-31 (third pass) — npc_spawners DB-side name matching fixed`, `Mate`, `Singleton`, `BotActionCommandQueue`, `BotAdminService`, `.GetArmorGradeBuff`, `CharacterQuests`, `Tagging`, `BotRoamStepExecutor`, `AAEmu.Game.Core.Network.Stream`, `M4ExitIntegratedSessionTests`, `Gimmick`, `HousingM3aConstructionTests`, `WorldInstance`, `ShipTuningDebug`, `HomesteadPlacementScenarioTests`, `.SendMessage`, `ClientFileManager`, `BaseCombatBehavior`, `.Run`, `ItemTemplate`, `ICharacterManager`, `.Plant`, `.Setup`, `IInitializable`, `TimedRewardsManager`, `PopulationDirectorTests`, `MailExpiryRestartTests`, `SpawnManager`, `Transform`, `CropHarvestLoopRig`, `.Spawn`, `DuelManager`, `Behavior`, `.Apply`, `Simulation`, `.Indun_PartyOfTwo_ClearsHadirFarm_ExitsThroughRealPortal_OnLiveServer`, `.Execute`, `UnitRequirementsGameData`, `IBuffs`, `GameplayActorHouseBuildActionsTests`, `PortalManager`, `Shipyard`, `.Execute`, `.Execute`, `IBotStepExecutor`, `M3aExitScenarioTests`, `LootingContainer`, `Buffs`, `NoBuffBuffs`, `.Evaluate`, `.Execute`, `FamilyManager`, `EconomyDayCycleScenarioRigTests`, `.View`, `ItemProcBindingTests`, `Rig`, `DominionManager`, `.VerifyLoadedState`, `SlaveGameData`, `.Execute`, `PvpAggressionSeamRigTests`, `BotScenarioTemplate.cs`, `.Execute`, `TradeManager`, `.Execute`, `SummonSlave`, `Fly`, `SkillManager`, `SkillObject`, `ForceDismountHeadlessTests`, `Rig`, `MailTaxLifecycleTests`, `PvpFlaggingRigTests`, `.SeedSingletons`, `FriendMananger`, `.M3aM4EconomicReplay_OnFixtureWorld_PassesConservationAndLifecycle`, `.DriveVehicle`, `AAEmu.Game.Models.CryEngine.Entities`, `WorldSpawnPosition`, `ActiveRegionTickSpawnerScanTests`, `CharacterMails`, `ItemGameData`, `BotAppearanceFactory`, `ScriptCompiler`, `.CreateRig`, `CharacterSkills`, `NetMissionReader`, `BotParitySeedingTests`, `Task`, `.Apply`, `AnimationManager`, `PlayerBotAuditSink`, `PublicFarmManager`, `SubCommandParameterBase`, `SCICSMenuListPacket`, `.RunManifest`, `QuestActObjZoneQuestComplete`, `LootPack`, `.GetList`, `SubZoneManager`, `Character`, `PlotEventTemplate`, `SourceCatalog`, `IZoneManager`, `FakeZoneManager`, `HoldPositionBehavior`, `.CalculateAngleFrom`, `AreaShape`, `RoadMissionReader`, `CharacterMates`, `.BuildAreaSkill`?**
  _High betweenness centrality (0.152) - this node is a cross-community bridge._
- **Why does `AAEmu.Game.Core.Managers` connect `AAEmu.Game.Core.Managers` to `AAEmu.Commons.Network`, `QuestActSupplyRemoveItem`, `AAEmu.Game.Models.Game.Char`, `.Execute`, `AAEmu.Game.Models.Game.Quests.Static`, `AAEmu.Game.Models.Game.NPChar`, `AccessLevelManager`, `CommandManager`, `StringExtensionsTest`, `GameplayActor`, `GateSoakRunner.cs`, `SkillCastTarget`, `AAEmu.Game.Models.Game.Units.Movements`, `TickManager`, `GameService`, `ExperienceManagerTests`, `IDisposable`, `BotAccountProvisioningService`, `.CreateActor`, `TimedRewardsTask.cs`, `GameScheduleManager`, `SCGimmicksCreatedPacket`, `ExpressText.cs`, `AuctionSettings.cs`, `QuestScenarioVerdict`, `AuctionManager`, `.Snapshot`, `Task`, `Singleton`, `ILoadable`, `AAEmu.Game.Core.Network.Stream`?**
  _High betweenness centrality (0.114) - this node is a cross-community bridge._
- **Why does `BaseUnit` connect `DoodadFuncTemplate` to `Character`, `BaseUnit`, `.Run`, `AAEmu.Game.Models.Game.NPChar`, `.Schedule`, `SpecialEffectAction`, `SphereGameData`, `SkillCastTarget`, `.TeleportWithRegionSync_CharacterReRegistered_DestinationBroadcastsResolveIt`, `.NewBot`, `StreamPacket`, `EventArgs`, `DoodadSaveSubCommand`, `.SendNormalText`, `Doodad`, `OnTalkNpcGroupMadeArgs`, `Npc`, `RandomExtensionsTests`, `.CreateActorOnUniqueWorld`, `HeadlessSession`, `.Execute`, `NpcSaveSubCommand`, `WorldEvents.cs`, `.Execute`, `ShipShipInteraction`, `AAEmu.Game.Models.Tasks.Specialty`, `RandomElementByWeightTests`, `.TierManifests_DriveAndWriteRunnabilityReport`, `GameObject`, `NpcSpawner`, `ExecutionBoundary`, `.Spawn`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `ClientFileManager`, `BaseCombatBehavior`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `Gimmick`, `.Dispatch`, `AreaTrigger`, `SpawnManager`, `CropHarvestLoopRig`, `AAEmu.ArchaeologyMcp — read-only archaeology MCP server`, `TaxationsManager`, `.Apply`, `Behavior`, `GimmickGameData`, `UnitRequirementsGameData`, `IBuffs`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `WorldInstance`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `LootingContainer`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `Buffs`, `.Execute`, `BuffTests`, `.Execute`, `.Execute`, `.Execute`, `NoBuffBuffs`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Run`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.View`, `Rig`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `.Execute`, `CraftManager`, `BuffTrigger`, `GradeTemplate`, `.M3aM4EconomicReplay_OnFixtureWorld_PassesConservationAndLifecycle`, `MySqlFixture`, `.DriveVehicle`, `BaiReader`, `SkillModifiers`, `CraftManager`, `.RunManifest`, `MailForSpeciality`, `BaseBaiLoader`, `StubHomeSource`, `FlytrapAttackBehavior`, `ItemGameData`, `CharacterCraft`, `GameScheduleManager.cs`, `.Apply`, `Character`, `SchedulerSoakStage1Tests.cs`, `BuffModifiers`, `AAEmu.Game.Models.Game.Duels`, `GameplayActorCastEffectTests`, `WanderingSkillController`, `TimeSpanExtensionsTests`?**
  _High betweenness centrality (0.105) - this node is a cross-community bridge._
- **What connects `R_NAME`, `R_STATUS`, `R_DETAIL` to the rest of the system?**
  _2122 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `AAEmu.Commons.Network` be split into smaller, more focused modules?**
  _Cohesion score 0.008034476545579566 - nodes in this community are weakly interconnected._
- **Should `GamePacket` be split into smaller, more focused modules?**
  _Cohesion score 0.029221882432891606 - nodes in this community are weakly interconnected._
- **Should `AAEmu.Game.Models.Game.Char` be split into smaller, more focused modules?**
  _Cohesion score 0.012477600679053099 - nodes in this community are weakly interconnected._